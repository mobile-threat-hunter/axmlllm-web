"""Manifest domain core — typed model + anomaly detection over the AOSP data tree.

The hexagonal domain layer of axmlllm (see ``docs/architecture.md``). It depends only on
the data-tree shape exposed by the ``ManifestSource`` port, not on the native AOSP adapter.
"""

from .anomalies import Anomaly, detect
from .model import Attribute, Element, Manifest
from .resources import Bag, BagEntry, Resolution, ResourceTable

__all__ = [
    "Anomaly",
    "Attribute",
    "Bag",
    "BagEntry",
    "Element",
    "Manifest",
    "Resolution",
    "ResourceTable",
    "detect",
]
