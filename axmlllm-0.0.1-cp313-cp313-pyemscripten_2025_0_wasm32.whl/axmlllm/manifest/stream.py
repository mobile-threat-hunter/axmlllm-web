"""The events the device's parsers pull from a manifest, for one setting of its flags.

docs/flag-model-design.md (r6). The package parser does not read the XML tree: it reads what
XmlBlock.Parser.next() returns (XmlBlock.java:337-392), which drops a START_TAG and its subtree
when the element's binary-XML flag says skip — with the platform's layout_readwrite_flags on, for a
flag name index > 0 (a jint), through AconfigFlags.skip — and both parsers stop at the visible
root's END_TAG. The full parse's Validator (AssetManager.java:1209; the lite parse has none) also
names some of the START_TAGs it is given (Validator.java:52-80).

``pulled_stream`` replays that over the engine's ``events`` for one answer to every flag it asks,
through ``ask(name) -> bool``: the run tree (the next commit) forks there. Nothing here guesses a
flag; a name no device can have is false, ``android.content.res.manifest_flagging`` is true.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Callable

if TYPE_CHECKING:
    from .model import Element, Manifest

# the platform flag that gates XmlBlock's removal (fixed read-only per build: ENABLED in bp4a and
# trunk_staging only, so it varies across 36.x builds) — also a guard name that is that variable
LAYOUT_GATE = "android.content.res.layout_readwrite_flags"
# fixed on in every 36.x build (is_fixed_read_only; ENABLED from ap3a / bp1a, inherited)
MANIFEST_FLAGGING = "android.content.res.manifest_flagging"
# a negation byte other than 0 or 1 is copied into a C++ bool (undefined), passed as a jboolean
# through NewObject's varargs (ART appends it as a jint, unnormalized: reflection.cc) and compared
# by AconfigFlags.skip as `flagValue == negated`. Not probed: a build may keep the byte (equal to
# neither value: never skipped) or normalize it — read as either value, per byte (2 and 3 can
# differ under a low-bit reading). Each is a platform variable, asked where such a byte is read
NEGATION_NEITHER = (
    "<a flag extension's negation byte other than 0 or 1 equals neither value>"
)
NEGATION_READING = "<a flag extension's negation byte of {} reads as negated>"


# Validator: the tags Element.shouldValidate accepts (frameworks/base/core/java/android/content/
# res/Element.java, shouldValidate) — pinned against that source by tests/test_stream.py
VALIDATED_TAGS = frozenset(
    {
        "action",
        "activity",
        "activity-alias",
        "application",
        "attribution",
        "category",
        "compatible-screens",
        "data",
        "grant-uri-permission",
        "instrumentation",
        "intent",
        "intent-filter",
        "layout",
        "manifest",
        "meta-data",
        "overlay",
        "package",
        "path-permission",
        "permission",
        "permission-group",
        "permission-tree",
        "profileable",
        "property",
        "provider",
        "queries",
        "receiver",
        "screen",
        "service",
        "supports-gl-texture",
        "supports-screens",
        "uri-relative-filter-group",
        "uses-configuration",
        "uses-feature",
        "uses-library",
        "uses-native-library",
        "uses-permission",
        "uses-permission-sdk-23",
        "uses-permission-sdk-m",
        "uses-sdk",
    }
)


def flag_value(name: str, ask: Callable[[str], bool]) -> bool:
    """AconfigFlags.getFlagValue for this setting: a constant where no device differs, else asked.

    False for a name no device can have (outside aconfig's grammar: undefined everywhere).
    """
    from .dispatch import _is_aconfig_flag_name  # one grammar for both guard kinds

    if name == MANIFEST_FLAGGING:
        return True
    if name == LAYOUT_GATE or _is_aconfig_flag_name(name):
        return ask(name)
    return False


def skip(name: str, negated: bool, ask: Callable[[str], bool]) -> bool:
    """``AconfigFlags.skip``: the element is skipped iff the flag's value equals the negation."""
    return flag_value(name, ask) == negated


@dataclass
class Pulled:
    """What the parsers pull, for one answer to every flag asked.

    The stream itself (root, kept, removed, failure, hang, removed_run) is the one both parses
    pull: the lite parse reads it all (it has no Validator). The full parse reads the same events
    but its Validator throws at ``validator_failure_at``, so for the full parse the stream ends
    there when that is set. A Validator failure, when set, always comes before the stream's own
    failure or hang (the stream stops at its first). Both stop points are upper bounds: a parse
    that refuses earlier pulls no further.
    """

    # the visible root: the first top-level START_TAG next() returns, or None (no start tag)
    root: Element | None = None
    # the ordinals of the START_TAGs next() returns up to the visible root's END_TAG
    kept: set[int] = field(default_factory=set)
    # the ordinals XmlBlock removed (with their subtrees) before or inside the visible root
    removed: set[int] = field(default_factory=set)
    # why pulling fails, if it does, and after which returned START_TAG (-1: before any)
    failure: str | None = None
    failure_after: int = -1
    # an element removed with no END_TAG: the skip loop never returns (its ordinal)
    hang: int | None = None
    # the longest run of consecutive removed siblings: next() recurses once per removal
    removed_run: int = 0
    # every removal, as (its ordinal, the run's length at it): a parse that stops earlier (the
    # lite parse's refusal) recursed only through the removals before its stop
    removal_runs: list[tuple[int, int]] = field(default_factory=list)
    # the full parse's Validator: the ordinals it names, in order; the first that throws
    validator_named: list[int] = field(default_factory=list)
    validator_failure: str | None = None
    # the ordinal of the START_TAG it throws on, or -1: an END_TAG before any open element
    validator_failure_at: int | None = None
    # what this replay could not judge (an element past the depth cap has no flag facts here)
    incomplete: list[str] = field(default_factory=list)


def _elements(manifest: Manifest) -> dict[int, Element]:
    """Every element by its ordinal: built once per manifest (the run tree calls this per run)."""
    cached: dict[int, Element] | None = getattr(manifest, "_by_ordinal", None)
    if cached is None:
        cached = {}
        for r in manifest.roots:
            for e in r.iter():
                if e.ordinal is not None:
                    cached[e.ordinal] = e
        manifest._by_ordinal = cached  # type: ignore[attr-defined]
    return cached


def _guard(e: Element, ask: Callable[[str], bool], why: list[str]) -> bool:
    """XmlBlock.next's flag test for START_TAG ``e`` (XmlBlock.java:350-355): True to remove it.

    ``why`` receives the reason the read throws (the name does not read).
    """
    flag = e.flag
    if not flag:
        return False
    index = int(flag.get("name_index", 0))
    if index >= 1 << 31:  # a jint: negative, so `flag.mNameIndex > 0` fails — no guard
        return False
    if index <= 0:
        return False
    if not ask(LAYOUT_GATE):  # Flags.layoutReadwriteFlags() && ...: no name is read
        return False
    units = flag.get("name_java")
    if units is None:
        why.append(
            f"the binary-XML flag name of the element at line {e.line} does not read "
            "(getSequence: IndexOutOfBoundsException)"
        )
        return False
    name = units.decode("utf-16-le", "surrogatepass")
    if flag.get("name_styled"):
        why.append(
            f"note: the binary-XML flag name of the element at line {e.line} is a styled "
            "string, read as its text, and whether the device's style application throws is not "
            "replayed"
        )
    byte = int(flag.get("negated_byte", 1 if flag.get("negated") else 0))
    if byte in (0, 1):
        negated = byte == 1
    else:
        why.append(
            f"note: the binary-XML flag of the element at line {e.line} has a negation byte of "
            f"{byte}, neither 0 nor 1: its device reading is not verified (run as equal to neither "
            "value, never skipped, and as either value)"
        )
        if ask(NEGATION_NEITHER):
            return False
        negated = ask(NEGATION_READING.format(byte))
    return skip(name, negated, ask)


def pulled_stream(manifest: Manifest, ask: Callable[[str], bool]) -> Pulled:
    """Replay XmlBlock.Parser.next() over the manifest's events for the answers ``ask`` gives."""
    out = Pulled()
    if "events" not in manifest._doc:
        # a hand-built document (no engine stream): its root as given, nothing removed or named
        out.root = manifest.root
        return out
    events: list[int] = manifest._doc.get("events") or []  # read only: no copy per run
    by_ordinal = _elements(manifest)
    pos = 0
    depth = 0  # XmlBlock's mDepth, with mDecNextDepth (XmlBlock.java:367-375)
    dec_next = False
    stack: list[str] = []  # the Validator's mElements (validated tags only)
    last_start = -1
    run = 0

    noted: set[str] = set()

    def add_note(text: str) -> None:
        if text not in noted:
            noted.add(text)
            out.incomplete.append(text)

    def element(ordinal: int) -> Element | None:
        e = by_ordinal.get(ordinal)
        if e is None:
            add_note(
                "an element past the depth this tool parses: its binary-XML flag is not read here"
            )
        return e

    def native_next() -> int | None:  # None: END_DOCUMENT (the stream is exhausted)
        nonlocal pos
        if pos >= len(events):
            return None
        ev = events[pos]
        pos += 1
        return ev

    def next_event() -> int | None:
        """XmlBlock.Parser.next(): the event returned, or None at END_DOCUMENT. Sets failures."""
        nonlocal run, depth, dec_next
        while True:
            ev = native_next()
            if ev is None:
                return None
            if ev == -3:
                out.failure = (
                    "a corrupt node in the binary XML (XmlPullParserException)"
                )
                out.failure_after = last_start
                return None
            if ev >= 0:
                e = element(ev)
                why: list[str] = []
                removed = e is not None and _guard(e, ask, why)
                for w in why:  # notes hold whether or not it is removed
                    if w.startswith("note: "):
                        add_note(w[len("note: ") :])
                if removed:
                    out.removed.add(ev)
                    run += 1
                    out.removed_run = max(out.removed_run, run)
                    out.removal_runs.append((ev, run))
                    level = 1
                    while level > 0:
                        ev2 = native_next()
                        if ev2 is None:  # END_DOCUMENT forever: the loop never ends
                            out.hang = ev
                            return None
                        if ev2 == -3:
                            out.failure = "a corrupt node in the binary XML (XmlPullParserException)"
                            out.failure_after = last_start
                            return None
                        if ev2 >= 0:
                            out.removed.add(ev2)
                            level += 1
                        elif ev2 == -1:
                            level -= 1
                    continue  # return next(): one more frame of the recursion
                throws = [w for w in why if not w.startswith("note: ")]
                if throws:
                    out.failure, out.failure_after = throws[0], last_start
                    return None
            run = 0
            if dec_next:
                depth -= 1
                dec_next = False
            if ev >= 0:
                depth += 1
            elif ev == -1:
                dec_next = True
            return ev

    def validate(ev: int) -> None:
        """Validator.validate (Validator.java:52-80) on the event next() just returned."""
        if out.validator_failure is not None or depth > len(stack) + 1:
            return
        if ev >= 0:
            e = by_ordinal.get(ev)
            if e is None:
                return
            out.validator_named.append(ev)
            if e.tag_unreadable:
                out.validator_failure = (
                    f"the Validator's getName of the element at line {e.line} throws "
                    "(nativeGetString: IndexOutOfBoundsException)"
                )
                out.validator_failure_at = ev
                return
            if e.tag_null:
                out.validator_failure = (
                    f"the element at line {e.line} has no name (getName is null): "
                    "Element.shouldValidate throws a NullPointerException"
                )
                out.validator_failure_at = ev
                return
            if e.tag_styled:
                note = (
                    f"the tag name of the element at line {e.line}, which the Validator reads, is "
                    "a styled string; whether the device's style application throws is not "
                    "replayed"
                )
                add_note(note)
            if e.tag in VALIDATED_TAGS:
                stack.append(e.tag)
        elif ev == -1 and depth == len(stack):
            if not stack:  # mElements.pop() on an empty ArrayDeque (a stray END_TAG)
                out.validator_failure = (
                    "an END_TAG with no open element reaches the Validator, whose pop of its "
                    "empty stack throws (NoSuchElementException)"
                )
                out.validator_failure_at = -1
                return
            stack.pop()

    # the parsers' first loop: next() until a START_TAG (ApkLiteParseUtils:903-906)
    while True:
        ev = next_event()
        if ev is None:
            return out  # no start tag (or a failure / hang, already set)
        validate(ev)
        if ev >= 0:
            break
    root_depth = depth
    out.root = by_ordinal.get(ev)
    out.kept.add(ev)
    last_start = ev
    # then every event up to the visible root's END_TAG
    while True:
        ev = next_event()
        if ev is None:
            return out
        validate(ev)
        if ev >= 0:
            out.kept.add(ev)
            last_start = ev
        elif ev == -1 and depth == root_depth:
            return out
