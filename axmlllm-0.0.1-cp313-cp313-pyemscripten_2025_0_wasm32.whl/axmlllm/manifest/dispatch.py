"""Replay of the device's manifest dispatch (the full base parse), over the parsed element tree.

The package parser does not read the manifest as a tree (ParsingPackageUtils, "PPU"): each parse
loop dispatches EVERY start tag below its owner that an earlier handler did not consume, by local
name; a handler that returns without consuming its subtree leaves its descendants to the enclosing
loop; a tag the loop does not know is skipped with its subtree. Verified on a device
(tests/device_golden). What each loop accepts and what each handler reads and consumes is
``data/manifest_dispatch.json`` (scripts/gen_manifest_dispatch.py, every fact cited to AOSP); this
module only runs it.

Spec (the JSON):

``owners``: loop owner id -> {
    "site": "PPU:1016",              # the loop
    "depth": "any" | "direct",       # direct: only depth == owner + 1 start tags are seen
    "feature_flag": bool,            # AconfigFlags.skipCurrentElement before dispatch
    "unknown": "skip" | "error" | "descend",   # an unmatched tag: skipped with its subtree, the
                                     # install fails, or ignored while its children are dispatched
    "text": "ignore" | "error",      # a TEXT event inside the loop
    "children": {tag name: handler id}
}
``handlers``: handler id -> {
    "site": "PPU:1389",
    "effect": str | None,            # what the device records ("uses-permission", "activity", ...)
    "reads": {"styleable": str | None, "by_name": [[ns, name], ...]},
    "subtree": SUBTREE,              # what happens to the element's descendants
}
SUBTREE: "owner:<owner id>"  — the handler runs that loop over its subtree (consumes it);
         "skip"              — skipCurrentTag: descendants never dispatched;
         "leave"             — returns at once: descendants go to the enclosing loop;
         {"if": COND, "then": SUBTREE, "else": SUBTREE}
         {"subtree": SUBTREE, "effect": null} — a branch on which the handler records nothing
                             (an early ``success(null)``: a second <application>, a <permission>
                             whose maxSdkVersion is below the device's)
COND (evaluated from the manifest where it can be, else the outcome is ``conditional``):
         {"attr_int_lt_sdk": attr}   — the element's int attribute < the device SDK
         {"target_sdk_lt": n}        — the effective targetSdkVersion < n
         {"first": tag}              — the first such element dispatched by this owner
         {"aconfig": flag name}      — a device flag (never evaluated: both branches shown)
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import TYPE_CHECKING, Any

from . import reads as R
from .styleables import ATTR

if TYPE_CHECKING:
    from .model import Attribute, Element, Manifest

_SPEC: dict[str, Any] = json.loads(
    (Path(__file__).parent / "data" / "manifest_dispatch.json").read_text()
)


def _no_deeper_tag_reaches_a_direct_loop(spec: dict[str, Any]) -> None:
    """Refuse a spec in which a direct-depth loop could be handed a deeper tag.

    Such a loop (``"depth": "direct"``) reads only its direct children; a deeper tag reaches it
    only through a child that leaves its subtree or an unknown child it passes over. While every
    child of every direct loop consumes or skips its subtree and an unknown one is skipped or
    fails the install, the depth rule never decides anything — so it is checked here, not run.
    """

    def leaves(sub: Any) -> bool:
        if isinstance(sub, str):
            return sub == "leave"
        if "subtree" in sub:
            return leaves(sub["subtree"])
        return leaves(sub["then"]) or leaves(sub["else"])

    for oid, owner in spec["owners"].items():
        if owner["depth"] != "direct":
            continue
        if owner["unknown"] == "descend" or any(
            leaves(spec["handlers"][h]["subtree"]) for h in owner["children"].values()
        ):
            raise ValueError(
                f"direct-depth loop <{oid}> can be handed a deeper tag: replay it"
            )


_no_deeper_tag_reaches_a_direct_loop(_SPEC)

# The device SDK a condition like "maxSdkVersion < SDK_INT" is evaluated against: this AOSP's own
# (android16-qpr2-release, RELEASE_PLATFORM_SDK_VERSION 36) — the stock-AOSP baseline every other
# verdict here is taken on.
BASELINE_SDK = 36

_ANDROID = "android"


@dataclass(frozen=True)
class Dispatched:
    """What the device's parser did with one element.

    ``outcome``: "read" (a handler ran on it), "skipped_unknown" (a loop did not know it: skipped
    with its subtree), "skipped" (an ancestor's handler skipped the subtree, or an unknown ancestor
    was skipped), "ignored_unknown" (a loop ignored it but dispatched its children), "error" (the install
    fails here).
    ``owner``: the loop that saw it (its owner element's tag may differ from the XML parent — a
    handler that left its subtree passes it to an enclosing loop). ``conditions``: device facts the
    outcome holds under (a feature flag, a binary-XML flag extension, a platform flag), each a
    sentence; empty when it holds on every stock device of this AOSP.
    """

    element: Element
    outcome: str
    owner: str | None
    owner_element: Element | None
    handler: str | None = None
    effect: str | None = None
    because: str | None = None
    conditions: tuple[str, ...] = ()
    # read, and nothing recorded because of the element's own VALUES (a name that is not a plain
    # string, an SDK range that excludes this SDK) — the parser's ordinary rules, not a place in
    # the dispatch
    by_value: bool = False


@dataclass
class Replay:
    """The replay of one manifest: every element's ``Dispatched``, and whether the install fails."""

    dispatched: list[Dispatched] = field(default_factory=list)
    install_error: str | None = None
    # an install error in one flag reading only ("with the manifest's flags on: ...")
    conditional_install_error: str | None = None
    incomplete: str | None = None
    _index: dict[int, Dispatched] = field(default_factory=dict, repr=False)
    _parents: dict[int, Element] = field(default_factory=dict, repr=False)

    def of(self, element: Element) -> Dispatched | None:
        """Return the record for ``element`` (identity), or None when the replay never reached it."""
        if not self._index:
            self._index = {id(d.element): d for d in self.dispatched}
        return self._index.get(id(element))

    def parent(self, element: Element) -> Element | None:
        """Return ``element``'s parent in the XML tree (None for the root)."""
        return self._parents.get(id(element))

    def hidden(self, d: Dispatched) -> bool:
        """Whether a read element was dispatched by a loop other than its XML parent's own."""
        return (
            d.outcome == "read"
            and d.owner_element is not None
            and (d.owner_element is not self.parent(d.element))
        )

    def how_hidden(self, d: Dispatched) -> str:
        """Say how a hidden read element reaches the loop that reads it."""
        parent = self.parent(d.element)
        owner = d.owner_element
        pd = self.of(parent) if parent is not None else None
        if pd is not None and pd.outcome == "ignored_unknown":
            how = f"which <{owner.tag if owner else '?'}>'s loop passes over while reading its children"
        else:
            how = "whose handler leaves its subtree"
        where = f"<{parent.tag}> (line {parent.line})" if parent is not None else "?"
        return (
            f"nested in {where}, {how}, so <{owner.tag if owner else '?'}>'s loop "
            f"(line {owner.line if owner else '?'}) reads it"
        )

    def effective(self, effect: str) -> list[Dispatched]:
        """Elements the device records as ``effect`` (read by that handler), in parse order."""
        return [
            d for d in self.dispatched if d.outcome == "read" and d.effect == effect
        ]


@dataclass(frozen=True)
class _Loop:
    owner: str
    element: Element | None
    depth: int


def _class_name(package: str | None, cls: str | None) -> str | None:
    """``ParsingUtils.buildClassName`` (ParsingUtils.java:59-75)."""
    if not cls:
        return None
    if cls[0] == ".":
        return f"{package}{cls}"
    if "." not in cls:
        return f"{package}.{cls}"
    return cls


def _string(a: Attribute | None) -> str | None:
    """Return what a by-name string read gets: the raw string, else the typed value as text."""
    if a is None:
        return None
    if a.raw_string is not None:
        return a.raw_string
    return None if a.value is None else str(a.value)


# Deferred errors (ParseInput.DeferredError / ParseTypeImpl): an error the parser defers until it
# knows the targetSdkVersion, keyed by change id. Enabled when the target is ABOVE the change's
# gate (getTargetSdkForChange). Before the first <uses-sdk> a deferral is stored (the first of each
# change id); every <uses-sdk> re-checks every stored id against its target (enableDeferredError);
# after one, a deferral is checked at once — unless its id was already checked and found disabled.
_GATES = {
    "MISSING_APP_TAG": 29,
    "EMPTY_INTENT_ACTION_CATEGORY": 29,
    "MISSING_EXPORTED_FLAG": 30,
}
# components whose filters count only with an action (failOnNoActions, ParsedMainComponentUtils:138)
_FILTERS_NEED_ACTION = ("activity", "receiver", "activity-alias")
_COMPONENTS_WITH_EXPORTED_CHECK = ("activity", "receiver", "activity-alias", "service")


def _guards(manifest: Manifest) -> bool:
    """Whether any element carries a flag guard (android:featureFlag by name, a flag extension)."""
    root = manifest.root
    return root is not None and any(
        e.flag is not None or R.by_name(e, R.ANDROID, "featureFlag") is not None
        for e in root.iter()
    )


def replay(manifest: Manifest) -> Replay:
    """Run the device's full base parse dispatch over ``manifest``'s element tree.

    A flag decides whether a guarded element exists on a device (android:featureFlag, a binary-XML
    flag extension; "!flag" keeps it when the flag is off), and its absence can change what else
    is read (an <application> removed makes the next one THE application). Flags are device
    state, never guessed: with any guarded element the dispatch runs twice — every flag on, every
    flag off — and what one reading has and the other lacks carries that as a condition. Two
    settings, not every mixture of independent flags.
    """
    if not _guards(manifest):
        return _replay(manifest, world=None)
    on, off = _replay(manifest, world="on"), _replay(manifest, world="off")
    if on.install_error is not None and off.install_error is not None:
        return on
    by_on = {id(d.element): d for d in on.dispatched}
    by_off = {id(d.element): d for d in off.dispatched}
    note = {
        "on": "only if the manifest's flags are on",
        "off": "only if the manifest's flags are off",
    }
    for err, world in ((on.install_error, "on"), (off.install_error, "off")):
        if err is not None:  # that reading installs nothing
            other = "off" if world == "on" else "on"
            note[other] += f" (with them {world}, the install fails: {err})"

    def reads(d: Dispatched | None, run: Replay) -> bool:
        return (
            d is not None
            and run.install_error is None
            and d.outcome == "read"
            and d.effect is not None
        )

    merged: list[Dispatched] = []
    root = manifest.root
    for e in root.iter() if root is not None else ():
        a, o = by_on.get(id(e)), by_off.get(id(e))
        a_reads, o_reads = reads(a, on), reads(o, off)
        if a_reads and not o_reads and a is not None:
            merged.append(replace(a, conditions=a.conditions + (note["on"],)))
        elif o_reads and not a_reads and o is not None:
            merged.append(replace(o, conditions=o.conditions + (note["off"],)))
        elif a is not None or o is not None:
            merged.append(a if a is not None else o)  # type: ignore[arg-type]
    out = Replay(dispatched=merged, incomplete=on.incomplete)
    out._parents = on._parents
    if on.install_error is not None or off.install_error is not None:
        world = "on" if on.install_error is not None else "off"
        out.conditional_install_error = f"with the manifest's flags {world}: {on.install_error or off.install_error}"
    return out


def _replay(manifest: Manifest, world: str | None) -> Replay:
    """One dispatch run; ``world``: None (no flag guards), or every flag "on" / "off"."""
    out = Replay()
    root = manifest.root
    if root is None:
        out.install_error = "no root element"
        return out
    owners: dict[str, Any] = _SPEC["owners"]
    handlers: dict[str, Any] = _SPEC["handlers"]
    table = manifest.resources
    # the manifest's package, as the parser reads it: by name, no namespace, the raw string
    package = _string(R.by_name(root, None, "package"))
    first_seen: dict[tuple[int, str], tuple[str, ...]] = {}
    # the targetSdkVersion as parsed so far: none yet is 0 (PackageImpl default, ParsingUtils:54)
    target: list[int] = [0]
    enabled: list[bool] = [
        False
    ]  # deferred errors enabled (the first <uses-sdk> parsed)
    deferred: dict[str, str | None] = (
        {}
    )  # change id -> message, or None: checked and disabled
    activities: list[str | None] = []
    keysets_open: list[Element] = []
    capped = sum(e.dropped_descendants for e in root.iter())
    for e in root.iter():
        for c in e.children:
            out._parents[id(c)] = e
    if capped:
        out.incomplete = (
            f"{capped} element(s) nested past the depth this tool parses were not replayed "
            "(see depth_capped): a handler that leaves its subtree passes them to a loop above"
        )

    def record(d: Dispatched) -> None:
        out.dispatched.append(d)

    def skip_subtree(e: Element, because: str, conds: tuple[str, ...]) -> None:
        for c in e.children:
            for x in c.iter():
                record(
                    Dispatched(
                        x, "skipped", None, None, because=because, conditions=conds
                    )
                )

    def fail(why: str) -> None:
        if out.install_error is None:
            out.install_error = why

    def defer(change: str, why: str) -> None:
        """``ParseTypeImpl.deferError``."""
        if enabled[0]:
            if change in deferred:
                return  # already checked and found disabled
            if target[0] > _GATES[change]:
                fail(
                    f"{why} — an error for targetSdkVersion above {_GATES[change]} "
                    f"(this one: {target[0]})"
                )
            else:
                deferred[change] = None
        else:
            deferred.setdefault(change, why)

    def enable(new_target: int) -> None:
        """``ParseTypeImpl.enableDeferredError``: every stored change re-checked."""
        target[0], enabled[0] = new_target, True
        for change, why in reversed(list(deferred.items())):
            if new_target > _GATES[change]:
                fail(
                    f"{why or change} — an error for targetSdkVersion above "
                    f"{_GATES[change]} (a <uses-sdk> sets {new_target})"
                )
                return
            deferred[change] = None

    def text(e: Element, loop: _Loop) -> None:
        if e.text and owners[loop.owner].get("text") == "error":
            fail(
                f"text inside <{loop.owner}> ({owners[loop.owner]['site']}): the parse throws"
            )

    def resolve(sub: Any, e: Element, loop: _Loop, conds: list[str]) -> Any:
        if isinstance(sub, str) or "subtree" in sub:
            return sub
        cond = sub["if"]
        if "first" in cond:
            key = (id(loop.element), cond["first"])
            if key not in first_seen:
                first_seen[key] = tuple(conds)
                return resolve(sub["then"], e, loop, conds)
            return resolve(sub["else"], e, loop, conds)
        if "attr_int_lt_sdk" in cond:
            name = cond["attr_int_lt_sdk"]
            v = R.get_int(e, ATTR[name], -1, table)
            if isinstance(v, R.Throws):
                fail(
                    f"android:{name} on <{e.tag}> at line {e.line} is {v.why}: the parse throws"
                )
                return resolve(sub["else"], e, loop, conds)
            if isinstance(v, R.Unresolved):
                conds.append(
                    f"android:{name} is {v.why}: below {BASELINE_SDK} the handler records "
                    "nothing and leaves its subtree"
                )
                return resolve(sub["else"], e, loop, conds)
            holds = (
                v != -1 and v < BASELINE_SDK
            )  # -1: not set (ParsedPermissionUtils:75-76)
            return resolve(sub["then"] if holds else sub["else"], e, loop, conds)
        if "target_sdk_lt" in cond:
            holds = target[0] < cond["target_sdk_lt"]
            return resolve(sub["then"] if holds else sub["else"], e, loop, conds)
        if "package_is" in cond:
            holds = package == cond["package_is"]
            return resolve(sub["then"] if holds else sub["else"], e, loop, conds)
        if "aconfig" in cond:
            conds.append(
                f"platform flag {cond['aconfig']} on (off: the element is skipped)"
            )
            return resolve(sub["then"], e, loop, conds)
        raise ValueError(f"unknown condition {cond}")

    def uses_sdk(e: Element) -> None:
        # parseUsesSdk (PPU:1730-1760): peekValue — a string is a codename, which a release
        # platform refuses (computeMin/TargetSdkVersion); no targetSdkVersion: the min (default 1)
        lo = R.peek_int(e, ATTR["minSdkVersion"])
        hi = R.peek_int(e, ATTR["targetSdkVersion"])
        for label, v in (("minSdkVersion", lo), ("targetSdkVersion", hi)):
            if isinstance(v, (str, R.Unresolved)):
                fail(
                    f"android:{label} is a codename or a reference read as one "
                    f"({v if isinstance(v, str) else v.why}): a release platform refuses it "
                    "(INSTALL_FAILED_OLDER_SDK, computeTargetSdkVersion)"
                )
                return
        minimum = 1 if lo is None else lo
        enable(minimum if hi is None else hi)  # type: ignore[arg-type]

    def permission_request(e: Element, conds: list[str]) -> str | None:
        """Why a read <uses-permission> requests nothing (PPU:1389-1494), or None.

        In the parser's order: its attributes (the requiredFeature / requiredNotFeature ones,
        getNonConfigurationString, :1407-1421; usesPermissionFlags, a getInt that throws on a
        non-int, :1424), then its children (feature_conditions), then the name and SDK range.
        """
        flags = R.get_int(e, ATTR["usesPermissionFlags"], 0, table)
        if isinstance(flags, R.Throws):
            fail(
                f"android:usesPermissionFlags on <{e.tag}> at line {e.line} is {flags.why}: "
                "the parse throws"
            )
            return "the parse throws on it"
        for attr, has in (("requiredFeature", "has"), ("requiredNotFeature", "lacks")):
            feature = R.non_config_string(e, ATTR[attr], table)
            if isinstance(feature, R.Unresolved):
                conds.append(f"android:{attr} is {feature.why}")
            elif feature is not None:
                conds.append(f"the device {has} feature {feature!r} (android:{attr})")
        if R.non_resource_string(e, ATTR["name"]) is None:
            return "its android:name is not a plain string (getNonResourceString): nothing is requested"
        bounds = []
        for attr, default in (
            ("minSdkVersion", -(1 << 31)),
            ("maxSdkVersion", (1 << 31) - 1),
        ):
            v = R.min_or_max_sdk(e, ATTR[attr], default, table)
            if isinstance(v, R.Unresolved):
                conds.append(
                    f"android:{attr} is {v.why}: outside it nothing is requested"
                )
                v = default
            bounds.append(v)
        lo, hi = bounds
        if not lo <= BASELINE_SDK <= hi:
            return f"requested only on SDK {lo}..{hi}, not on {BASELINE_SDK}"
        return None  # its required-(not-)feature children: after its loop (feature_conditions)

    def feature_conditions(e: Element, start: int) -> None:
        """Add the features a <uses-permission> requires to its record (PPU:1444-1494).

        From the required-feature / required-not-feature records ITS loop dispatched — at any
        depth below it, as the replay reached them (a nested one too; device-verified) — never
        from its XML children.
        """
        at = start - 1  # the <uses-permission> record itself
        own = set(out.dispatched[at].conditions)
        conds = []
        for d in out.dispatched[start:]:
            if not (
                d.outcome == "read"
                and d.owner_element is e
                and d.effect in ("required-feature", "required-not-feature")
            ):
                continue
            text = (
                f"the device {'has' if d.effect == 'required-feature' else 'lacks'} feature "
                f"{_string(R.styleable(d.element, ATTR['name']))!r}"
            )
            extra = [c for c in d.conditions if c not in own]  # e.g. its own flag
            conds.append(text + (f" (only if: {'; '.join(extra)})" if extra else ""))
        if conds:
            assert out.dispatched[at].element is e
            out.dispatched[at] = replace(
                out.dispatched[at],
                conditions=out.dispatched[at].conditions + tuple(conds),
            )

    def intent_name(e: Element) -> None:
        # action / category: read by name; absent fails the parse, empty is a deferred error
        # (ParsedIntentInfoUtils:112-133)
        value = _string(R.by_name(e, R.ANDROID, "name"))
        if value is None:
            fail(f"<{e.tag}> at line {e.line} has no android:name: the parse fails")
        elif value == "":
            defer(
                "EMPTY_INTENT_ACTION_CATEGORY",
                f"<{e.tag}> at line {e.line} has an empty android:name",
            )

    def component_done(e: Element, effect: str, start: int) -> None:
        """Apply the checks the parser makes once a component's subtree is parsed."""
        if effect not in _COMPONENTS_WITH_EXPORTED_CHECK or R.styleable(
            e, ATTR["exported"]
        ):
            return
        # an intent filter (for an activity, receiver or alias: one with an action) and no
        # explicit exported: S+ refuses it (ParsedActivityUtils:497-505, ParsedServiceUtils:182)
        mine = out.dispatched[start:]
        filters = {
            id(d.element)
            for d in mine
            if d.outcome == "read"
            and d.effect == "intent-filter"
            and d.owner_element is e
        }
        if effect in _FILTERS_NEED_ACTION:
            filters = {
                id(d.owner_element)
                for d in mine
                if d.outcome == "read"
                and d.effect == "action"
                and d.owner_element is not None
                and id(d.owner_element) in filters
            }
        if filters:
            defer(
                "MISSING_EXPORTED_FLAG",
                f"<{e.tag}> at line {e.line} has intent filters and no android:exported",
            )

    def walk(e: Element, depth: int, loop: _Loop, inherited: tuple[str, ...]) -> None:
        if out.install_error is not None:
            return
        spec = owners[loop.owner]
        conds = list(inherited)
        present = True
        if e.flag is not None:
            neg = bool(e.flag.get("negated"))
            present = world is None or (world == "on") != neg
            conds.append(
                f"binary-XML flag {e.flag.get('name')!r} {'not ' if neg else ''}set (otherwise "
                "the device's XmlBlock removes this element and its subtree)"
            )
        if spec.get("feature_flag"):
            # read by name, whitespace trimmed (AconfigFlags.skipCurrentElement); "!" negates
            flag = _string(R.by_name(e, R.ANDROID, "featureFlag"))
            if flag is not None and flag.strip():
                neg = flag.strip().startswith("!")
                present = present and (world is None or (world == "on") != neg)
                conds.append(
                    f"android:featureFlag {flag.strip()!r} true on the device (otherwise this "
                    "element and its subtree are skipped)"
                )
        if not present:
            record(
                Dispatched(
                    e,
                    "skipped",
                    loop.owner,
                    loop.element,
                    because=f"its flag removes it (the flags-{world} reading)",
                    conditions=tuple(conds),
                )
            )
            skip_subtree(e, f"inside <{e.tag}>, which its flag removes", tuple(conds))
            return
        handler_id = spec["children"].get(e.tag)
        if handler_id is None:
            policy = spec["unknown"]
            if policy == "skip":
                record(
                    Dispatched(
                        e,
                        "skipped_unknown",
                        loop.owner,
                        loop.element,
                        because=f"unknown to <{loop.owner}>'s loop ({spec['site']})",
                        conditions=tuple(conds),
                    )
                )
                skip_subtree(
                    e,
                    f"inside <{e.tag}>, which <{loop.owner}>'s loop skipped",
                    tuple(conds),
                )
                return
            if policy == "error":
                record(
                    Dispatched(
                        e, "error", loop.owner, loop.element, conditions=tuple(conds)
                    )
                )
                fail(
                    f"<{e.tag}> under <{loop.owner}> ({spec['site']}): the parse fails"
                )
                return
            record(
                Dispatched(
                    e,
                    "ignored_unknown",
                    loop.owner,
                    loop.element,
                    conditions=tuple(conds),
                )
            )
            text(e, loop)
            for c in e.children:
                walk(c, depth + 1, loop, tuple(conds))
            return
        h = handlers[handler_id]
        sub = resolve(h["subtree"], e, loop, conds)
        effect = h.get("effect")
        because = None
        if not isinstance(sub, str):  # a branch that records nothing
            sub, effect = sub["subtree"], sub["effect"]
            because = "its handler returns early and records nothing"
        by_value = False
        if effect == "uses-permission":
            because = permission_request(e, conds)
            if because is not None:
                effect, by_value = None, True
        elif effect in ("action", "category"):
            intent_name(e)
        elif effect == "install-constraints":
            fail(
                f"<install-constraints> at line {e.line}: this AOSP refuses it for any package "
                "not on the device's install-constraints allowlist (InstallConstraintsTagParser)"
            )
        elif effect == "key-set" and keysets_open:
            fail(
                f"<key-set> at line {e.line} inside another <key-set>: improperly nested"
            )
        elif effect == "activity-alias":
            # the target must be an activity parsed BEFORE the alias (ParsedActivityUtils:267-296)
            raw = R.non_resource_string(e, ATTR["targetActivity"])
            if raw is None:
                fail(f"<activity-alias> at line {e.line} has no targetActivity")
            elif _class_name(package, raw) not in activities:
                fail(
                    f"<activity-alias> at line {e.line}: its target activity "
                    f"{_class_name(package, raw)} is not declared before it"
                )
        if out.install_error is not None:  # this element is where the parse fails
            record(
                Dispatched(
                    e,
                    "error",
                    loop.owner,
                    loop.element,
                    handler=handler_id,
                    because=out.install_error,
                    conditions=tuple(conds),
                )
            )
            return
        if effect in ("activity", "activity-alias"):
            # an alias joins the parsed activities too (addActivity, PPU:2381): a later alias
            # may target it
            activities.append(
                _class_name(package, R.non_resource_string(e, ATTR["name"]))
            )
        frozen = tuple(conds)
        record(
            Dispatched(
                e,
                "read",
                loop.owner,
                loop.element,
                handler=handler_id,
                effect=effect,
                because=because,
                conditions=frozen,
                by_value=by_value,
            )
        )
        start = len(out.dispatched)
        if effect == "uses-sdk":
            uses_sdk(e)
        if effect == "key-set":
            keysets_open.append(e)
        if sub == "skip":
            skip_subtree(
                e, f"<{e.tag}>'s handler skips its subtree ({h['site']})", frozen
            )
        elif sub == "leave":
            text(e, loop)
            for c in e.children:
                walk(c, depth + 1, loop, frozen)
        elif sub.startswith("owner:"):
            inner = _Loop(sub[len("owner:") :], e, depth)
            text(e, inner)
            for c in e.children:
                walk(c, depth + 1, inner, frozen)
            if effect is not None and out.install_error is None:
                component_done(e, effect, start)
            if h.get("effect") == "uses-permission":
                feature_conditions(e, start)
        else:
            raise ValueError(f"unknown subtree {sub!r}")
        if effect == "key-set":
            keysets_open.pop()

    if root.tag != _SPEC["root"]:
        record(Dispatched(root, "error", None, None))
        out.install_error = f"the root element is <{root.tag}>, not <{_SPEC['root']}>"
        return out
    h = handlers[_SPEC["root"]]
    record(
        Dispatched(
            root, "read", None, None, handler=_SPEC["root"], effect=h.get("effect")
        )
    )
    top = _Loop(h["subtree"][len("owner:") :], root, 1)
    text(root, top)
    for c in root.children:
        walk(c, 2, top, ())
    if out.install_error is None and not any(
        d.outcome == "read" and d.effect in ("application", "instrumentation")
        for d in out.dispatched
    ):
        defer("MISSING_APP_TAG", "<manifest> has no <application> or <instrumentation>")
    return out
