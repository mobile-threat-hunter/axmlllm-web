"""Replay of the device's manifest dispatch (the full base parse), over the parsed element tree.

The package parser does not read the manifest as a tree (ParsingPackageUtils, "PPU"): each parse
loop dispatches EVERY start tag below its owner that an earlier handler did not consume, by local
name; a handler that returns without consuming its subtree leaves its descendants to the enclosing
loop; a tag the loop does not know is skipped with its subtree. Verified on a device
(tests/device_golden). What each loop accepts and what each handler reads and consumes is
``data/manifest_dispatch.json`` (scripts/gen_manifest_dispatch.py, every fact cited to AOSP); this
module only runs it.

Spec (the JSON):

``owners``: loop owner id -> {
    "site": "PPU:1016",              # the loop
    "depth": "any" | "direct",       # direct: only depth == owner + 1 start tags are seen
    "feature_flag": bool,            # AconfigFlags.skipCurrentElement before dispatch
    "unknown": "skip" | "error" | "descend",   # an unmatched tag: skipped with its subtree, the
                                     # install fails, or ignored while its children are dispatched
    "text": "ignore" | "error",      # a TEXT event inside the loop
    "children": {tag name: handler id}
}
``handlers``: handler id -> {
    "site": "PPU:1389",
    "effect": str | None,            # what the device records ("uses-permission", "activity", ...)
    "reads": {"styleable": str | None, "by_name": [[ns, name], ...]},
    "subtree": SUBTREE,              # what happens to the element's descendants
}
SUBTREE: "owner:<owner id>"  — the handler runs that loop over its subtree (consumes it);
         "skip"              — skipCurrentTag: descendants never dispatched;
         "leave"             — returns at once: descendants go to the enclosing loop;
         {"if": COND, "then": SUBTREE, "else": SUBTREE}
         {"subtree": SUBTREE, "effect": null} — a branch on which the handler records nothing
                             (an early ``success(null)``: a second <application>, a <permission>
                             whose maxSdkVersion is below the device's)
COND (evaluated from the manifest where it can be, else the outcome is ``conditional``):
         {"attr_int_lt_sdk": attr}   — the element's int attribute < the device SDK
         {"target_sdk_lt": n}        — the effective targetSdkVersion < n
         {"first": tag}              — the first such element dispatched by this owner
         {"aconfig": flag name}      — a device flag (never evaluated: both branches shown)
"""

from __future__ import annotations

import functools
import hashlib
import json
from collections import deque
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable, Iterator

from . import reads as R
from . import stream as S
from .styleables import ATTR

if TYPE_CHECKING:
    from .model import Element, Manifest

_SPEC: dict[str, Any] = json.loads(
    (Path(__file__).parent / "data" / "manifest_dispatch.json").read_text()
)


def _no_deeper_tag_reaches_a_direct_loop(spec: dict[str, Any]) -> None:
    """Refuse a spec in which a direct-depth loop could be handed a deeper tag.

    Such a loop (``"depth": "direct"``) reads only its direct children; a deeper tag reaches it
    only through a child that leaves its subtree or an unknown child it passes over. While every
    child of every direct loop consumes or skips its subtree and an unknown one is skipped or
    fails the install, the depth rule never decides anything — so it is checked here, not run.
    """

    def leaves(sub: Any) -> bool:
        if isinstance(sub, str):
            return sub == "leave"
        if "subtree" in sub:
            return leaves(sub["subtree"])
        return leaves(sub["then"]) or leaves(sub["else"])

    for oid, owner in spec["owners"].items():
        if owner["depth"] != "direct":
            continue
        if owner["unknown"] == "descend" or any(
            leaves(spec["handlers"][h]["subtree"]) for h in owner["children"].values()
        ):
            raise ValueError(
                f"direct-depth loop <{oid}> can be handed a deeper tag: replay it"
            )


_no_deeper_tag_reaches_a_direct_loop(_SPEC)

# The device SDK a condition like "maxSdkVersion < SDK_INT" is evaluated against: this AOSP's own
# (android16-qpr2-release, RELEASE_PLATFORM_SDK_VERSION 36) — the stock-AOSP baseline every other
# verdict here is taken on.
BASELINE_SDK = 36
# the golden device's ro.build.version.sdk_full is 36.1: its resources request carries minor 1
# (RESOURCES_SDK_INT_FULL, AssetManager.java:1615; device golden ra_minor picks values-v36.1)
BASELINE_SDK_MINOR = 1

_ANDROID = "android"


@dataclass(frozen=True)
class Dispatched:
    """What the device's parser did with one element.

    ``outcome``: "read" (a handler ran on it), "skipped_unknown" (a loop did not know it: skipped
    with its subtree), "skipped" (an ancestor's handler skipped the subtree, or an unknown ancestor
    was skipped), "ignored_unknown" (a loop ignored it but dispatched its children), "error" (the install
    fails here).
    ``owner``: the loop that saw it (its owner element's tag may differ from the XML parent — a
    handler that left its subtree passes it to an enclosing loop). ``conditions``: device facts the
    outcome holds under (a feature flag, a binary-XML flag extension, a platform flag), each a
    sentence; empty when it holds on every stock device of this AOSP.
    """

    element: Element
    outcome: str
    owner: str | None
    owner_element: Element | None
    handler: str | None = None
    effect: str | None = None
    because: str | None = None
    conditions: tuple[str, ...] = ()
    # read, and nothing recorded because of the element's own VALUES (a name that is not a plain
    # string, an SDK range that excludes this SDK) — the parser's ordinary rules, not a place in
    # the dispatch
    by_value: bool = False


@dataclass
class Replay:
    """The replay of one manifest: every element's ``Dispatched``, and whether the install fails."""

    dispatched: list[Dispatched] = field(default_factory=list)
    install_error: str | None = None
    # an install error in one flag reading only ("with the manifest's flags on: ...")
    conditional_install_error: str | None = None
    # the run tree stopped at its bound: what only an unrun flag setting reads is not here
    capped: str | None = None
    # the longest run of consecutive siblings XmlBlock removes (next() recurses once per removal),
    # and a setting with it
    removed_run: int = 0
    removed_run_with: tuple[str, ...] | None = None
    # elements reached only by settings that refuse the install (merged with installing ones)
    _refused_only: set[int] = field(default_factory=set, repr=False)
    # the notes `incomplete` joins, kept apart (a note may itself hold "; "), and as a set
    _notes: list[str] = field(default_factory=list, repr=False)
    _note_set: set[str] = field(default_factory=set, repr=False)
    _index: dict[int, Dispatched] = field(default_factory=dict, repr=False)

    def note(self, text: str) -> None:
        """Add a note to `incomplete` (once)."""
        if text not in self._note_set:
            self._note_set.add(text)
            self._notes.append(text)

    @property
    def incomplete(self) -> str | None:
        """What the replay could not judge, its notes joined (None: nothing)."""
        return "; ".join(self._notes) if self._notes else None

    _parents: dict[int, Element] = field(default_factory=dict, repr=False)

    def of(self, element: Element) -> Dispatched | None:
        """Return the record for ``element`` (identity), or None when the replay never reached it."""
        if not self._index:
            self._index = {id(d.element): d for d in self.dispatched}
        return self._index.get(id(element))

    def parent(self, element: Element) -> Element | None:
        """Return ``element``'s parent in the XML tree (None for the root)."""
        return self._parents.get(id(element))

    def hidden(self, d: Dispatched) -> bool:
        """Whether a read element was dispatched by a loop other than its XML parent's own."""
        return (
            d.outcome == "read"
            and d.owner_element is not None
            and (d.owner_element is not self.parent(d.element))
        )

    def how_hidden(self, d: Dispatched) -> str:
        """Say how a hidden read element reaches the loop that reads it."""
        parent = self.parent(d.element)
        owner = d.owner_element
        pd = self.of(parent) if parent is not None else None
        if pd is not None and pd.outcome == "ignored_unknown":
            how = f"which <{owner.tag if owner else '?'}>'s loop passes over while reading its children"
        else:
            how = "whose handler leaves its subtree"
        where = f"<{parent.tag}> (line {parent.line})" if parent is not None else "?"
        return (
            f"nested in {where}, {how}, so <{owner.tag if owner else '?'}>'s loop "
            f"(line {owner.line if owner else '?'}) reads it"
        )

    def effective(self, effect: str) -> list[Dispatched]:
        """Elements the device records as ``effect`` (read by that handler), in parse order."""
        return [
            d for d in self.dispatched if d.outcome == "read" and d.effect == effect
        ]


@dataclass(frozen=True)
class _Loop:
    owner: str
    element: Element | None
    depth: int


def _class_name(package: str | None, cls: str | None) -> str | None:
    """``ParsingUtils.buildClassName`` (ParsingUtils.java:59-75)."""
    if not cls:
        return None
    if cls[0] == ".":
        return f"{package}{cls}"
    if "." not in cls:
        return f"{package}.{cls}"
    return cls


_ACONFIG_LOWER = "abcdefghijklmnopqrstuvwxyz"


def _is_aconfig_ident(s: str) -> bool:
    """Return aconfig's ``is_valid_name_ident`` (aconfig_protos/src/lib.rs:78-91).

    ``[a-z][a-z0-9_]*`` in ASCII, with no consecutive underscores.
    """
    return (
        s[:1] != ""
        and s[0] in _ACONFIG_LOWER
        and all(c in _ACONFIG_LOWER or c in "0123456789_" for c in s)
        and "__" not in s
    )


def _is_aconfig_flag_name(name: str) -> bool:
    """Whether a device can have an aconfig flag named ``name`` ("<package>.<flag>").

    aconfig refuses every parsed flag whose package is not ``is_valid_package_ident`` (it has a
    '.', every part an ident) or whose name is not an ident (aconfig_protos/src/lib.rs:94-99,
    293-309). AconfigFlags keys its proto storage by package + "." + name, and its new storage
    splits the name at the last '.' into a package and a flag: any other name is undefined or
    not found — false on every device.
    """
    package, dot, flag = name.rpartition(".")
    return (
        bool(dot)
        and "." in package
        and all(_is_aconfig_ident(p) for p in (*package.split("."), flag))
    )


_MAX_FILE_NAME_SIZE = 223  # FrameworkParsingPackageUtils.java:58
_BIND_DEVICE_ADMIN = "android.permission.BIND_DEVICE_ADMIN"
_DEVICE_ADMIN_META_DATA = (
    "android.app.device_admin"  # DeviceAdminReceiver.DEVICE_ADMIN_META_DATA
)


def _has_styled_string(row: Any) -> bool:
    """Whether a TypedArray row (or one of its per-state alternatives) is a styled string."""
    if isinstance(row, dict):
        return bool(row.get("string_styled")) or any(
            _has_styled_string(v) for v in row.values()
        )
    if isinstance(row, list):
        return any(_has_styled_string(v) for v in row)
    return False


def _validate_name(
    name: str, require_separator: bool, require_filename: bool
) -> str | None:
    """``FrameworkParsingPackageUtils.validateName`` (FrameworkParsingPackageUtils.java:72-103).

    The error message, or None. Over Java's chars (UTF-16 units): letters anywhere, a digit or '_'
    only after one, '.' a separator; a bad character is shown escaped unless printable ASCII.
    """
    units = R._utf16(name)
    has_sep, front = False, True
    for c in units:
        if "a" <= c <= "z" or "A" <= c <= "Z":
            front = False
            continue
        if not front and ("0" <= c <= "9" or c == "_"):
            continue
        if c == ".":
            has_sep, front = True, True
            continue
        shown = c if " " <= c <= "~" else f"\\u{ord(c):04x}"
        return f"bad character '{shown}'"
    if require_filename:
        if not _is_valid_ext_filename(name):
            return "Invalid filename"
        if len(units) > _MAX_FILE_NAME_SIZE:
            return f"the length of the name is greater than {_MAX_FILE_NAME_SIZE}"
    return (
        None
        if has_sep or not require_separator
        else "must have at least one '.' separator"
    )


def _is_valid_ext_filename(name: str) -> bool:
    r"""``FileUtils.isValidExtFilename`` (FileUtils.java:1076-1101): name == buildValidExtFilename.

    buildValidExtFilename is "(invalid)" for "", "." and ".." (never equal to them), maps '\0' and
    '/' to '_', and trimFilename shortens it — so never equal — past 255 UTF-8 bytes. Reached only
    from validateName, whose loop lets through nothing but ASCII letters, digits, '_' and '.'.
    """
    if name in ("", ".", ".."):
        return False
    built = "".join("_" if c in ("\0", "/") else c for c in name)
    return len(built.encode("utf-8")) <= 255 and built == name


def _split_types_error(values: str) -> str | None:
    """``separateAndValidateSplitTypes`` over a non-empty value (ApkLiteParseUtils:968-985).

    ``values.trim().split(",")``, every part trimmed through validateName (a file name, no
    separator required): the first error, or None.
    """
    for part in R._java_split(R._java_trim(values), ","):
        err = _validate_name(R._java_trim(part), False, True)
        if err is not None:
            return err
    return None


def _feature_flag_name(text: str) -> tuple[bool, str]:
    """AconfigFlags.skipCurrentElement's parse of a featureFlag (AconfigFlags.java:323-329).

    ``(negated, name)``: String.strip (Android's whitespace), a leading "!" negates, strip again.
    """
    stripped = R._java_strip(text)
    if stripped.startswith("!"):
        return True, R._java_strip(stripped[1:])
    return False, stripped


# Deferred errors (ParseInput.DeferredError / ParseTypeImpl): an error the parser defers until it
# knows the targetSdkVersion, keyed by change id. Enabled when the target is ABOVE the change's
# gate (getTargetSdkForChange). Before the first <uses-sdk> a deferral is stored (the first of each
# change id); every <uses-sdk> re-checks every stored id against its target (enableDeferredError);
# after one, a deferral is checked at once — unless its id was already checked and found disabled.
_GATES = {
    "MISSING_APP_TAG": 29,
    "EMPTY_INTENT_ACTION_CATEGORY": 29,
    "MISSING_EXPORTED_FLAG": 30,
}
# components whose filters count only with an action (failOnNoActions, ParsedMainComponentUtils:138)
_FILTERS_NEED_ACTION = ("activity", "receiver", "activity-alias")
_COMPONENTS_WITH_EXPORTED_CHECK = ("activity", "receiver", "activity-alias", "service")
# PackageManager.APP_DETAILS_ACTIVITY_CLASS_NAME (AppDetailsActivity.class.getName()): refused as
# a component's class (ParsedComponentUtils:54-56)
_APP_DETAILS_ACTIVITY = "android.app.AppDetailsActivity"
# the handlers that run ParsedComponentUtils.parseComponent (its android:name read and checks):
# the app components (ParsedMainComponentUtils:57), <permission> / <permission-tree> /
# <permission-group> (ParsedPermissionUtils:62, 223, 269) and <instrumentation>
# (ParsedInstrumentationUtils:50)
_PARSE_COMPONENT = (
    "activity",
    "activity-alias",
    "service",
    "receiver",
    "provider",
    "permission",
    "permission-tree",
    "permission-group",
    "instrumentation",
)


def _guards(manifest: Manifest) -> bool:
    """Whether any element of any root carries a flag guard (featureFlag by name, a flag ext)."""
    return any(
        e.flag is not None or R.by_name(e, R.ANDROID, "featureFlag") is not None
        for r in manifest.roots
        for e in r.iter()
    )


_MAX_LEAVES = 1024  # flag settings run per manifest (docs/flag-model-design.md, r6)
# the work of all the runs (events pulled, records dispatched, notes): a run costs
# its manifest's size, so a large manifest with many flags is bounded by its work, not by its
# settings alone
_MAX_WORK = 1 << 25
_WITNESS_NAMES = 8  # true names a witness lists before "and N more"
_REASONS_SHOWN = 3  # distinct refusals a merged install error lists


def replay(manifest: Manifest) -> Replay:
    """Run the device's full base parse dispatch over ``manifest``'s element tree.

    A flag decides whether a guarded element exists on a device (android:featureFlag; a binary-XML
    flag extension, with the platform's layout_readwrite_flags), and its absence can change what
    else is read. Flags are device state, never guessed: the dispatch is run once per setting of
    the flags it actually reads (the run tree, ``_run_tree``), and the runs are merged
    (``_Merge``): what every installing setting reads alike holds on every device; what differs
    says so, with a setting that reads it and one that does not.
    """
    if not _guards(manifest):
        return _replay(manifest, None)
    try:
        return _run_tree(manifest)
    finally:
        _shown_name.cache_clear()  # its names are this manifest's: not kept past it


def _run_tree(manifest: Manifest) -> Replay:
    """Run every flag setting the replay asks (``_RunTree``) and merge the runs as they end."""
    tree = _RunTree(manifest)
    merge = _Merge(manifest)
    for assignment, run in tree:
        merge.add(tuple(sorted(n for n, v in assignment.items() if v)), run)
    return merge.result(tree.capped)


class _RunTree:
    """Every setting of the flags the replay asks, by re-execution, fewest flags on first.

    A run answers a name it has not met with false and schedules the same run with it true from
    that point: the leaves are disjoint and cover every assignment, and a name no run asks is no
    variable. Runs are taken by how many names they set true (all false, then each single flip,
    then pairs, ...): first in, first out does it, since a run schedules only runs with one more
    name true. So within the bound the single flips run first, in the order the names are first
    asked — and past it a payload behind one name the bound does not reach (a binary-XML flag is
    read only with the gate on: a pair) is not run, and said so. Bounded by ``_MAX_LEAVES`` runs and ``_MAX_WORK``, charged with what
    a run costs — the events its stream pulls (and so the names it asks), the records it
    dispatches, its notes; past either, ``capped`` says so. A scheduled run is kept as its parent's asked names and
    the index flipped, not as a copy of the assignment (so what waits is bounded by the work
    charged: a run is charged the whole input it reads, events and attributes); iterating yields each run with its assignment, kept by neither.
    """

    def __init__(self, manifest: Manifest) -> None:
        self.manifest = manifest
        self.runs = 0
        self.capped: str | None = None

    def __iter__(self) -> Iterator[tuple[dict[str, bool], Replay]]:
        # (the parent run's asked names in order, the index set true)
        todo: deque[tuple[list[tuple[str, bool]], int]] = deque([([], -1)])
        work = 0
        # what one run reads: its stream's events (and so the names it asks), every element's
        # tag and every attribute with its strings — a run's reads scan attributes and walk
        # strings character by character (strip, validateName, aconfig's grammar); charged in
        # full to every run
        size = len(self.manifest._doc.get("events") or ()) + sum(
            _read_size(e) for r in self.manifest.roots for e in r.iter()
        )
        asked: set[str] = set()
        while todo and self.runs < _MAX_LEAVES and work < _MAX_WORK:
            parent, flip = todo.popleft()
            order: list[tuple[str, bool]] = (
                parent[:flip] + [(parent[flip][0], True)] if flip >= 0 else []
            )
            assignment = dict(order)

            def ask(
                name: str,
                assignment: dict[str, bool] = assignment,
                order: list[tuple[str, bool]] = order,
            ) -> bool:
                if name not in assignment:
                    assignment[name] = False
                    order.append((name, False))
                    todo.append((order, len(order) - 1))
                return assignment[name]

            run = _replay(self.manifest, ask)
            asked.update(assignment)
            self.runs += 1
            # the names a run asks (and schedules) are at most its events: charged with them
            work += size + len(run.dispatched) + len(run._notes) + 1
            yield assignment, run
        if todo:
            names = [n for n in asked if n != S.LAYOUT_GATE and not n.startswith("<")]
            self.capped = (
                f"the manifest reads {len(names)} flag name(s), and only {self.runs} of their "
                "settings were run (fewest flags on first): what only an unrun setting reads "
                "is not shown as read"
            )


_SHOWN_NAME_CHARS = (
    120  # a flag name longer than this is shown cut, with its length and hash
)


@functools.lru_cache(maxsize=4096)
def _shown_name(name: str, limit: int = _SHOWN_NAME_CHARS) -> str:
    """Show a flag name as the replay's text does: whole, or cut with its length and a hash.

    Per-element text (a condition, a witness) names flags once per element: an attacker's
    megabyte name in one pool string would be copied into every element's text.
    """
    if len(name) <= limit:
        return name
    digest = hashlib.sha256(name.encode("utf-16-le", "surrogatepass")).hexdigest()[:16]
    return f"{name[: limit * 2 // 3]}… ({len(name)} chars, sha256/utf-16 {digest})"


def _read_size(e: Element) -> int:
    """Measure the text of ``e`` a run can read: its tag, each attribute's name and strings."""
    n = 1 + len(e.tag or "")
    for a in e.attributes:
        n += 1 + len(a.name) + len(a.ns or "")
        for t in (a.raw_string, a.typed_string, a.raw_java, a.typed_java, a.value):
            if isinstance(t, (str, bytes)):
                n += len(t)
    return n


def _witness(trues: tuple[str, ...]) -> str:
    """Name a run's setting: the names it set true; every other name it read was false."""
    if not trues:
        return "with every flag false"
    shown = ", ".join(_shown_name(n) for n in trues[:_WITNESS_NAMES])
    if len(trues) > _WITNESS_NAMES:
        shown += f" and {len(trues) - _WITNESS_NAMES} more"
    return f"with {shown} true and every other flag false"


def _record_key(d: Dispatched) -> tuple[Any, ...]:
    """Return a record's identity across flag settings: what the device does with it."""
    owner = id(d.owner_element) if d.owner_element is not None else None
    return (
        d.outcome,
        d.effect,
        d.handler,
        d.owner,
        owner,
        d.because,
        d.conditions,
        d.by_value,
    )


_DESCRIBED_CHARS = (
    400  # a record text the merge copies into a per-element note, cut past this
)


def _describe(d: Dispatched, other: Dispatched | None) -> str:
    """Say what a record says, enough to tell it from ``other`` (a differing record).

    Built once per element: every piece that can hold the manifest's text (a tag in ``because``,
    an owner, a condition) is cut, so a long tag is not copied into each of its children's notes.
    """

    def cut(t: str) -> str:
        return _shown_name(t, _DESCRIBED_CHARS)

    text = d.outcome.replace("_", " ")
    if d.effect and d.effect != d.element.tag:
        text += f" as {cut(d.effect)}"
    if d.because:
        text += f" ({cut(d.because)})"
    if other is not None and (
        other.outcome,
        other.effect,
        other.because,
    ) == (d.outcome, d.effect, d.because):
        owner = d.owner_element
        text += f" by the <{cut(d.owner or '')}> loop" + (
            (
                f" of element #{owner.ordinal} (line {owner.line})"
                if owner.ordinal is not None
                else f" at line {owner.line}"
            )
            if owner is not None
            else ""
        )
        if d.handler != other.handler and d.handler:
            text += f" ({cut(d.handler)})"
        if d.conditions != other.conditions and d.conditions:
            text += f" if {cut('; '.join(d.conditions))}"
        if d.by_value != other.by_value:
            text += " by its own values" if d.by_value else " not by its own values"
    return text


@dataclass
class _Seen:
    """One element across the runs merged: its first records, by what they say."""

    first: tuple[tuple[str, ...], Dispatched]
    read: tuple[tuple[str, ...], Dispatched] | None = None
    # the first two distinct records (by _record_key), each with the first run that gave it
    keys: dict[tuple[Any, ...], tuple[tuple[str, ...], Dispatched]] = field(
        default_factory=dict
    )
    # a run that did not reach it
    missing: tuple[str, ...] | None = None
    stamp: int = 0


class _Records:
    """The records of one kind of run (installing, or refusing), merged as each run ends."""

    def __init__(self, kind: str) -> None:
        self.kind = kind  # "installing" or "refusing"
        self.runs = 0
        self.first_run: tuple[str, ...] | None = None
        self.seen: dict[int, _Seen] = {}

    def add(self, trues: tuple[str, ...], run: Replay) -> None:
        self.runs += 1
        if self.first_run is None:
            self.first_run = trues
        for d in run.dispatched:
            s = self.seen.get(id(d.element))
            if s is None:
                s = _Seen(first=(trues, d))
                if self.runs > 1:  # every earlier run of this kind did not reach it
                    s.missing = self.first_run
                self.seen[id(d.element)] = s
            s.stamp = self.runs
            if s.read is None and d.outcome == "read":
                s.read = (trues, d)
            key = _record_key(d)
            if key not in s.keys and len(s.keys) < 2:
                s.keys[key] = (trues, d)
        for s in self.seen.values():
            if s.stamp != self.runs and s.missing is None:
                s.missing = trues

    def record(self, s: _Seen, capped: bool) -> Dispatched:
        """Return the merged record: alike in every run, or conditioned with a witness each way."""
        shown = s.read or s.first
        if not capped and s.missing is None and len(s.keys) == 1:
            return shown[1]
        shown_key = _record_key(shown[1])
        other = next(
            (v for k, v in s.keys.items() if k != shown_key),
            None,
        )
        if other is not None:
            note = (
                f"depends on the device's flags: {_describe(shown[1], other[1])} "
                f"{_witness(shown[0])}; {_describe(other[1], shown[1])} {_witness(other[0])}"
            )
        elif s.missing is not None:
            note = (
                f"depends on the device's flags: {_describe(shown[1], None)} "
                f"{_witness(shown[0])}; not reached {_witness(s.missing)}"
            )
        else:  # alike in every run of its kind, but not every setting was run
            note = (
                f"{_describe(shown[1], None)} in every {self.kind} flag setting run "
                f"({_witness(shown[0])}); not every setting was run"
            )
        return replace(shown[1], conditions=shown[1].conditions + (note,))


class _Merge:
    """The run tree's runs, merged as they end (no run is kept: memory is one manifest's)."""

    def __init__(self, manifest: Manifest) -> None:
        self.manifest = manifest
        self.installing = _Records("installing")
        self.refusing = _Records("refusing")
        self.runs = 0
        self.first_run: tuple[str, ...] = ()
        # every distinct refusal and the first run that gave it (the first few shown)
        self.reasons: dict[str, tuple[str, ...]] = {}
        # every note, the first run that has it, how many runs have it, and a run without it
        self.notes: dict[str, list[Any]] = {}
        self.parents: dict[int, Element] = {}
        self.removed_run = 0
        self.removed_run_with: tuple[str, ...] | None = None

    def add(self, trues: tuple[str, ...], run: Replay) -> None:
        self.runs += 1
        if self.runs == 1:
            self.first_run = trues
        if run.install_error is None:
            self.installing.add(trues, run)
        else:
            self.refusing.add(trues, run)
            self.reasons.setdefault(run.install_error, trues)
        self.parents.update(run._parents)
        if run.removed_run > self.removed_run:
            self.removed_run, self.removed_run_with = run.removed_run, trues
        have = set(run._notes)
        for n in run._notes:
            entry = self.notes.get(n)
            if entry is None:
                # every earlier run did not have it
                self.notes[n] = [trues, 1, self.first_run if self.runs > 1 else None]
            else:
                entry[1] += 1
        for n, entry in self.notes.items():
            if n not in have and entry[2] is None:
                entry[2] = trues

    def _reasons(self) -> str:
        shown = [
            f"{_witness(w)}: {why}"
            for why, w in list(self.reasons.items())[:_REASONS_SHOWN]
        ]
        if len(self.reasons) > _REASONS_SHOWN:
            shown.append(f"and {len(self.reasons) - _REASONS_SHOWN} other reason(s)")
        return "; ".join(shown)

    def result(self, capped: str | None) -> Replay:
        out = Replay()
        out.capped = capped
        out._parents = self.parents
        out.removed_run, out.removed_run_with = self.removed_run, self.removed_run_with
        if self.installing.runs:
            out._refused_only = set(self.refusing.seen) - set(self.installing.seen)
        records = self.installing if self.installing.runs else self.refusing
        for root in self.manifest.roots:
            for e in root.iter():
                s = records.seen.get(id(e))
                if s is not None:
                    out.dispatched.append(records.record(s, capped is not None))
        if self.reasons:
            if self.installing.runs or capped is not None:
                # some setting installs, or not every setting was run: no refusal is certain
                out.conditional_install_error = self._reasons()
            elif len(self.reasons) == 1:
                out.install_error = next(iter(self.reasons))
            else:
                out.install_error = (
                    f"every flag setting refuses the install: {self._reasons()}"
                )
        for n, (has, count, lacks) in self.notes.items():
            if count == self.runs:
                out.note(n)
            else:
                out.note(f"{n} ({_witness(has)}; not {_witness(lacks)})")
        if capped is not None:
            out.note(capped)
        return out


def _never(name: str) -> bool:
    raise AssertionError(f"a manifest with no flag guard asked for {name!r}")


def _replay(manifest: Manifest, ask: Callable[[str], bool] | None) -> Replay:
    """One dispatch run, for one setting of the flags (``ask``); None: the manifest has none.

    What the parsers see is the pulled stream (stream.pulled_stream): XmlBlock's removals, the
    visible root, and where pulling fails. The lite parse pulls all of it first; the full parse
    then reads it, its Validator naming tags as it goes.
    """
    out = Replay()
    flags = ask if ask is not None else _never
    pulled = S.pulled_stream(manifest, flags)
    out.removed_run = (
        pulled.removed_run
    )  # every parse pulls the stream, unless it stops early

    def pulled_upto(stop: int) -> None:
        """Count the removals before ``stop``, where the lite parse stopped (no later recursion)."""
        out.removed_run = max(
            (n for o, n in pulled.removal_runs if o <= stop), default=0
        )

    root = pulled.root
    if root is None:
        out.install_error = (
            pulled.failure
            if pulled.failure is not None
            else (
                "the parser never returns: an element XmlBlock removes has no end (its skip loop "
                "spins on END_DOCUMENT)"
                if pulled.hang is not None
                else 'no root element: no start tag survives ("No start tag found")'
            )
        )
        return out
    fail_ord: list[int | None] = [
        None
    ]  # where this replay's own refusal stands (an ordinal)
    cur_ord: list[int] = [-1]
    owners: dict[str, Any] = _SPEC["owners"]
    handlers: dict[str, Any] = _SPEC["handlers"]
    # the manifest's package, as the parser reads it: by name, no namespace (getAttributeValue)
    package_read = R.by_name_text(root, None, "package")
    package = package_read if isinstance(package_read, str) else None
    first_seen: dict[tuple[int, str], tuple[str, ...]] = {}
    # the targetSdkVersion as parsed so far: none yet is 0 (PackageImpl default, ParsingUtils:54)
    target: list[int] = [0]
    enabled: list[bool] = [
        False
    ]  # deferred errors enabled (the first <uses-sdk> parsed)
    deferred: dict[str, str | None] = (
        {}
    )  # change id -> message, or None: checked and disabled
    activities: set[str | None] = set()  # only asked "is it in": no order to keep
    unknown_activity = [
        False
    ]  # an activity whose android:name this host could not read
    keysets_open: list[Element] = []
    capped = sum(e.dropped_descendants for e in root.iter())
    for e in root.iter():
        for c in e.children:
            out._parents[id(c)] = e
    if capped:
        out.note(
            f"{capped} element(s) nested past the depth this tool parses were not replayed "
            "(see depth_capped): a handler that leaves its subtree passes them to a loop above"
        )

    def record(d: Dispatched) -> None:
        out.dispatched.append(d)

    def skip_subtree(e: Element, because: str, conds: tuple[str, ...]) -> None:
        for c in e.children:
            for x in c.iter():
                record(
                    Dispatched(
                        x, "skipped", None, None, because=because, conditions=conds
                    )
                )
                if x.ordinal is not None:  # skipCurrentTag pulls it through next()
                    cur_ord[0] = max(cur_ord[0], x.ordinal)

    def fail(why: str) -> None:
        if out.install_error is None:
            out.install_error = why
            fail_ord[0] = cur_ord[0]

    def defer(change: str, why: str) -> None:
        """``ParseTypeImpl.deferError``."""
        if enabled[0]:
            if change in deferred:
                return  # already checked and found disabled
            if target[0] > _GATES[change]:
                fail(
                    f"{why} — an error for targetSdkVersion above {_GATES[change]} "
                    f"(this one: {target[0]})"
                )
            else:
                deferred[change] = None
        else:
            deferred.setdefault(change, why)

    def enable(new_target: int) -> None:
        """``ParseTypeImpl.enableDeferredError``: every stored change re-checked."""
        target[0], enabled[0] = new_target, True
        for change, why in reversed(list(deferred.items())):
            if new_target > _GATES[change]:
                fail(
                    f"{why or change} — an error for targetSdkVersion above "
                    f"{_GATES[change]} (a <uses-sdk> sets {new_target})"
                )
                return
            deferred[change] = None

    def text(e: Element, loop: _Loop) -> None:
        if e.text and owners[loop.owner].get("text") == "error":
            fail(
                f"text inside <{loop.owner}> ({owners[loop.owner]['site']}): the parse throws"
            )

    def resolve(sub: Any, e: Element, loop: _Loop, conds: list[str]) -> Any:
        if isinstance(sub, str) or "subtree" in sub:
            return sub
        cond = sub["if"]
        if "first" in cond:
            key = (id(loop.element), cond["first"])
            if key not in first_seen:
                first_seen[key] = tuple(conds)
                return resolve(sub["then"], e, loop, conds)
            return resolve(sub["else"], e, loop, conds)
        if "attr_int_lt_sdk" in cond:
            name = cond["attr_int_lt_sdk"]
            v = R.get_int(e, ATTR[name], -1)
            if isinstance(v, R.Throws):
                threw(e, name, v)
                return resolve(sub["else"], e, loop, conds)
            if isinstance(v, R.Unresolved):
                conds.append(
                    f"android:{name} is {v.why}: below {BASELINE_SDK} the handler records "
                    "nothing and leaves its subtree"
                )
                return resolve(sub["else"], e, loop, conds)
            holds = (
                v != -1 and v < BASELINE_SDK
            )  # -1: not set (ParsedPermissionUtils:75-76)
            return resolve(sub["then"] if holds else sub["else"], e, loop, conds)
        if "target_sdk_lt" in cond:
            holds = target[0] < cond["target_sdk_lt"]
            return resolve(sub["then"] if holds else sub["else"], e, loop, conds)
        if "package_is" in cond:
            holds = package == cond["package_is"]
            return resolve(sub["then"] if holds else sub["else"], e, loop, conds)
        if "aconfig" in cond:
            conds.append(
                f"platform flag {cond['aconfig']} on (off: the element is skipped)"
            )
            return resolve(sub["then"], e, loop, conds)
        raise ValueError(f"unknown condition {cond}")

    def uses_sdk(e: Element) -> None:
        # parseUsesSdk (PPU:1730-1760): peekValue — a string is a codename, which a release
        # platform refuses (computeMin/TargetSdkVersion); no targetSdkVersion: the min (default 1)
        lo = R.peek_int(e, ATTR["minSdkVersion"])
        if threw(e, "minSdkVersion", lo):
            return
        hi = R.peek_int(e, ATTR["targetSdkVersion"])
        if threw(e, "targetSdkVersion", hi):
            return

        # an Unresolved SDK value (no table, an entry this host does not decode, a value the
        # device's locale decides): not judged — taken as absent, never a codename — and SAID, in
        # the replay's `incomplete`, since the target it would set gates the deferred errors
        for label, v in (("minSdkVersion", lo), ("targetSdkVersion", hi)):
            if isinstance(v, R.Unresolved):
                note = (
                    f"android:{label} on <uses-sdk> at line {e.line} is {v.why}: the SDK checks "
                    "and the target the deferred errors use were not judged from it"
                )
                out.note(note)
        if isinstance(lo, R.Unresolved):
            lo = None
        if isinstance(hi, R.Unresolved):
            hi = None
        for label, v in (("minSdkVersion", lo), ("targetSdkVersion", hi)):
            if isinstance(v, str):
                fail(
                    f"android:{label} is a codename ({v}): a release platform refuses it "
                    "(INSTALL_FAILED_OLDER_SDK, computeTargetSdkVersion)"
                )
                return
        # computeMinSdkVersion (FrameworkParsingPackageUtils:302-310): a release platform refuses
        # a minimum above its own SDK — an unresolved reference's id (2130771968...) included
        if isinstance(lo, int) and lo > BASELINE_SDK:
            fail(
                f'android:minSdkVersion is {lo}, above SDK {BASELINE_SDK}: "Requires newer sdk '
                'version" (INSTALL_FAILED_OLDER_SDK, computeMinSdkVersion)'
            )
            return
        minimum = 1 if lo is None else lo
        enable(minimum if hi is None else hi)  # type: ignore[arg-type]

    def threw(e: Element, attr: str, v: object) -> bool:
        """Fail the parse at ``e`` when its read of android:``attr`` throws."""
        if isinstance(v, R.Throws):
            fail(
                f"android:{attr} on <{e.tag}> at line {e.line} is {v.why}: the parse throws"
            )
            return True
        return False

    def component_reads(e: Element, effect: str, conds: list[str]) -> None:
        """Fail where the component's handler fails on its targetActivity / name reads.

        An alias reads targetActivity first (ParsedActivityUtils:267-296,
        getNonConfigurationString allowing Configuration.NATIVE_CONFIG_VERSION as a Java mask),
        then — as every component — android:name (ParsedComponentUtils:47-56,
        getNonConfigurationString(name, 0)): both resolve references on the default config.
        """
        if effect == "activity-alias":
            raw = R.non_config_string(
                e, ATTR["targetActivity"], R.NATIVE_CONFIG_VERSION
            )
            if isinstance(raw, R.Throws):
                threw(e, "targetActivity", raw)
                return
            if isinstance(raw, R.Unresolved):
                conds.append(
                    f"android:targetActivity is {raw.why}: whether its target is declared "
                    "before it is not known"
                )
            elif raw is None:
                fail(
                    f"<activity-alias> at line {e.line} does not specify "
                    "android:targetActivity (null: absent, or a reference varying with the "
                    "configuration)"
                )
                return
            else:
                target = _class_name(package, raw)
                if target is None:
                    fail(
                        f"<activity-alias> at line {e.line}: empty class name in package"
                    )
                    return
                if target not in activities:
                    if unknown_activity[0]:
                        conds.append(
                            f"its target activity {target} is declared before it (an earlier "
                            "activity's android:name is not known)"
                        )
                    else:
                        fail(
                            f"<activity-alias> at line {e.line}: its target activity "
                            f"{target} is not declared before it"
                        )
                        return
        name = R.non_config_string(e, ATTR["name"])
        if isinstance(name, R.Throws):
            threw(e, "name", name)
        elif isinstance(name, R.Unresolved):
            conds.append(f"android:name is {name.why}")
        elif not name:
            fail(
                f"<{e.tag}> at line {e.line} does not specify android:name (empty, absent, or "
                "a reference varying with the configuration)"
            )
        elif _class_name(package, name) == _APP_DETAILS_ACTIVITY:
            fail(f"<{e.tag}> at line {e.line} has an invalid android:name: {name}")

    def permission_request(e: Element, conds: list[str]) -> str | None:
        """Why a read <uses-permission> requests nothing (PPU:1389-1494), or None.

        In the parser's order: every attribute first — android:name (getNonResourceString,
        :1396), min/maxSdkVersion (parseMinOrMaxSdkVersion, :1399-1405), requiredFeature /
        requiredNotFeature (getNonConfigurationString, :1407-1421), usesPermissionFlags (getInt,
        :1424); a read that throws fails the parse there — then its children
        (feature_conditions), then the returns on the name and the SDK range.
        """
        name = R.non_resource_string(e, ATTR["name"])
        if threw(e, "name", name):
            return "the parse throws on it"
        bounds, sdk_conds = [], []
        for attr, default in (
            ("minSdkVersion", -(1 << 31)),
            ("maxSdkVersion", (1 << 31) - 1),
        ):
            v = R.min_or_max_sdk(e, ATTR[attr], default)
            if threw(e, attr, v):
                return "the parse throws on it"
            if isinstance(v, R.Unresolved):
                sdk_conds.append(
                    f"android:{attr} is {v.why}: outside it nothing is requested"
                )
                v = default
            assert isinstance(v, int)
            bounds.append(v)
        for attr, has in (("requiredFeature", "has"), ("requiredNotFeature", "lacks")):
            feature = R.non_config_string(e, ATTR[attr])
            if threw(e, attr, feature):
                return "the parse throws on it"
            if isinstance(feature, R.Unresolved):
                conds.append(f"android:{attr} is {feature.why}")
            elif feature is not None:
                conds.append(f"the device {has} feature {feature!r} (android:{attr})")
        if threw(
            e,
            "usesPermissionFlags",
            R.get_int(e, ATTR["usesPermissionFlags"], 0),
        ):
            return "the parse throws on it"
        if isinstance(name, R.Unresolved):
            return (
                f"its android:name is {name.why} (what the device makes of it is not verified): "
                "nothing is counted as requested"
            )
        if name is None:
            return "its android:name is not a plain string (getNonResourceString): nothing is requested"
        # the SDK conditions after the feature ones, as they were stated before the reads were
        # put in the parser's order; none on a record that requests nothing
        conds.extend(sdk_conds)
        lo, hi = bounds
        if not lo <= BASELINE_SDK <= hi:
            return f"requested only on SDK {lo}..{hi}, not on {BASELINE_SDK}"
        return None  # its required-(not-)feature children: after its loop (feature_conditions)

    def feature_conditions(e: Element, start: int) -> None:
        """Add the features a <uses-permission> requires to its record (PPU:1444-1494).

        From the required-feature / required-not-feature records ITS loop dispatched — at any
        depth below it, as the replay reached them (a nested one too; device-verified) — never
        from its XML children.
        """
        at = start - 1  # the <uses-permission> record itself
        own = set(out.dispatched[at].conditions)
        conds = []
        for d in out.dispatched[start:]:
            if not (
                d.outcome == "read"
                and d.owner_element is e
                and d.effect in ("required-feature", "required-not-feature")
            ):
                continue
            # the name its handler read: TypedArray.getString — the TYPED value, never rawValue
            name = R.get_string(d.element, ATTR["name"])
            shown = (
                f"whose android:name is {name.why}"
                if isinstance(name, (R.Unresolved, R.Throws))
                else repr(name)
            )
            text = (
                f"the device {'has' if d.effect == 'required-feature' else 'lacks'} feature "
                f"{shown}"
            )
            extra = [c for c in d.conditions if c not in own]  # e.g. its own flag
            conds.append(text + (f" (only if: {'; '.join(extra)})" if extra else ""))
        if conds:
            assert out.dispatched[at].element is e
            out.dispatched[at] = replace(
                out.dispatched[at],
                conditions=out.dispatched[at].conditions + tuple(conds),
            )

    def intent_name(e: Element) -> None:
        # action / category: read by name; absent fails the parse, empty is a deferred error
        # (ParsedIntentInfoUtils:112-133)
        value = R.by_name_text(e, R.ANDROID, "name")
        if isinstance(value, R.Throws):
            fail(
                f"<{e.tag}> at line {e.line}: its android:name read throws ({value.why})"
            )
        elif value is None:
            fail(f"<{e.tag}> at line {e.line} has no android:name: the parse fails")
        elif value == "":
            defer(
                "EMPTY_INTENT_ACTION_CATEGORY",
                f"<{e.tag}> at line {e.line} has an empty android:name",
            )

    def component_done(e: Element, effect: str, start: int) -> None:
        """Apply the checks the parser makes once a component's subtree is parsed."""
        if effect not in _COMPONENTS_WITH_EXPORTED_CHECK or R.styleable(
            e, ATTR["exported"]
        ):
            return
        # an intent filter (for an activity, receiver or alias: one with an action) and no
        # explicit exported: S+ refuses it (ParsedActivityUtils:497-505, ParsedServiceUtils:182)
        mine = out.dispatched[start:]
        filters = {
            id(d.element)
            for d in mine
            if d.outcome == "read"
            and d.effect == "intent-filter"
            and d.owner_element is e
        }
        if effect in _FILTERS_NEED_ACTION:
            filters = {
                id(d.owner_element)
                for d in mine
                if d.outcome == "read"
                and d.effect == "action"
                and d.owner_element is not None
                and id(d.owner_element) in filters
            }
        if filters:
            defer(
                "MISSING_EXPORTED_FLAG",
                f"<{e.tag}> at line {e.line} has intent filters and no android:exported",
            )

    def lite_names() -> bool:
        """Replay the lite parse's first refusals, its name checks (ApkLiteParseUtils:900-985).

        parsePackageSplitNames: <manifest>'s package (by name, no namespace) through validateName
        — a '.' required, a file name — unless it is "android"; a null package throws in it (a
        NullPointerException the lite parse turns into a failed parse, ALPU:400-403); a non-empty
        split through validateName with neither. parseRequiredSplitTypes: android:requiredSplitTypes
        then android:splitTypes, unless empty — trimmed, split on ',', every part trimmed through
        validateName with a file name. An Unresolved text (a finite float's or a dimension's) begins
        with '-' or a digit: a bad character. True: the parse failed.
        """
        bad_text = "a bad character (the text begins with '-' or a digit)"
        why = None
        if isinstance(package_read, R.Throws):
            why = f"<manifest> package is {package_read.why}: the parse fails"
        elif package_read is None:
            why = (
                "<manifest> has no package (absent, or a value Java renders as null): "
                "validateName(null) throws a NullPointerException and the parse fails "
                "(INSTALL_PARSE_FAILED_UNEXPECTED_EXCEPTION)"
            )
        elif isinstance(package_read, R.Unresolved):
            why = (
                f'<manifest> package is {package_read.why}, {bad_text}: "Invalid manifest '
                'package" (INSTALL_PARSE_FAILED_BAD_PACKAGE_NAME)'
            )
        elif package_read != "android":
            err = _validate_name(package_read, True, True)
            if err is not None:
                why = (
                    f'<manifest> package {package_read!r}: "Invalid manifest package: {err}" '
                    "(INSTALL_PARSE_FAILED_BAD_PACKAGE_NAME)"
                )
        if why is None:
            split = R.by_name_text(root, None, "split")
            if isinstance(split, R.Throws):
                why = f"<manifest> split is {split.why}: the parse fails"
            elif isinstance(split, R.Unresolved):
                why = (
                    f'<manifest> split is {split.why}, {bad_text}: "Invalid manifest split" '
                    "(INSTALL_PARSE_FAILED_BAD_PACKAGE_NAME)"
                )
            elif split:  # "" is no split (ALPU:928-929)
                err = _validate_name(split, False, False)
                if err is not None:
                    why = (
                        f'<manifest> split {split!r}: "Invalid manifest split: {err}" '
                        "(INSTALL_PARSE_FAILED_BAD_PACKAGE_NAME)"
                    )
                else:
                    note = (
                        f"<manifest> names split {split!r}: this APK is that split, not a base — "
                        'replayed as a base (installed alone, the installer refuses it: "Full '
                        'install must include a base package", PackageInstallerSession:4690-4693)'
                    )
                    out.note(note)
        split_types = (
            (
                "requiredSplitTypes",
                R.by_name_text(root, R.ANDROID, "requiredSplitTypes"),
            ),
            ("splitTypes", R.by_name_text(root, R.ANDROID, "splitTypes")),
        )
        for attr, v in split_types:
            if why is not None:
                break
            if isinstance(v, R.Throws):
                why = f"android:{attr} on <manifest> is {v.why}: the parse fails"
            elif isinstance(v, R.Unresolved):
                why = (
                    f'android:{attr} on <manifest> is {v.why}, {bad_text}: "Invalid manifest '
                    'split types" (INSTALL_PARSE_FAILED_MANIFEST_MALFORMED)'
                )
            elif v:  # TextUtils.isEmpty
                err = _split_types_error(v)
                if err is not None:
                    why = (
                        f'android:{attr} on <manifest> is {v!r}: "Invalid manifest split '
                        f'types: {err}" (INSTALL_PARSE_FAILED_MANIFEST_MALFORMED)'
                    )
        if why is None:
            return False
        out.install_error = why
        record(Dispatched(root, "error", None, None, because=why))
        return True

    def lite_uses_sdk() -> bool:
        """Replay the lite parse's <uses-sdk> check, which runs (and refuses) BEFORE the full parse.

        ApkLiteParseUtils:743-800: every <uses-sdk> child of <manifest> (depth 2), read BY NAME
        (XmlBlock.getAttributeValue — a reference is "@<decimal>"); Integer.parseInt, else a
        codename; computeTargetSdkVersion then computeMinSdkVersion on a release platform. The lite
        parse has no featureFlag skip; XmlBlock's binary-XML flag removal applies. True: it failed.
        """

        def removed(
            x: Element,
        ) -> bool:  # the device's XmlBlock removed it (this setting)
            return x.ordinal in pulled.removed

        def lite_name(x: Element) -> bool:
            """Replay the lite parse's getName of ``x``. False: it throws; the parse fails."""
            if x.ordinal is not None:
                cur_ord[0] = x.ordinal
            if not x.tag_unreadable:
                return True
            fail(
                f"the element at line {x.line}: the lite parse's getName of its tag throws "
                "(nativeGetString: IndexOutOfBoundsException), a failed parse "
                "(ApkLiteParseUtils:400-403, INSTALL_PARSE_FAILED_UNEXPECTED_EXCEPTION)"
            )
            record(Dispatched(x, "error", None, None, because=out.install_error))
            return False

        def lite_application(app: Element) -> bool:
            """Replay the lite parse's getName reads under one <application>. True: it failed.

            ApkLiteParseUtils:526-722: every direct child; <processes>' children; a device-admin
            <receiver>'s children up to its device_admin meta-data.
            """
            app_bind = (
                R.by_name_text(app, R.ANDROID, "permission") == _BIND_DEVICE_ADMIN
            )
            for c in app.children:
                if removed(c):
                    continue
                if not lite_name(c):
                    return True
                if c.tag == "processes":  # :700-720
                    for x in c.children:
                        if not removed(x) and not lite_name(x):
                            return True
                elif c.tag == "receiver" and (  # isDeviceAdminReceiver, :866-900
                    app_bind
                    or R.by_name_text(c, R.ANDROID, "permission") == _BIND_DEVICE_ADMIN
                ):
                    for x in c.children:
                        if removed(x):
                            continue
                        if not lite_name(x):
                            return True
                        if (
                            x.tag == "meta-data"
                            and R.by_name_text(x, R.ANDROID, "name")
                            == _DEVICE_ADMIN_META_DATA
                        ):
                            break  # `!hasDeviceAdminReceiver && ...`: no getName after it
                elif c.tag == "uses-static-library" and any(
                    x.tag_unreadable for x in c.iter() if x is not c
                ):
                    # parseAdditionalCertificates (:828-850) reads every descendant's name, but
                    # only for a library that passes the lite checks before it (not replayed)
                    note = (
                        f"<uses-static-library> at line {c.line}: a tag below it does not read; the "
                        "lite parse reads them only for a library that passes its checks (not "
                        "replayed), so whether the parse fails there is not judged"
                    )
                    out.note(note)
            return False

        # the lite loop, in document order (ApkLiteParseUtils:487-800): getName of every depth-2
        # element, then the <application> or <uses-sdk> it is
        for e in root.children:
            if removed(e):
                continue
            if not lite_name(e):
                return True
            if e.tag == "application":
                if lite_application(e):
                    return True
                continue
            if e.tag != "uses-sdk":
                continue
            min_s = R.by_name_text(e, R.ANDROID, "minSdkVersion")
            target_s = R.by_name_text(e, R.ANDROID, "targetSdkVersion")
            for label, v in (("minSdkVersion", min_s), ("targetSdkVersion", target_s)):
                if isinstance(v, R.Throws):
                    fail(
                        f"the lite parse's by-name read of android:{label} on <uses-sdk> at "
                        f"line {e.line} throws ({v.why})"
                    )
            if out.install_error is None:
                lite_sdk_check(e, min_s, target_s)  # type: ignore[arg-type]
            if out.install_error is not None:
                record(Dispatched(e, "error", None, None, because=out.install_error))
                return True
        return False

    def lite_sdk_check(
        e: Element,
        min_s: str | R.Unresolved | None,
        target_s: str | R.Unresolved | None,
    ) -> None:
        """ApkLiteParseUtils:750-798 over the two strings (DEFAULT_MIN_SDK_VERSION 1).

        An Unresolved text is a float/dimension/fraction's Float.toString: non-empty and never an
        integer, so a codename whatever its digits — the refusal is certain, its text is not.
        """

        def parse(v: str | R.Unresolved) -> int | None:
            return (
                None
                if isinstance(v, R.Unresolved)
                else R._java_parse_int(R._utf16(v), 10)
            )

        def shown(v: str | R.Unresolved) -> str:
            return f"<{v.why}>" if isinstance(v, R.Unresolved) else v

        min_ver, min_code, min_assigned = 1, None, False
        if min_s:
            parsed = parse(min_s)
            if parsed is None:
                min_code, min_assigned = shown(min_s), True
            else:
                min_ver, min_assigned = parsed, True
        target_code = None
        if target_s:
            if parse(target_s) is None:
                target_code = shown(target_s)
                if not min_assigned:
                    min_code = target_code
        else:
            target_code = min_code
        where = f"<uses-sdk> at line {e.line}, the lite parse (ApkLiteParseUtils)"
        # computeTargetSdkVersion / computeMinSdkVersion on a release platform (no codenames)
        if target_code is not None:
            fail(
                f'{where}: "Requires development platform {target_code} but this is a release '
                'platform." (INSTALL_FAILED_OLDER_SDK)'
            )
        elif min_code is not None:
            fail(
                f'{where}: "Requires development platform {min_code} but this is a release '
                'platform." (INSTALL_FAILED_OLDER_SDK)'
            )
        elif min_ver > BASELINE_SDK:
            fail(
                f'{where}: "Requires newer sdk version #{min_ver} (current version is '
                f'#{BASELINE_SDK})" (INSTALL_FAILED_OLDER_SDK)'
            )

    def tag_read(e: Element) -> bool:
        """XmlBlock.getName: the tag's Java string. False: it throws here and the parse fails."""
        if e.tag_unreadable:
            fail(
                f"the element at line {e.line}: its tag name does not read "
                "(XmlBlock.getName -> nativeGetString: IndexOutOfBoundsException): the parse fails"
            )
            record(Dispatched(e, "error", None, None, because=out.install_error))
            return False
        styled = (["its tag name"] if e.tag_styled else []) + [
            f"android:{a.name}" if a.ns == R.ANDROID else a.name
            for a in e.attributes
            if a.raw_styled or a.typed_styled
        ]
        styled += [
            f"the TypedArray value of {resid}"
            for resid, row in (e.rows() or {}).items()
            if _has_styled_string(row)
        ]
        if styled:
            note = (
                f"<{e.tag}> at line {e.line}: {', '.join(styled)} is a styled string, read as "
                "its text; if the device's style application throws on it, the parse fails "
                "there (not replayed)"
            )
            out.note(note)
        return True

    def walk(e: Element, depth: int, loop: _Loop, inherited: tuple[str, ...]) -> None:
        if out.install_error is not None:
            return
        spec = owners[loop.owner]
        if e.ordinal is not None:
            cur_ord[0] = e.ordinal
        conds = list(inherited)
        present = True
        removed = "its flag removes it"
        if e.ordinal in pulled.removed:  # XmlBlock removed it before the parser saw it
            present, removed = False, "XmlBlock removes it (its binary-XML flag)"
        if spec.get("feature_flag"):
            # AconfigFlags.skipCurrentElement/skip (AconfigFlags.java:308-360): getAttributeValue
            # (the raw string first; TYPE_NULL throws), null never skips. String.strip, a leading
            # "!" negates, strip again; the name's value — false when undefined — skips the element
            # iff it equals the negation. manifestFlagging is fixed on in this platform
            # (android.content.res.manifest_flagging: is_fixed_read_only, ENABLED from ap3a through
            # bp1a and the releases inheriting it), so the skip always applies; the two readings
            # are every flag true and every flag false.
            flag_read = R.by_name_text(e, R.ANDROID, "featureFlag")
            if isinstance(flag_read, R.Throws):
                fail(
                    f"<{e.tag}> at line {e.line}: its android:featureFlag read throws "
                    f"({flag_read.why})"
                )
            elif flag_read is not None:
                if isinstance(flag_read, R.Unresolved):
                    # a float/dimension/fraction's Float.toString: no "!", and never a flag name
                    neg, name, shown = False, None, flag_read.why
                else:
                    neg, name = _feature_flag_name(flag_read)
                    shown = repr(_shown_name(flag_read))
                if name is not None and _is_aconfig_flag_name(name):
                    # a flag a device can have, whose value this setting answers
                    present = present and not S.skip(name, neg, flags)
                    conds.append(
                        f"the device's aconfig flag {_shown_name(name)!r} is "
                        f"{'false' if neg else 'true'} (otherwise this element and its subtree "
                        "are skipped)"
                    )
                else:
                    # no device has a flag of this name: it reads false on every device. Not
                    # negated: false == negated, always skipped; negated: false != true, kept
                    if not neg:
                        present, removed = False, "its flag removes it on every device"
                        conds.append(
                            f"android:featureFlag ({shown}) names no aconfig flag (no device "
                            "has one of that name: it reads false), so the device skips this "
                            "element and its subtree"
                        )

        if not present:
            record(
                Dispatched(
                    e,
                    "skipped",
                    loop.owner,
                    loop.element,
                    because=removed,
                    conditions=tuple(conds),
                )
            )
            skip_subtree(e, f"inside <{e.tag}>, which its flag removes", tuple(conds))
            return
        # the loop's getName, after XmlBlock's removal and skipCurrentElement (PPU:795 and the
        # component loops): a removed or skipped element's tag is never read
        if not tag_read(e):
            return
        handler_id = spec["children"].get(e.tag)
        if handler_id is None:
            policy = spec["unknown"]
            if policy == "skip":
                record(
                    Dispatched(
                        e,
                        "skipped_unknown",
                        loop.owner,
                        loop.element,
                        because=f"unknown to <{loop.owner}>'s loop ({spec['site']})",
                        conditions=tuple(conds),
                    )
                )
                skip_subtree(
                    e,
                    f"inside <{e.tag}>, which <{loop.owner}>'s loop skipped",
                    tuple(conds),
                )
                return
            if policy == "error":
                record(
                    Dispatched(
                        e, "error", loop.owner, loop.element, conditions=tuple(conds)
                    )
                )
                fail(
                    f"<{e.tag}> under <{loop.owner}> ({spec['site']}): the parse fails"
                )
                return
            record(
                Dispatched(
                    e,
                    "ignored_unknown",
                    loop.owner,
                    loop.element,
                    conditions=tuple(conds),
                )
            )
            text(e, loop)
            for c in e.children:
                walk(c, depth + 1, loop, tuple(conds))
            return
        h = handlers[handler_id]
        sub = resolve(h["subtree"], e, loop, conds)
        effect = h.get("effect")
        because = None
        if not isinstance(sub, str):  # a branch that records nothing
            sub, effect = sub["subtree"], sub["effect"]
            because = "its handler returns early and records nothing"
        by_value = False
        if effect == "uses-permission":
            because = permission_request(e, conds)
            if because is not None:
                effect, by_value = None, True
        elif effect in ("action", "category"):
            intent_name(e)
        elif effect in ("required-feature", "required-not-feature"):
            # TypedArray.getString of android:name; empty or absent -> input.error, which the
            # <uses-permission> loop returns at once: the install fails (PPU:1449-1475, 1580-1608)
            feature = R.get_string(e, ATTR["name"])
            if threw(e, "name", feature):
                pass
            elif feature is None or feature == "":
                fail(
                    f'<{e.tag}> at line {e.line} has an empty or missing android:name ("Feature name is missing '
                    f'from <{e.tag}> tag."): the parse fails'
                )
        elif effect == "install-constraints":
            fail(
                f"<install-constraints> at line {e.line}: this AOSP refuses it for any package "
                "not on the device's install-constraints allowlist (InstallConstraintsTagParser)"
            )
        elif effect == "key-set" and keysets_open:
            fail(
                f"<key-set> at line {e.line} inside another <key-set>: improperly nested"
            )
        elif h.get("effect") in _PARSE_COMPONENT:
            # the HANDLER's effect: <permission> runs parseComponent before its maxSdkVersion
            # return (ParsedPermissionUtils:62-78), so a branch recording nothing still reads it
            component_reads(e, h["effect"], conds)
        if out.install_error is not None:  # this element is where the parse fails
            record(
                Dispatched(
                    e,
                    "error",
                    loop.owner,
                    loop.element,
                    handler=handler_id,
                    because=out.install_error,
                    conditions=tuple(conds),
                )
            )
            return
        if effect in ("activity", "activity-alias"):
            # an alias joins the parsed activities too (addActivity, PPU:2381): a later alias
            # may target it
            own = R.non_config_string(e, ATTR["name"])
            if isinstance(own, str):
                activities.add(_class_name(package, own))
            else:  # Unresolved: an activity of an unknown name
                unknown_activity[0] = True
        frozen = tuple(conds)
        record(
            Dispatched(
                e,
                "read",
                loop.owner,
                loop.element,
                handler=handler_id,
                effect=effect,
                because=because,
                conditions=frozen,
                by_value=by_value,
            )
        )
        start = len(out.dispatched)
        if effect == "uses-sdk":
            uses_sdk(e)
        if effect == "key-set":
            keysets_open.append(e)
        if sub == "skip":
            skip_subtree(
                e, f"<{e.tag}>'s handler skips its subtree ({h['site']})", frozen
            )
        elif sub == "leave":
            text(e, loop)
            for c in e.children:
                walk(c, depth + 1, loop, frozen)
        elif sub.startswith("owner:"):
            inner = _Loop(sub[len("owner:") :], e, depth)
            text(e, inner)
            for c in e.children:
                walk(c, depth + 1, inner, frozen)
            if effect is not None and out.install_error is None:
                component_done(e, effect, start)
            if h.get("effect") == "uses-permission":
                feature_conditions(e, start)
        else:
            raise ValueError(f"unknown subtree {sub!r}")
        if effect == "key-set":
            keysets_open.pop()

    if not tag_read(root):
        if root.ordinal is not None:
            pulled_upto(root.ordinal)
        return out
    if root.tag != _SPEC["root"]:
        if root.ordinal is not None:
            pulled_upto(root.ordinal)
        record(Dispatched(root, "error", None, None))
        out.install_error = f"the root element is <{root.tag}>, not <{_SPEC['root']}>"
        return out
    lite_failed = lite_names() or lite_uses_sdk()
    # the lite parse pulls the visible root's whole stream: a throw or a hang in it stops the
    # parse there, unless the lite parse refused before it (at an element no later)
    stream_end = pulled.failure_after if pulled.failure is not None else pulled.hang
    if (pulled.failure is not None or pulled.hang is not None) and (
        not lite_failed
        or (
            fail_ord[0] is not None
            and fail_ord[0] > (stream_end if stream_end is not None else -1)
        )
    ):
        out.install_error = (
            pulled.failure
            if pulled.failure is not None
            else "the parser never returns: an element XmlBlock removes has no end (its skip "
            "loop spins on END_DOCUMENT)"
        )
        record(Dispatched(root, "error", None, None, because=out.install_error))
        return out
    if lite_failed:
        if fail_ord[0] is not None:
            pulled_upto(fail_ord[0])
        return out
    if pulled.incomplete:
        for note in pulled.incomplete:
            out.note(note)
    h = handlers[_SPEC["root"]]
    record(
        Dispatched(
            root, "read", None, None, handler=_SPEC["root"], effect=h.get("effect")
        )
    )
    top = _Loop(h["subtree"][len("owner:") :], root, 1)
    text(root, top)
    for c in root.children:
        walk(c, 2, top, ())
    cur_ord[0] = (
        1 << 62
    )  # the checks after the loop: after every element the parse pulled
    if out.install_error is None and not any(
        d.outcome == "read" and d.effect in ("application", "instrumentation")
        for d in out.dispatched
    ):
        defer("MISSING_APP_TAG", "<manifest> has no <application> or <instrumentation>")
    # the full parse's Validator throws as it pulls (Validator.java:52-80): first, unless the
    # dispatch refused at an earlier element
    if pulled.validator_failure is not None:
        at = pulled.validator_failure_at
        # it throws in next(), before the dispatch reads that element: first at an equal one
        if out.install_error is None or (
            fail_ord[0] is not None and at is not None and fail_ord[0] >= at
        ):
            out.install_error = pulled.validator_failure
    return out
