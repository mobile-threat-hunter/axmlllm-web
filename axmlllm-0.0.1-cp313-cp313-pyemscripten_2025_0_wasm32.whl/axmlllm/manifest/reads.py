"""How the device's package parser reads one attribute — the two readers, not ``Element.attr()``.

* A styleable read (``obtainAttributes`` then ``TypedArray``) keys on the attribute's ResID and
  takes what AOSP's RetrieveAttributes walk takes (``Element.styleable_reads``, run natively) — a
  string name is never consulted. A reference is resolved through the app's resource table, as
  the TypedArray's AssetManager does.
* A by-name read (``XmlResourceParser.getAttributeValue(ns, name)``, ResXMLParser::
  indexOfAttribute) takes the first attribute whose namespace and name STRINGS match — the ResID
  is never consulted — and gets its raw string first.

``Element.attr()`` mixes the two (ResID first, then name, through a curated map): a manifest can
make it read an attribute neither reader takes. Each function here says what a reader returns,
``Throws`` where the device's read throws (its parse then fails), or ``Unresolved`` with why when
this host cannot say (a reference with no table, a value that depends on the configuration).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .model import Attribute, Element
    from .resources import ResourceTable

ANDROID = "android"  # the model's name for the exact android namespace URI

# Res_value data types (ResourceTypes.h)
TYPE_NULL, TYPE_REFERENCE, TYPE_ATTRIBUTE, TYPE_STRING = 0x00, 0x01, 0x02, 0x03
TYPE_FIRST_INT, TYPE_LAST_INT = 0x10, 0x1F
TYPE_DYNAMIC_REFERENCE = 0x07


@dataclass(frozen=True)
class Throws:
    """The reader throws on this value (the device's parse fails here); ``why`` says what."""

    why: str


@dataclass(frozen=True)
class Unresolved:
    """The reader's value is not known on this host; ``why`` says what it depends on."""

    why: str


def styleable(element: Element, resid: int) -> Attribute | None:
    """Return the attribute a styleable read of ``resid`` takes, or None (the read gets no value)."""
    i = element.styleable_reads.get(f"0x{resid:08x}")
    return None if i is None else element.attributes[i]


def by_name(element: Element, ns: str | None, name: str) -> Attribute | None:
    """Return the attribute a by-name read takes: the first whose namespace and name strings match.

    ``ns`` is ``"android"`` (the exact android URI) or None (no namespace).
    """
    for a in element.attributes:
        if a.name == name and a.ns == ns:
            return a
    return None


def _signed(raw: int) -> int:
    return raw - (1 << 32) if raw >= 1 << 31 else raw


def _resolved(
    a: Attribute, table: ResourceTable | None
) -> tuple[int, int, str | None] | Unresolved:
    """Return (type, data, string) of the value a TypedArray holds for ``a`` (references resolved)."""
    if a.type_code in (TYPE_REFERENCE, TYPE_DYNAMIC_REFERENCE) and a.raw != 0:
        if table is None:
            return Unresolved(
                f"a reference (0x{a.raw:08x}) with no resource table loaded"
            )
        r = table.resolve(a.raw)
        if r is None:
            return Unresolved(f"a reference (0x{a.raw:08x}) the table does not resolve")
        if r.config_axes:
            return Unresolved(
                f"a reference (0x{a.raw:08x}) whose value varies with the device configuration"
            )
        if isinstance(r.value, bool):
            return (0x12, 0xFFFFFFFF if r.value else 0, None)
        if isinstance(r.value, int):
            return (0x10, r.value & 0xFFFFFFFF, None)
        if isinstance(r.value, str):
            return (TYPE_STRING, 0, r.value)
        return Unresolved(f"a reference (0x{a.raw:08x}) to a {r.type} value")
    if a.type_code == TYPE_ATTRIBUTE:
        return Unresolved(
            "a theme attribute (?attr), resolved against a theme at run time"
        )
    string = (
        a.raw_string
        if a.raw_string is not None
        else (
            a.value if a.type_code == TYPE_STRING and isinstance(a.value, str) else None
        )
    )
    return (a.type_code, a.raw, string)


def get_int(
    element: Element, resid: int, default: int, table: ResourceTable | None
) -> int | Unresolved | Throws:
    """Return ``TypedArray.getInt(resid, default)`` (TypedArray.java getInt).

    Int-range data; a string through convertValueToInt; any other type's text through it too —
    which always throws (Throws).
    """
    a = styleable(element, resid)
    if a is None:
        return default
    v = _resolved(a, table)
    if isinstance(v, Unresolved):
        return v
    type_, data, string = v
    if type_ == TYPE_NULL:
        return default
    if TYPE_FIRST_INT <= type_ <= TYPE_LAST_INT:
        return _signed(data)
    if string is not None:
        return _convert_value_to_int(string, default)
    # a float, dimension or fraction coerces to text like "1.5", "1.5dip", "50%": parseInt
    # throws on every one (device-verified with a float maxSdkVersion)
    return Throws(
        f"a value of type 0x{type_:02x}, whose text is no int (NumberFormatException)"
    )


def peek_int(element: Element, resid: int) -> int | str | None | Unresolved:
    """Return ``TypedArray.peekValue(resid)`` as parseUsesSdk reads it.

    The string (a codename) for a string, else the raw data (any other type), None when there is
    no value.
    """
    a = styleable(element, resid)
    if a is None:
        return None
    if a.type_code == TYPE_NULL:
        return None
    if a.type_code in (TYPE_REFERENCE, TYPE_DYNAMIC_REFERENCE, TYPE_ATTRIBUTE):
        # peekValue resolves references; a reference the parser reads as a codename string
        # (the device took "@2130771968" for one: INSTALL_FAILED_OLDER_SDK) is told as such
        return Unresolved(f"a reference (0x{a.raw:08x}) read as the SDK version")
    if a.type_code == TYPE_STRING:
        return a.raw_string if a.raw_string is not None else str(a.value)
    return _signed(a.raw)


def min_or_max_sdk(
    element: Element, resid: int, default: int, table: ResourceTable | None
) -> int | Unresolved:
    """``parseMinOrMaxSdkVersion``: an int-typed peeked value (references resolved), else default."""
    a = styleable(element, resid)
    if a is None:
        return default
    v = _resolved(a, table)
    if isinstance(v, Unresolved):
        return v
    type_, data, _ = v
    return _signed(data) if TYPE_FIRST_INT <= type_ <= TYPE_LAST_INT else default


def non_resource_string(element: Element, resid: int) -> str | None:
    """``TypedArray.getNonResourceString``: the raw string of a string-typed value, else None."""
    a = styleable(element, resid)
    if a is None or a.type_code != TYPE_STRING:
        return None
    return (
        a.raw_string
        if a.raw_string is not None
        else (a.value if isinstance(a.value, str) else None)
    )


def _utf16(s: str) -> list[str]:
    """Return ``s`` as Java sees it: UTF-16 code units (a supplementary char is two surrogates)."""
    b = s.encode("utf-16-le", "surrogatepass")
    return [chr(int.from_bytes(b[k : k + 2], "little")) for k in range(0, len(b), 2)]


def _java_digit(ch: str, radix: int) -> int:
    """Return ``Character.digit(char, radix)`` for one UTF-16 unit.

    A BMP decimal digit or a Latin letter (also full-width); a surrogate — half of a
    supplementary digit — is -1, as in Java.
    """
    import unicodedata

    if 0xD800 <= ord(ch) <= 0xDFFF:
        return -1
    if ch.isdecimal():
        d = unicodedata.decimal(ch)
    elif ch.isascii() and ch.isalpha():
        d = ord(ch.lower()) - ord("a") + 10
    elif "\uff21" <= ch <= "\uff3a" or "\uff41" <= ch <= "\uff5a":
        d = (ord(ch) - (0xFF21 if ch <= "\uff3a" else 0xFF41)) + 10
    else:
        return -1
    return d if d < radix else -1


def _java_parse_int(units: list[str], radix: int) -> int | None:
    """Return ``Integer.parseInt`` of these UTF-16 units, or None where Java throws.

    An optional sign, then digits only; NumberFormatException for empty, any other unit, or a
    value out of int range.
    """
    if not units:
        return None
    i, negative = 0, False
    if units[0] in "+-":
        negative, i = units[0] == "-", 1
        if len(units) == 1:
            return None
    value = 0
    for ch in units[i:]:
        d = _java_digit(ch, radix)
        if d < 0:
            return None
        value = value * radix + d
        if value > (1 << 31) - (0 if negative else 1):
            return None
    return -value if negative else value


def _int32(v: int) -> int:
    v &= 0xFFFFFFFF
    return v - (1 << 32) if v >= 1 << 31 else v


def _convert_value_to_int(s: str, default: int) -> int | Throws:
    """Return ``XmlUtils.convertValueToInt`` (XmlUtils.java:302-346), or Throws where Java throws.

    "-", then 0x / 0 (octal) / # prefixes, then ``Integer.parseInt`` of the rest times the sign.
    """
    if not s:
        return default
    u = _utf16(s)  # Java's charAt / length count UTF-16 units
    sign, index, base = 1, 0, 10
    if u[0] == "-":
        sign, index = -1, 1
    if index >= len(u):
        return Throws(f"{s!r}: StringIndexOutOfBounds in convertValueToInt")
    if u[index] == "0":
        if index == len(u) - 1:
            return 0
        if u[index + 1] in "xX":
            index, base = index + 2, 16
        else:
            index, base = index + 1, 8
    elif u[index] == "#":
        index, base = index + 1, 16
    parsed = _java_parse_int(u[index:], base)
    if parsed is None:
        return Throws(f"{s!r}: NumberFormatException in Integer.parseInt")
    return _int32(parsed * sign)


def get_boolean(
    element: Element, resid: int, default: bool, table: ResourceTable | None
) -> bool | Unresolved:
    """``TypedArray.getBoolean(resid, default)``: int-range data != 0, a string "1"/"true"/"TRUE"."""
    a = styleable(element, resid)
    if a is None:
        return default
    v = _resolved(a, table)
    if isinstance(v, Unresolved):
        return v
    type_, data, string = v
    if type_ == TYPE_NULL:
        return default
    if TYPE_FIRST_INT <= type_ <= TYPE_LAST_INT:
        return data != 0
    if string is not None:  # XmlUtils.convertValueToBoolean
        return default if string == "" else string in ("1", "true", "TRUE")
    # any other type is coerced to its text (a float, a dimension): never "1"/"true"/"TRUE"
    return False


def non_config_string(
    element: Element, resid: int, table: ResourceTable | None
) -> str | None | Unresolved:
    """Return ``TypedArray.getNonConfigurationString(resid, 0)`` (TypedArray.java:336-361).

    None when absent, null, or a value that varies with the configuration; a string's text; any
    other value's text (coerceToString) — an int as decimal or hex, a boolean as true / false.
    """
    a = styleable(element, resid)
    if a is None:
        return None
    if (
        a.type_code in (TYPE_REFERENCE, TYPE_DYNAMIC_REFERENCE)
        and a.raw != 0
        and table is not None
    ):
        r = table.resolve(a.raw)
        if r is not None and r.config_axes:
            return None  # its changing configurations are not allowed: null
    v = _resolved(a, table)
    if isinstance(v, Unresolved):
        return v
    type_, data, string = v
    if type_ == TYPE_NULL:
        return None
    if string is not None:
        return string
    if type_ == 0x12:
        return "true" if data != 0 else "false"
    if TYPE_FIRST_INT <= type_ <= TYPE_LAST_INT:
        return f"0x{data:08x}" if type_ == 0x11 else str(_signed(data))
    return Unresolved(f"the text of a value of type 0x{type_:02x}")
