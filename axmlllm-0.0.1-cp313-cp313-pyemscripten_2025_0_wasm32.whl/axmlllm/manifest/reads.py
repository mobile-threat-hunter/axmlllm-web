"""How the device's package parser reads one attribute — the two readers, not ``Element.attr()``.

* A styleable read (``obtainAttributes`` then ``TypedArray``) keys on the attribute's ResID and
  takes what AOSP's RetrieveAttributes walk takes (``Element.styleable_reads``, run natively) — a
  string name is never consulted. A reference is resolved through the app's resource table, as
  the TypedArray's AssetManager does.
* A by-name read (``XmlResourceParser.getAttributeValue(ns, name)``, ResXMLParser::
  indexOfAttribute) takes the first attribute whose namespace and name STRINGS match — the ResID
  is never consulted — and gets its raw string first.

``Element.attr()`` mixes the two (ResID first, then name, through a curated map): a manifest can
make it read an attribute neither reader takes. Each function here says what a reader returns,
``Throws`` where the device's read throws (its parse then fails), or ``Unresolved`` with why when
this host cannot say (a reference with no table, a value that depends on the configuration).
"""

from __future__ import annotations

import math
import struct
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Callable

if TYPE_CHECKING:
    from .model import Attribute, Element

ANDROID = "android"  # the model's name for the exact android namespace URI
_ANDROID_URI = "http://schemas.android.com/apk/res/android"

# Res_value data types (ResourceTypes.h)
TYPE_NULL, TYPE_REFERENCE, TYPE_ATTRIBUTE, TYPE_STRING = 0x00, 0x01, 0x02, 0x03
TYPE_FIRST_INT, TYPE_LAST_INT = 0x10, 0x1F
TYPE_DYNAMIC_REFERENCE = 0x07


@dataclass(frozen=True)
class Throws:
    """The reader throws on this value (the device's parse fails here); ``why`` says what."""

    why: str


@dataclass(frozen=True)
class Unresolved:
    """The reader's value is not known on this host; ``why`` says what it depends on."""

    why: str


def styleable(element: Element, resid: int) -> Attribute | None:
    """Return the attribute a styleable read of ``resid`` takes, or None (the read gets no value)."""
    i = element.styleable_reads.get(f"0x{resid:08x}")
    return None if i is None else element.attributes[i]


def by_name(element: Element, ns: str | None, name: str) -> Attribute | None:
    """Return the attribute a by-name read takes: the first whose namespace and name strings match.

    ``ns`` is ``"android"`` (the exact android URI) or None (no namespace). The comparison is
    ResXMLParser::indexOfAttribute's (ResourceTypes.cpp:1611-1690) on the STORED strings: equal
    lengths and bytes; with no namespace asked, only an attribute with no namespace (not ""). An
    attribute the engine did not give its stored strings (a hand-built document) is compared by
    its decoded name and namespace.
    """
    for a in element.attributes:
        if by_name_matches(a, ns, name):
            return a
    return None


def by_name_matches(a: Attribute, ns: str | None, name: str) -> bool:
    """Whether a by-name read of (``ns``, ``name``) matches ``a`` (indexOfAttribute's test)."""
    if not a.stored_present:  # a hand-built document: no stored strings to compare
        return a.name == name and a.ns == ns
    return _index_of_attribute_match(a, None if ns is None else _ns_uri(ns), name)


def _ns_uri(ns: str) -> str:
    return _ANDROID_URI if ns == ANDROID else ns


def _index_of_attribute_match(a: Attribute, ns: str | None, name: str) -> bool:
    """Test one attribute as indexOfAttribute does (ResourceTypes.cpp:1611-1690).

    The query is converted as the JNI caller does (a Java String, so UTF-16 units). A UTF-8 pool
    compares ``curAttrLen == attrLen`` (the stored byte count against the query's UTF-16 length)
    and then that many bytes of the query's UTF-8 form; a UTF-16 pool compares the units.
    """
    stored = a.name_stored
    if stored is None:
        return False
    attr16 = name.encode("utf-16-le", "surrogatepass")
    attr_len = len(attr16) // 2
    if a.stored_utf8:
        attr8 = name.encode("utf-8", "surrogatepass")
        if len(stored) != attr_len or stored[:attr_len] != attr8[:attr_len]:
            return False
    elif stored != attr16:
        return False
    cur_ns = a.ns_stored
    if ns is None:
        return cur_ns is None
    if cur_ns is None:
        return False
    ns16 = ns.encode("utf-16-le", "surrogatepass")
    ns_len = len(ns16) // 2
    if a.stored_utf8:
        ns8 = ns.encode("utf-8", "surrogatepass")
        return len(cur_ns) == ns_len and cur_ns[:ns_len] == ns8[:ns_len]
    return cur_ns == ns16


def _signed(raw: int) -> int:
    return raw - (1 << 32) if raw >= 1 << 31 else raw


TYPE_INT_BOOLEAN = 0x12
TYPE_FIRST_COLOR_INT, TYPE_LAST_COLOR_INT = 0x1C, 0x1F
# ActivityInfo.CONFIG_NATIVE_BITS (ActivityInfo.java:1134-1151): Java config bit i is set when
# native (ResTable_config) bit CONFIG_NATIVE_BITS[i] is — Configuration.NATIVE_CONFIG_* values
# (Configuration.java:1009-1044). VERSION (0x0400) and SCREEN_ROUND (0x8000) are not listed.
_CONFIG_NATIVE_BITS = (
    0x0002,  # MNC
    0x0001,  # MCC
    0x0004,  # LOCALE
    0x0008,  # TOUCHSCREEN
    0x0010,  # KEYBOARD
    0x0020,  # KEYBOARD_HIDDEN
    0x0040,  # NAVIGATION
    0x0080,  # ORIENTATION
    0x0800,  # SCREEN_LAYOUT
    0x1000,  # UI_MODE
    0x0200,  # SCREEN_SIZE
    0x2000,  # SMALLEST_SCREEN_SIZE
    0x0100,  # DENSITY
    0x4000,  # LAYOUTDIR
    0x10000,  # COLOR_MODE
    0x20000,  # GRAMMATICAL_GENDER
)
# Configuration.NATIVE_CONFIG_VERSION (Configuration.java:1030): parseActivityAlias passes it as
# getNonConfigurationString's allowed (JAVA) mask, where 0x0400 is bit 10 — native SCREEN_SIZE
NATIVE_CONFIG_VERSION = 0x0400


def _native_to_java(native: int) -> int:
    """``ActivityInfo.activityInfoConfigNativeToJava`` (ActivityInfo.java:1760-1768)."""
    out = 0
    for i, bit in enumerate(_CONFIG_NATIVE_BITS):
        if native & bit:
            out |= 1 << i
    return out


@dataclass(frozen=True)
class _Value:
    """A styleable (TypedArray) value, references resolved.

    Its ``type_code``, ``data``, the pooled string of a string value, and the config axes it
    varies with.
    """

    type_code: int
    data: int
    typed_string: str | None
    changing: int
    # the Java cookie: -1 for a value from the XML's own pool; a loaded table's otherwise
    cookie: int = -1
    # a string value's load (TypedArray.loadStringValueAt), when it does not give a string: it is
    # LAZY, so this is the outcome only for a reader that loads it — getNonResourceString of a
    # table string returns null without loading (TypedArray.java:301-318)
    load: Throws | Unresolved | None = None


def _typed(element: Element, resid: int, a: Attribute) -> _Value | Unresolved | Throws:
    """Return the TypedArray entry a styleable read of ``resid`` gets (``a`` is what it takes).

    With the app's table loaded, the device's OWN entry: RetrieveAttributes run natively with that
    table's AssetManager2 over the manifest the device opens (``ArscResolver.typed_reads``) — it
    resolves a reference from the XML value (flags 0, ResolveReference), so a chain's changing
    configurations, a bag reference and the resolved bits are AOSP's. Without a table (a bare
    AXML, a hand-built tree), the XML's typed value as is: a reference is then Unresolved.
    """
    rows = element.rows()
    if rows is None:
        return _from_row(_xml_row(a), table=False)
    if rows.get("io_error"):
        return Throws(
            "an I/O error reading the resource table (obtainAttributes throws)"
        )
    row = rows.get(f"0x{resid:08x}")
    # the table ran but gave this taken attribute no entry: never expected, so said, not guessed
    if row is None:
        return Unresolved(
            f"no TypedArray entry for 0x{resid:08x} (the table's run lacks it)"
        )
    return _from_row(row)


def _alternatives(element: Element, resid: int) -> list[_Value | Unresolved | Throws]:
    """Return the other TypedArray entries another device state gives (``typed_reads`` alt)."""
    rows = element.rows()
    row = None if rows is None else rows.get(f"0x{resid:08x}")
    return [] if row is None else [_from_row(alt) for alt in row.get("alt", [])]


def _over_locales(
    element: Element, resid: int, a: Attribute, read: Callable[[Any], Any]
) -> Any:
    """Return ``read`` of the TypedArray entry — or Unresolved when the device decides it.

    The device's request carries three things this host cannot know (ResourcesImpl:503-508,
    613-651; PackageManagerService:2103): its default locale, the layout direction that locale
    sets, and the real screen's pixel size. ``read`` is applied to the first run's entry and to
    every other entry a run under another of those states gives (``typed_reads``); only where those
    answers differ is the answer the device's to make. Derived from the runs, not from the
    changing flags (which ResolveReference overwrites hop by hop, AssetManager2.cpp:1201).
    """
    base = read(_typed(element, resid, a))
    alts = _alternatives(element, resid)
    answers = [base] + [read(v) for v in alts]
    if all(x == base for x in answers):
        return base
    shown = sorted(
        {
            repr(x.why) if isinstance(x, (Unresolved, Throws)) else repr(x)
            for x in answers
        }
    )
    return Unresolved(
        "a value the device's locale, layout direction or screen size decides "
        f"(one of {', '.join(shown[:4])})"
    )


def _from_row(row: dict[str, Any], table: bool = True) -> _Value | Unresolved | Throws:
    """Return a TypedArray entry (``typed_reads``) as a value: its type, data, string, flags.

    ``table`` False: the entry of a run with no resource table (``_xml_row``) — the device always
    has its app's table, so a reference or a theme attribute there is not known.
    """
    if not table and row["type"] in (TYPE_REFERENCE, TYPE_DYNAMIC_REFERENCE):
        return Unresolved(
            f"a reference (0x{row['data']:08x}) with no resource table loaded"
        )
    if not table and row["type"] == TYPE_ATTRIBUTE:
        return Unresolved("a theme attribute (?attr), with no resource table loaded")
    if "more" in row:  # every state ran; more distinct entries than typed_reads keeps
        return Unresolved(
            f"one of more than {row['more']} distinct values the device states read"
        )
    # typed_reads did not run every device state: what they read is not known
    if "capped" in row:
        return Unresolved(
            f"a reference read under {row['capped']} device states, more than this host runs"
        )
    t, data, flags = row["type"], row["data"], row["flags"]
    if t == TYPE_STRING:
        # TypedArray.loadStringValueAt from the pool the cookie names (:1397-1407). The load is
        # lazy: its failure belongs to the reader that loads (_Value.load), not to the row
        load: Throws | Unresolved | None = None
        text: str | None = None
        if row.get(
            "past_pool"
        ):  # past the pool: the load throws (device-verified, rf_out_of_pool)
            load = Throws(
                f"a string whose typed data index ({data}) is past the string pool (the "
                "TypedArray's string load indexes past its array)"
            )
        elif "string_java" in row:  # the Java string the load gives (nativeGetString)
            got = _java_value(
                _java_units(row["string_java"]),
                bool(row.get("string_styled")),
                "the string",
            )
            if isinstance(got, Throws):
                load = got
            else:
                text = got
        elif row.get("string") is None:
            load = Unresolved(
                f"a string whose pool entry {data} this host's ResStringPool::stringAt does not "
                "return (what the device reads there is not verified)"
            )
        else:
            text = row["string"]
        return _Value(t, data, text, flags, row["cookie"], load)
    return _Value(t, data, None, flags, row["cookie"])


def _xml_row(a: Attribute) -> dict[str, Any]:
    """Return the entry RetrieveAttributes gives ``a`` with NO table loaded, in typed_reads' shape.

    Nothing resolves (ResolveReference finds no entry), so it is the XML's typed value — never the
    rawValue string — except @null, which becomes TYPE_NULL (AttributeResolution.cpp:394-398).
    """
    if a.type_code in (TYPE_REFERENCE, TYPE_DYNAMIC_REFERENCE) and a.raw == 0:
        return {"type": TYPE_NULL, "data": 0, "cookie": -1, "flags": 0}
    row: dict[str, Any] = {"type": a.type_code, "data": a.raw, "cookie": -1, "flags": 0}
    if a.type_code == TYPE_STRING:
        row["string"], row["past_pool"] = a.typed_string, a.typed_out_of_pool
        if (
            a.typed_java_present
        ):  # the Java string, as the engine's TypedArray rows carry it
            row["string_java"] = (
                None
                if a.typed_java is None
                else a.typed_java.encode("utf-16-le", "surrogatepass")
            )
            if a.typed_styled:
                row["string_styled"] = True
    return row


def _java_units(units: bytes | None) -> str | None:
    return None if units is None else units.decode("utf-16-le", "surrogatepass")


_DIMENSION_UNITS = (
    "px",
    "dip",
    "sp",
    "pt",
    "in",
    "mm",
)  # TypedValue.DIMENSION_UNIT_STRS
_FRACTION_UNITS = ("%", "%p")  # TypedValue.FRACTION_UNIT_STRS


def _coerce_static(t: int, data: int) -> str | None | Unresolved | Throws:
    """``TypedValue.coerceToString(int type, int data)`` (TypedValue.java:778-808).

    The text, or None where Java returns null — TYPE_NULL, a string (the static form renders none),
    a dynamic reference / attribute, and every type it does not know. A float / dimension / fraction
    has a text this host cannot reproduce byte for byte (Java's Float.toString): Unresolved — except
    a NaN or infinite float, whose text Float.toString fixes ("NaN", "Infinity", "-Infinity"). An
    Unresolved text thus begins with '-' or an ASCII digit and holds no ',' or whitespace. 0x07 is
    a dynamic reference and 0x08 a dynamic attribute, both null in Java. A
    dimension / fraction whose unit indexes past its table throws (ArrayIndexOutOfBounds) in Java.
    Pinned by a table host OpenJDK computed with the method verbatim (tests/test_reads.py).
    """
    data = _int32(data)
    if t == TYPE_REFERENCE:
        return f"@{data}"
    if t == TYPE_ATTRIBUTE:
        return f"?{data}"
    if t == 0x04:  # TYPE_FLOAT
        f = struct.unpack("<f", struct.pack("<I", data & 0xFFFFFFFF))[0]
        if math.isnan(f):
            return "NaN"
        if math.isinf(f):
            return "Infinity" if f > 0 else "-Infinity"
        return Unresolved("the Float.toString text of a float")
    if t in (0x05, 0x06):  # TYPE_DIMENSION / TYPE_FRACTION: the unit is the low 4 bits
        units = _DIMENSION_UNITS if t == 0x05 else _FRACTION_UNITS
        if (data & 0xF) >= len(units):
            return Throws(
                f"a value of type 0x{t:02x} whose unit {data & 0xF} is past its table"
            )
        return Unresolved(f"the Float.toString text of a value of type 0x{t:02x}")
    if (
        t == 0x11
    ):  # TYPE_INT_HEX: "0x" + Integer.toHexString (unsigned, no leading zeros)
        return f"0x{data & 0xFFFFFFFF:x}"
    if t == TYPE_INT_BOOLEAN:
        return "true" if data != 0 else "false"
    if TYPE_FIRST_COLOR_INT <= t <= TYPE_LAST_COLOR_INT:  # "#" + Integer.toHexString
        return f"#{data & 0xFFFFFFFF:x}"
    if TYPE_FIRST_INT <= t <= TYPE_LAST_INT:  # other int: signed decimal
        return str(data)
    return None  # TYPE_NULL, TYPE_STRING, 0x07-0x0f, 0x20+: Java's null


def _coerce_to_string(v: _Value) -> str | None | Unresolved | Throws:
    """``TypedValue.coerceToString()`` (TypedValue.java:752-759): a string's own, else the static."""
    if v.type_code == TYPE_STRING:
        return v.load if v.load is not None else v.typed_string  # the load happens here
    return _coerce_static(v.type_code, v.data)


def get_int(
    element: Element,
    resid: int,
    default: int,
) -> int | Unresolved | Throws:
    """Return ``TypedArray.getInt(resid, default)`` (TypedArray.java getInt).

    Int-range data; a string through convertValueToInt; any other type's text through it too —
    which always throws (Throws).
    """
    a = styleable(element, resid)
    if a is None:
        return default

    def of(v: Any) -> Any:
        if isinstance(v, (Unresolved, Throws)):
            return v
        if v.type_code == TYPE_NULL:
            return default
        if TYPE_FIRST_INT <= v.type_code <= TYPE_LAST_INT:
            return _signed(v.data)
        # getInt coerces any other value to a string (coerceToString) and runs it through
        # convertValueToInt: a float "1.5", a reference "@123" or a bad string throws (TypedArray.java
        # getInt; device-verified with a float maxSdkVersion and a maxSdkVersion @missing); a null
        # text is the default (XmlUtils.convertValueToInt: TextUtils.isEmpty)
        text = _coerce_to_string(v)
        if isinstance(text, Throws):
            return text
        if isinstance(
            text, Unresolved
        ):  # Float.toString: always a "." or a letter, never an int
            return Throws(
                f"a value of type 0x{v.type_code:02x}, coerced to a non-integer (NumberFormatException)"
            )
        return _convert_value_to_int(text, default) if text is not None else default

    return _over_locales(element, resid, a, of)


def peek_int(element: Element, resid: int) -> int | str | None | Unresolved | Throws:
    """Return ``TypedArray.peekValue(resid)`` as parseUsesSdk reads it (PPU:1732-1755).

    None for no value (getValueAt is false for TYPE_NULL, TypedArray.java:1388); a string's text
    (a codename); any other value's data as an int — an unresolved reference's too (its id).
    """
    a = styleable(element, resid)
    if a is None:
        return None

    def of(v: Any) -> Any:
        if isinstance(v, (Unresolved, Throws)):
            return v
        if v.type_code == TYPE_NULL:
            return None
        if v.type_code == TYPE_STRING:  # getValueAt loads the string
            return v.load if v.load is not None else v.typed_string
        return _signed(v.data)

    return _over_locales(element, resid, a, of)


def min_or_max_sdk(
    element: Element,
    resid: int,
    default: int,
) -> int | Unresolved | Throws:
    """``parseMinOrMaxSdkVersion``: an int-typed peeked value (references resolved), else default."""
    a = styleable(element, resid)
    if a is None:
        return default

    def of(v: Any) -> Any:
        if isinstance(v, (Unresolved, Throws)):
            return v
        if v.type_code == TYPE_STRING and v.load is not None:
            return v.load  # peekValue's getValueAt loads a string value
        return (
            _signed(v.data)
            if TYPE_FIRST_INT <= v.type_code <= TYPE_LAST_INT
            else default
        )

    return _over_locales(element, resid, a, of)


def by_name_text(
    element: Element, ns: str | None, name: str
) -> str | None | Unresolved | Throws:
    """Return ``XmlBlock.Parser.getAttributeValue(ns, name)`` (XmlBlock.java:288-308).

    A by-name read: the attribute's raw string when it has one; else its TYPED value through the
    static ``TypedValue.coerceToString(type, data)`` — "@<decimal>" for a reference, None for a
    string (the static form renders none); TYPE_NULL throws (IndexOutOfBoundsException). The type
    is ResXMLParser::getAttributeDataType's, which reports a dynamic reference as a plain
    reference (ResourceTypes.cpp:1548-1555), so it reads "@<decimal>" too. Its data is the raw id
    in the lite parse, whose tree has no DynamicRefTable (ApkAssets.openXml), and in the full parse
    the id the table maps it to, 0 when unmapped (:1560-1580): shown here unmapped — exact for the
    lite parse; in the full parse only the digits can differ, never a verdict ("@" is in no name).
    """
    a = by_name(element, ns, name)
    return None if a is None else by_name_text_of(a)


def by_name_text_of(a: Attribute) -> str | None | Unresolved | Throws:
    """``by_name_text`` of the attribute a by-name lookup found."""
    if (
        a.raw_java_present
    ):  # rawValue indexes the pool: getSequenceString of it (XmlBlock:294)
        return _java_value(a.raw_java, a.raw_styled, "the raw string")
    if a.raw_string is not None:  # a hand-built document with no Java text
        return a.raw_string
    if a.type_code == TYPE_NULL:
        return Throws(
            "a null value (XmlBlock.getAttributeValue: IndexOutOfBoundsException)"
        )
    # XmlBlock.java:304-307, with getAttributeDataType's type: a dynamic reference is a reference
    t = TYPE_REFERENCE if a.type_code == TYPE_DYNAMIC_REFERENCE else a.type_code
    return _coerce_static(t, a.raw)


def _java_value(text: str | None, styled: bool, what: str) -> str | Throws:
    """Return the Java string a pool read gives, or how it fails (docs/java-string-design.md)."""
    if text is None:
        return Throws(
            f"{what}'s pool entry does not read (nativeGetString: IndexOutOfBoundsException)"
        )
    # a styled string reads as its text (getSequenceString -> toString); whether the device's
    # style application throws first is not replayed — the dispatch says so (styled_reads)
    return text


def non_resource_string(
    element: Element, resid: int
) -> str | None | Unresolved | Throws:
    """``TypedArray.getNonResourceString`` (TypedArray.java:301-318).

    A string from the XML's own pool (cookie < 0), else None — a reference resolved to a table
    string is NOT returned.
    """
    a = styleable(element, resid)
    if a is None:
        return None

    def of(v: Any) -> Any:
        if isinstance(v, Throws):
            return v
        if isinstance(v, Unresolved):
            # no table: only a direct string can be one; a reference is not (TypedArray.java:309)
            return v if a.type_code == TYPE_STRING else None
        if v.type_code != TYPE_STRING or v.cookie >= 0:
            return None  # a table string is not loaded at all (TypedArray.java:309-316)
        return v.load if v.load is not None else v.typed_string

    return _over_locales(element, resid, a, of)


def _utf16(s: str) -> list[str]:
    """Return ``s`` as Java sees it: UTF-16 code units (a supplementary char is two surrogates)."""
    b = s.encode("utf-16-le", "surrogatepass")
    return [chr(int.from_bytes(b[k : k + 2], "little")) for k in range(0, len(b), 2)]


def _android_is_whitespace(cp: int) -> bool:
    """Return libcore ``Character.isWhitespace(int)`` — Android's, not OpenJDK's.

    Character.java (Android-changed, on ICU4C): ASCII 0x09-0x0d and 0x1c-0x20; then only U+1680,
    U+180E, U+2000-U+200A except U+2007, U+2028, U+2029, U+205F, U+3000. U+0085 and U+00A0 are not
    (Python's ``str.isspace`` says they are). Above U+FFFF it asks ICU, and no supplementary code
    point is whitespace.
    """
    if 0x1C <= cp <= 0x20 or 0x09 <= cp <= 0x0D:
        return True
    if cp < 0x1000:
        return False
    if cp in (0x1680, 0x180E):
        return True
    if cp < 0x2000 or cp in (0x2007, 0x202F):
        return False
    if cp <= 0xFFFF:
        return cp <= 0x200A or cp in (0x2028, 0x2029, 0x205F, 0x3000)
    return False


def _java_strip(s: str) -> str:
    """Return libcore ``String.strip()`` (StringUTF16.strip): whitespace code points off both ends.

    Whitespace is ``_android_is_whitespace`` — Python's ``str.strip()`` also strips U+0085 and the
    no-break spaces, which the device keeps.
    """
    left, right = 0, len(s)
    while left < right and _android_is_whitespace(ord(s[left])):
        left += 1
    while right > left and _android_is_whitespace(ord(s[right - 1])):
        right -= 1
    return s[left:right]


def _java_trim(s: str) -> str:
    """Return libcore ``String.trim()`` (String.java:3774-3792): every char <= ' ' off both ends.

    Java trims UTF-16 chars; a supplementary code point and a surrogate are both above ' ', so over
    Python's code points the result is the same.
    """
    left, right = 0, len(s)
    while left < right and s[left] <= " ":
        left += 1
    while right > left and s[right - 1] <= " ":
        right -= 1
    return s[left:right]


def _java_split(s: str, sep: str) -> list[str]:
    """Return libcore ``String.split(sep)`` for one non-metacharacter ``sep`` (Pattern.fastSplit).

    Limit 0: "" is ``[""]``; trailing empty parts are dropped, so a string of separators only is
    ``[]``.
    """
    if not s:
        return [""]
    parts = s.split(sep)
    while parts and parts[-1] == "":
        parts.pop()
    return parts


def _java_digit(ch: str, radix: int) -> int:
    """Return ``Character.digit(char, radix)`` for one UTF-16 unit.

    A BMP decimal digit or a Latin letter (also full-width); a surrogate — half of a
    supplementary digit — is -1, as in Java.
    """
    import unicodedata

    if 0xD800 <= ord(ch) <= 0xDFFF:
        return -1
    if ch.isdecimal():
        d = unicodedata.decimal(ch)
    elif ch.isascii() and ch.isalpha():
        d = ord(ch.lower()) - ord("a") + 10
    elif "\uff21" <= ch <= "\uff3a" or "\uff41" <= ch <= "\uff5a":
        d = (ord(ch) - (0xFF21 if ch <= "\uff3a" else 0xFF41)) + 10
    else:
        return -1
    return d if d < radix else -1


def _java_parse_int(units: list[str], radix: int) -> int | None:
    """Return ``Integer.parseInt`` of these UTF-16 units, or None where Java throws.

    An optional sign, then digits only; NumberFormatException for empty, any other unit, or a
    value out of int range.
    """
    if not units:
        return None
    i, negative = 0, False
    if units[0] in "+-":
        negative, i = units[0] == "-", 1
        if len(units) == 1:
            return None
    value = 0
    for ch in units[i:]:
        d = _java_digit(ch, radix)
        if d < 0:
            return None
        value = value * radix + d
        if value > (1 << 31) - (0 if negative else 1):
            return None
    return -value if negative else value


def _int32(v: int) -> int:
    v &= 0xFFFFFFFF
    return v - (1 << 32) if v >= 1 << 31 else v


def _convert_value_to_int(s: str, default: int) -> int | Throws:
    """Return ``XmlUtils.convertValueToInt`` (XmlUtils.java:302-346), or Throws where Java throws.

    "-", then 0x / 0 (octal) / # prefixes, then ``Integer.parseInt`` of the rest times the sign.
    """
    if not s:
        return default
    u = _utf16(s)  # Java's charAt / length count UTF-16 units
    sign, index, base = 1, 0, 10
    if u[0] == "-":
        sign, index = -1, 1
    if index >= len(u):
        return Throws(f"{s!r}: StringIndexOutOfBounds in convertValueToInt")
    if u[index] == "0":
        if index == len(u) - 1:
            return 0
        if u[index + 1] in "xX":
            index, base = index + 2, 16
        else:
            index, base = index + 1, 8
    elif u[index] == "#":
        index, base = index + 1, 16
    parsed = _java_parse_int(u[index:], base)
    if parsed is None:
        return Throws(f"{s!r}: NumberFormatException in Integer.parseInt")
    return _int32(parsed * sign)


def get_boolean(
    element: Element,
    resid: int,
    default: bool,
) -> bool | Unresolved | Throws:
    """``TypedArray.getBoolean(resid, default)``: int-range data != 0, a string "1"/"true"/"TRUE"."""
    a = styleable(element, resid)
    if a is None:
        return default

    def of(v: Any) -> Any:
        if isinstance(v, (Unresolved, Throws)):
            return v
        if v.type_code == TYPE_NULL:
            return default
        if TYPE_FIRST_INT <= v.type_code <= TYPE_LAST_INT:
            return v.data != 0
        # getBoolean coerces to a string and runs XmlUtils.convertValueToBoolean (TypedArray.java
        # getBoolean, XmlUtils:285-299): empty or null -> default, "1"/"true"/"TRUE" -> true, else
        # false (a float's text is non-empty and never a boolean word)
        string = _coerce_to_string(v)
        if isinstance(string, Throws):
            return string
        if isinstance(string, Unresolved):
            return False
        return default if not string else string in ("1", "true", "TRUE")

    return _over_locales(element, resid, a, of)


def _text(v: _Value) -> str | None | Unresolved | Throws:
    """Return the string a TypedArray gives a value (TypedArray.java getString:262-284).

    None for null; a string's TYPED pool string; any other value's coerceToString text. Unresolved
    where this host cannot give the device's text: a float/dimension/fraction (Java's
    Float.toString).
    """
    if v.type_code == TYPE_NULL:
        return None
    return _coerce_to_string(
        v
    )  # null where Java's coerceToString is (getString :278-279)


def get_string(
    element: Element,
    resid: int,
) -> str | None | Unresolved | Throws:
    """Return ``TypedArray.getString(resid)`` (TypedArray.java:262-284): see ``_text``."""
    a = styleable(element, resid)
    if a is None:
        return None
    return _over_locales(
        element,
        resid,
        a,
        lambda v: v if isinstance(v, (Unresolved, Throws)) else _text(v),
    )


def non_config_string(
    element: Element, resid: int, allowed: int = 0
) -> str | None | Unresolved | Throws:
    """Return ``TypedArray.getNonConfigurationString(resid, allowed)`` (TypedArray.java:336-361).

    ``get_string``'s text, but None for a value whose changing configurations — mapped to the
    Java bits — are not all in ``allowed`` (a JAVA config mask).
    """
    a = styleable(element, resid)
    if a is None:
        return None

    def of(v: Any) -> Any:
        if isinstance(v, (Unresolved, Throws)):
            return v
        # null if its changing configurations, mapped native -> Java, leave any bit outside
        # ``allowed``: a value varying only by sdk-version or screen-round maps to nothing and is
        # still returned (device-confirmed)
        if _native_to_java(v.changing) & ~allowed:
            return None
        return _text(v)

    return _over_locales(element, resid, a, of)
