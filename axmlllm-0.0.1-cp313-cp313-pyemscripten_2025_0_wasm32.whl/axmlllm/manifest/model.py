"""Typed domain model over the AOSP-parsed AXML data tree.

This is the hexagonal **domain core**: it consumes the data tree produced by the
``ManifestSource`` port (``axmlllm._axml_core.parse_apk`` / ``parse_axml``) and knows
nothing about how the bytes were parsed. The tree shape is documented in
``docs/tree-schema.md``. Every node/attribute preserves the string-name vs ResID dual
identity and the raw (unmasked) ``Res_value`` type, so the spoofing signals survive into
the model.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Iterator

from .._axml_core import ZIP_ENTRY_NOT_FOUND, TableLoadError
from .._axml_core import parse_apk as _parse_apk
from .._axml_core import parse_axml as _parse_axml
from .android_attrs import canonical_name
from .dispatch import Replay, replay
from .reads import (
    Throws,
    Unresolved,
    by_name_text,
    get_boolean,
    non_config_string,
    non_resource_string,
)
from .resources import (
    LoadFailure,
    ResourceTable,
    StackDrop,
    arsc_entry,
    arsc_inflate,
    host_judgement,
    native_path,
)
from .styleables import ATTR

if TYPE_CHECKING:  # a stub-only type: the extension has no such runtime name
    from .._axml_core import ArscEntry

_COMPONENT_TAGS = ("activity", "activity-alias", "service", "receiver", "provider")
# the tag names the device reads as a permission request (PPU:1128-1130)
_PERMISSION_TAGS = (
    "uses-permission",
    "uses-permission-sdk-23",
    "uses-permission-sdk-m",
)

# Cap tree depth when materializing the native dict into Element objects. Real manifests
# nest <15 deep; a malicious APK can nest thousands deep (the native parser is iterative and
# tolerates it) which would blow Python's recursion limit here and in every tree walker.
# Beyond the cap we drop deeper children — far above anything legitimate, and excessive depth
# is itself a triage signal, not data worth crashing for.
_MAX_DEPTH = 256


def java_str(units: bytes | None) -> str | None:
    """Decode a Java string the engine reports as UTF-16LE units (lone surrogates kept)."""
    return None if units is None else units.decode("utf-16-le", "surrogatepass")


_LONE_SURROGATE = re.compile("[\ud800-\udfff]")


def printable(text: str) -> str:
    r"""Return ``text`` with every lone surrogate written as ``\uXXXX``.

    A Java string can hold lone surrogates, and so can the names read from it. No UTF-8 encoder
    accepts them, so a crafted name would make an output fail. Outputs are escaped; comparisons
    keep the string itself.
    """
    return _LONE_SURROGATE.sub(lambda c: f"\\u{ord(c.group()):04x}", text)


@dataclass(frozen=True)
class Attribute:
    """One element attribute, exactly as ResXMLParser exposes it.

    ``name`` is the string-pool name (may be empty); ``resid`` is the independent
    resource-map ID (``getAttributeNameResID``); their disagreement is the spoof signal.
    ``type_code`` is the raw, unmasked ``Res_value.dataType`` (so a masked
    ``TYPE_DYNAMIC_REFERENCE`` 0x07 is still visible).
    """

    name: str
    ns: str | None
    resid: str | None
    type: str
    type_code: int
    value: Any
    raw: int
    # the attribute's raw string (rawValue), when it has one: what a by-name reader gets first
    raw_string: str | None = None
    # the TYPED string (the pool string at Res_value.data), what a styleable read / TypedArray
    # gets for a string value — differs from raw_string only in a crafted raw!=typed split, which
    # aapt2 never writes. None unless the value is string-typed. See build_attr in the engine.
    typed_string: str | None = None
    typed_out_of_pool: bool = False
    # What the device's Java parser reads for those two (StringBlock.getSequence ->
    # nativeGetString, docs/java-string-design.md): raw_java when rawValue indexes the pool
    # (raw_java_present), typed_java for a string value; None where nativeGetString throws.
    # *_styled: the index carries style spans, whose application is not replayed.
    raw_java_present: bool = False
    raw_java: str | None = None
    raw_styled: bool = False
    typed_java_present: bool = False
    typed_java: str | None = None
    typed_styled: bool = False
    # The name and namespace as ResXMLParser::indexOfAttribute compares them (the pool's own
    # encoding: UTF-8 bytes or UTF-16LE units); ns_stored None is "no namespace", not "".
    name_stored: bytes | None = None
    ns_stored: bytes | None = None
    # the pool's encoding, which says how name_stored is encoded
    stored_utf8: bool = False
    stored_present: bool = False  # the engine reported name_stored / ns_stored

    @classmethod
    def from_dict(cls, d: dict[str, Any], utf8: bool = False) -> Attribute:
        """Build an Attribute from one attribute dict in the tree."""
        return cls(
            name=d.get("name", ""),
            ns=d.get("ns"),
            resid=d.get("resid"),
            type=d.get("type", "unknown"),
            type_code=int(d.get("type_code", 0)),
            value=d.get("value"),
            raw=int(d.get("raw", 0)),
            raw_string=d.get("raw_string"),
            typed_string=d.get("typed_string"),
            typed_out_of_pool=bool(d.get("typed_out_of_pool", False)),
            raw_java_present="raw_java" in d,
            raw_java=java_str(d.get("raw_java")),
            raw_styled=bool(d.get("raw_styled", False)),
            typed_java_present="typed_java" in d,
            typed_java=java_str(d.get("typed_java")),
            typed_styled=bool(d.get("typed_styled", False)),
            name_stored=d.get("name_stored"),
            ns_stored=d.get("ns_stored"),
            stored_utf8=utf8,
            stored_present="name_stored" in d,
        )

    @property
    def key(self) -> str:
        """The framework's canonical name for this attribute (ResID-first).

        The framework keys on the ResID, so this — not ``name`` — is what the device acts
        on. Falls back to the string-pool ``name`` when the ResID is absent/unknown.
        """
        return canonical_name(self.resid, self.name)


@dataclass
class Element:
    """One XML element (start-tag) and its subtree.

    ``tag`` is the name the device's Java parser matches (XmlBlock.getName, the Java string of the
    pool entry); ``stored_tag`` is the stored string. They differ only in a crafted pool.
    """

    tag: str
    ns: str | None
    line: int
    attributes: list[Attribute] = field(default_factory=list)
    children: list[Element] = field(default_factory=list)
    text: str | None = None
    # Descendants the depth cap dropped below this element — recorded, because "no children" here
    # would be a false statement: the app can read its own manifest at any depth (review).
    dropped_descendants: int = 0
    # Which attribute a styleable read takes, per ResID (0x%08x -> index in ``attributes``, or None
    # when the read gets no value): AOSP's RetrieveAttributes, run natively. The device reads
    # manifest tags through styleables (obtainAttributes), so this — not ``attr()`` — is what it
    # sees for an attribute it reads by ResID.
    styleable_reads: dict[str, int | None] = field(default_factory=dict)
    # A binary-XML flag extension on this element ({"name", "negated"}): with that flag off, the
    # device's XmlBlock removes the element and its subtree before the package parser sees it.
    flag: dict[str, Any] | None = None
    # The element's index among the document's start tags (the native parse's "ordinal").
    ordinal: int | None = None
    # The stored tag string; tag_unreadable: getName's nativeGetString throws (the parse fails
    # there); tag_styled: the entry carries style spans (their application is not replayed).
    stored_tag: str = ""
    tag_unreadable: bool = False
    tag_styled: bool = False
    tag_null: bool = False  # a negative name index: getName is null (XmlBlock.java:246)
    # The TypedArray each ResID's styleable read gets ({"0x%08x": row}, or {"io_error": True}):
    # set directly, or fetched through ``row_source`` (the Manifest's table, loaded on first ask).
    # Neither: reads take the XML value as is (no table).
    typed_reads: dict[str, Any] | None = None
    row_source: Any = field(default=None, repr=False, compare=False)

    def rows(self) -> dict[str, Any] | None:
        """Return this element's TypedArray rows, or None when no table backs this tree."""
        if self.typed_reads is not None:
            return self.typed_reads
        if self.row_source is None or self.ordinal is None:
            return None
        rows: dict[str, Any] | None = self.row_source.rows_for(self.ordinal)
        return rows

    @classmethod
    def from_dict(
        cls, d: dict[str, Any], _depth: int = 0, utf8: bool = False
    ) -> Element:
        """Recursively build an Element from a node dict in the tree (depth-capped)."""
        children = (
            [Element.from_dict(c, _depth + 1, utf8) for c in d.get("children", [])]
            if _depth < _MAX_DEPTH
            else []
        )
        dropped = 0
        if _depth >= _MAX_DEPTH:
            stack = list(d.get("children", []))
            while stack:  # iterative: the depth is what the cap exists for
                dropped += 1
                stack.extend(stack.pop().get("children", []))
        stored = d.get("tag", "")
        java = java_str(d.get("tag_java"))
        return cls(
            tag=stored if java is None else java,
            ns=d.get("ns"),
            line=int(d.get("line", -1)),
            attributes=[Attribute.from_dict(a, utf8) for a in d.get("attributes", [])],
            children=children,
            text=d.get("text"),
            dropped_descendants=dropped,
            flag=d.get("flag"),
            styleable_reads=dict(d.get("styleable_reads", {})),
            ordinal=d.get("ordinal"),
            stored_tag=stored,
            tag_unreadable="tag_java" in d and d["tag_java"] is None,
            tag_styled=bool(d.get("tag_styled", False)),
            tag_null=int(d.get("name_index", 0)) < 0,
        )

    def attr(self, key: str) -> Attribute | None:
        """Return the attribute the framework treats as android:``key`` (ResID-first).

        The framework keys on the ResID, so an attribute whose ResID maps to ``key`` wins
        over a string-named decoy — defeating ResID spoofing. Falls back to a string-name
        match when no ResID maps to ``key``.
        """
        if (
            not key
        ):  # never let an empty key match an unknown-ResID attribute via the ""-fallback
            return None
        for a in self.attributes:
            if a.resid is not None and canonical_name(a.resid, "") == key:
                return a
        return next((a for a in self.attributes if a.name == key), None)

    def iter(self, tag: str | None = None) -> Iterator[Element]:
        """Depth-first iterate this element and its descendants, optionally by tag."""
        if tag is None or self.tag == tag:
            yield self
        for child in self.children:
            yield from child.iter(tag)


@dataclass(frozen=True)
class TableLoad:
    """The outcome of loading an APK's resource table, as data (see ``Manifest.table_load``)."""

    entry: ArscEntry | None  # AOSP's archive lookup
    inflate: (
        dict[str, Any] | None
    )  # the device's inflate, replayed (deflated entries only)
    table: ResourceTable | None
    failure: LoadFailure | None  # how the constructor refused the stack, when it did
    dropped: tuple[
        StackDrop, ...
    ]  # members the best-effort policy left out, with AOSP's reason


class Manifest:
    """Facade over a parsed AndroidManifest.xml data tree."""

    def __init__(self, doc: dict[str, Any], apk_path: str | None = None) -> None:
        """Wrap a raw tree dict (as returned by the native port).

        ``apk_path`` enables ``@ref`` resolution via the lazy ``resources`` table.
        """
        self._doc = doc
        self._apk_path = apk_path
        self._table_load: TableLoad | None = None  # see table_load
        self._dispatch: Replay | None = None  # see dispatch
        self._archive_facts: tuple[ArscEntry | None, dict[str, Any] | None] | None = (
            None
        )
        root = doc.get("root")
        utf8 = doc.get("string_pool", {}).get("encoding") == "utf8"
        self.root: Element | None = Element.from_dict(root, utf8=utf8) if root else None
        self._rows: dict[int, dict[str, Any]] | None = None  # see rows_for
        self._roots: list[Element] | None = None  # see roots
        if apk_path is not None and self.root is not None:
            for (
                e
            ) in (
                self.root.iter()
            ):  # every read asks the table itself: no call order matters
                e.row_source = self

    @classmethod
    def from_apk(cls, path: str) -> Manifest:
        """Open an APK and parse its AndroidManifest.xml via real AOSP ResXMLTree."""
        # Bytes across the boundary: a file name need not be UTF-8 (see ArscResolver).
        return cls(_parse_apk(native_path(path)), apk_path=path)

    @property
    def manifest_entry(self) -> dict[str, Any] | None:
        """The APK's AndroidManifest.xml entry as the device opened it, or None (from_axml).

        ``method``, ``compressed_length``, ``length`` (the bytes the device's XML parser is
        handed), ``xml_size`` (the XML chunk's own header.size — the bytes it parses; None below
        8 bytes), ``trailing`` (bytes past the chunk, which it never reads) and ``trailing_fill``
        (the one byte value they all hold, else None). See parse_apk in the binding.
        """
        entry: dict[str, Any] | None = self._doc.get("manifest_entry")
        return entry

    @property
    def table_load(self) -> TableLoad:
        """How this APK's resource table loaded — ONE record, computed once, read by every caller.

        AOSP's archive lookup, its inflate replay, and the table load run back to back (each opens
        the path; a file replaced between them is the only way they can describe different
        archives). The constructor's refusal arrives as a TableLoadError naming the member and
        the cause, so nothing here parses a message or infers a cause from an exception class.
        A MemoryError outside ApkAssets::Load is not a load outcome and propagates (the tool
        boundary answers memory_exhausted).
        """
        if self._table_load is None:
            load = self._load_table()
            if load.table is not None and self._apk_path is not None:
                # the TypedArray rows read the manifest NOW, beside the table's own load: both
                # describe the same archive (a file replaced or removed later is not re-read).
                # Nothing is cached when this raises, so a failure is never a silent no-table.
                from .dispatch import (
                    BASELINE_SDK,
                    BASELINE_SDK_MINOR,
                )  # the device answered

                rows = load.table.typed_reads(
                    self._apk_path, BASELINE_SDK, BASELINE_SDK_MINOR
                )
                read_over = rows.pop(-1, {}).get("start_tags")
                if read_over != self._doc.get("start_tags"):
                    # the ordinals would name other elements: never matched silently
                    raise RuntimeError(
                        f"AndroidManifest.xml changed between the parse ({self._doc.get('start_tags')} "
                        f"start tags) and the resource table's read of it ({read_over})"
                    )
                self._rows = rows
            self._table_load = load
        return self._table_load

    def _archive(self) -> tuple[ArscEntry | None, dict[str, Any] | None]:
        """AOSP's archive lookup and inflate replay, memoized apart from the load.

        A load that raises something other than TableLoadError (a bug of ours, a MemoryError
        outside ApkAssets::Load) leaves no record; these facts must not be lost or recomputed
        with it (the replay is O(inflated size)).
        """
        if self._archive_facts is None:
            if self._apk_path is None:
                self._archive_facts = (None, None)
            else:
                entry = arsc_entry(self._apk_path)
                found = entry["stage"] == "find" and entry["code"] == 0
                inflate = arsc_inflate(self._apk_path) if found else None
                self._archive_facts = (entry, inflate)
        return self._archive_facts

    def _load_table(self) -> TableLoad:
        entry, inflate = self._archive()
        if self._apk_path is None:
            return TableLoad(None, None, None, None, ())
        try:
            # Base + framework only. Splits are NOT auto-mounted from sibling files: in triage the
            # analysis directory is attacker-controlled, and since every app uses package 0x7f a
            # planted sibling split_*.apk would merge into this app's package group (AOSP
            # SetApkAssets groups by package id) — contaminating resolution and, via the
            # cross-package declared() union, suppressing dangling_resource_ref. It would also make
            # analysis non-reproducible. A trusted split set is opt-in via
            # ResourceTable(extra_apks=...); see discover_splits() for a membership-verified helper.
            table = ResourceTable(self._apk_path)
        except TableLoadError as exc:
            failure = LoadFailure(
                exc.cause,
                exc.element,
                getattr(exc, "role", "stack"),
                str(exc),
                host_judgement(exc),
            )
            return TableLoad(entry, inflate, None, failure, getattr(exc, "dropped", ()))
        return TableLoad(entry, inflate, table, None, tuple(table.dropped))

    @property
    def resources(self) -> ResourceTable | None:
        """The loaded resource table, or None (no APK path, or the load failed — see table_load)."""
        return self.table_load.table

    def rows_for(self, ordinal: int) -> dict[str, Any] | None:
        """Return the TypedArray rows of the element at ``ordinal`` (``typed_reads``), or None.

        Loads the table on the first ask, from whichever reader asks first; None when no table
        loaded (reads then take the XML value as is, saying a reference is not known).
        """
        if self.table_load.table is None or self._rows is None:
            return None
        return self._rows.get(ordinal, {})

    @property
    def arsc_entry(self) -> ArscEntry | None:
        """AOSP's own lookup of this APK's ``resources.arsc`` (None without an APK path).

        ``{"stage", "code", "message"}`` (+ the central directory's ``method``,
        ``compressed_length``, ``uncompressed_length`` when found) from libziparchive's
        ``OpenArchive`` + ``FindEntry``, the calls ApkAssets::Load makes. Code 0 is a table the
        device loads; ``ZIP_ENTRY_NOT_FOUND`` and every other code give the device an empty table
        (ApkAssets.cpp:153).
        """
        return self._archive()[0]

    @property
    def loads_no_own_table(self) -> bool:
        """Whether AOSP's lookup answered that the device loads none of this APK's own table.

        True only on a lookup that ran (stage "find") and did not find a usable entry: the
        APK's element of the stack is then the empty table ApkAssets loads in its place. An
        archive that did not reopen says nothing either way (False).
        """
        entry = self.arsc_entry
        return entry is not None and entry["stage"] == "find" and entry["code"] != 0

    @property
    def resources_status(self) -> str:
        """``"ok" | "absent" | "load_failed" | "arsc_unopenable"`` — how the table load resolved.

        - ``"ok"`` — a table loaded and ``@ref`` resolution is available. It may be the EMPTY
          table the device loads for an entry AOSP's archive reader lists but refuses
          (``arsc_entry`` names the code; ``detect`` raises ``arsc_entry_refused``).
        - ``"absent"`` — AOSP's archive reader finds no ``resources.arsc`` (or there is no APK
          path). The detectors still run on the table the device loads in its place: a manifest
          that references app resources the APK does not carry is reported, not excused.
        - ``"load_failed"`` — the entry *is* present and no table loaded; ``table_load.failure``
          says which member and why (``load_rejected``, ``allocation_failed``,
          ``unindexable_package_id`` — we refused to hand AOSP a table it would index out of
          bounds, #13 — or ``set_apk_assets_failed``); ``failure.not_judged`` is set when THIS
          host ended the load (``host_judgement``: a refusal witnessed inside AOSP's Load), and
          every consumer reads it rather than the cause.
        - ``"arsc_unopenable"`` — the archive did not open for the lookup (``arsc_entry`` says
          why: the file vanished or changed after parsing, or the process ran out of
          descriptors). Nothing is claimed about the entry.

        The status is app-centric: it keys on whether the APK carries its own
        ``resources.arsc`` entry. An APK with none is ``"absent"`` even when the resolver
        loaded (e.g. backed by framework-res) — the APK itself contributes no resource table.
        """
        load = self.table_load
        if load.entry is None:
            return "absent"
        if load.entry["stage"] == "open":
            return "arsc_unopenable"
        if load.entry["code"] == ZIP_ENTRY_NOT_FOUND:
            return "absent"
        return "ok" if load.table is not None else "load_failed"

    @property
    def resources_error(self) -> str | None:
        """``"<cause>: <AOSP/binding message>"`` when ``resources_status == "load_failed"``."""
        failure = self.table_load.failure
        if failure is None or self.resources_status != "load_failed":
            return None
        return f"{failure.cause}: {failure.message}"

    @classmethod
    def from_axml(cls, data: bytes) -> Manifest:
        """Parse raw binary-XML (AXML) bytes via real AOSP ResXMLTree."""
        return cls(_parse_axml(data))

    @property
    def parse_status(self) -> str:
        """``"ok"`` or ``"bad_document"`` (device-faithful tolerance)."""
        return self._doc.get("parse_status", "bad_document")

    @property
    def package(self) -> str | None:
        """The ``package`` attribute on ``<manifest>`` as the device reads it, or None.

        getAttributeValue(null, "package") (ApkLiteParseUtils / ParsingPackageUtils): by name with no
        namespace, the raw string first, else the value's coerceToString text — not ``attr()``,
        which a ResID can redirect. None when that read is null, throws, or has a text this host
        cannot render; the dispatch replay says why the install then fails.
        """
        if self.root is None:
            return None
        text = by_name_text(self.root, None, "package")
        return text if isinstance(text, str) else None

    def iter(self, tag: str | None = None) -> Iterator[Element]:
        """Depth-first iterate all elements, optionally filtered by tag."""
        if self.root is None:
            return
        yield from self.root.iter(tag)

    @property
    def roots(self) -> list[Element]:
        """Every top-level element in document order; the first is ``root``.

        The parsers read the first one XmlBlock keeps (docs/flag-model-design.md). The others are
        built on first ask, through the same depth cap as ``root``.
        """
        if self._roots is None:
            utf8 = self._doc.get("string_pool", {}).get("encoding") == "utf8"
            extra = [
                Element.from_dict(d, utf8=utf8) for d in self._doc.get("roots", [])[1:]
            ]
            if (
                self._apk_path is not None
            ):  # their TypedArray rows come from the table too
                for r in extra:
                    for e in r.iter():
                        e.row_source = self
            self._roots = ([self.root] if self.root is not None else []) + extra
        return self._roots

    @property
    def dispatch(self) -> Replay:
        """The device's full base parse dispatch, replayed over this tree (``dispatch.replay``)."""
        if self._dispatch is None:
            self._dispatch = replay(self)
        return self._dispatch

    def components(self) -> list[Element]:
        """Return the components the DEVICE registers (activity/service/receiver/provider/alias).

        Read through the replayed dispatch, not the XML tree: a component nested where a handler
        leaves its subtree is registered, one where a loop skips it is not (tests/device_golden).
        Components registered only under a device condition are included (see component_entries);
        none when the device refuses the manifest.
        """
        r = self.dispatch
        if r.install_error is not None:
            return []
        return [
            d.element
            for d in r.dispatched
            if d.outcome == "read" and d.effect in _COMPONENT_TAGS
        ]

    def permissions(self) -> list[str]:
        """Return the permissions the DEVICE requests from this manifest.

        Any of the uses-permission tag names, read where the dispatch reads them, with the
        parser's own value rules (a plain-string name; the SDK range); none when the device
        refuses the manifest. Permissions the device adds on its own (split permissions for an
        older targetSdkVersion) are not in it.
        """
        r = self.dispatch
        if r.install_error is not None:
            return []
        out: list[str] = []
        for d in r.effective("uses-permission"):
            name = non_resource_string(d.element, ATTR["name"])
            if isinstance(name, str):
                out.append(name)
        return out

    def permission_entries(self) -> list[dict[str, Any]]:
        """Every uses-permission-family element, each with what the device does.

        Over every top-level element: the device reads the first one XmlBlock keeps, which a
        flagged decoy before the real <manifest> can make the second.
        """
        return [
            self._entry(e, {"uses-permission"})
            for r in self.roots
            for e in r.iter()
            if e.tag in _PERMISSION_TAGS
        ]

    def component_entries(self) -> list[dict[str, Any]]:
        """Every component-tag element, each with what the device does (over every root)."""
        return [
            self._entry(e, set(_COMPONENT_TAGS))
            for r in self.roots
            for e in r.iter()
            if e.tag in _COMPONENT_TAGS
        ]

    def _entry(self, e: Element, effects: set[str]) -> dict[str, Any]:
        shown = e.attr("name")
        # a uses-permission's name: getNonResourceString; a component's: getNonConfigurationString
        # (ParsedComponentUtils:47), which resolves a reference
        device_name = (
            non_resource_string(e, ATTR["name"])
            if "uses-permission" in effects
            else non_config_string(e, ATTR["name"])
        )
        out: dict[str, Any] = {
            "tag": e.tag,
            "name": (
                device_name
                if isinstance(device_name, str)
                else (shown.value if shown else None)
            ),
            "line": e.line,
        }
        if shown is not None and shown.value != device_name:
            # what a tree reader shows (name first) when the device reads another value by ResID
            out["name_shown_by_tree_readers"] = shown.value
        r = self.dispatch
        d = r.of(e)
        if r.install_error is not None:
            out["device"] = (
                f"the device does not install this manifest: {r.install_error}"
            )
        elif d is None or d.outcome != "read" or d.effect is None:
            why = (d.because if d is not None and d.because else None) or (
                d.outcome.replace("_", " ") if d is not None else "not reached"
            )
            out["device"] = (
                f"not read in any flag setting run (not every setting was run): {why}"
                if r.capped is not None
                else f"not read by the device: {why}"
            )
        elif d.effect not in effects:
            out["device"] = (
                f"not read as a <{e.tag}>: the <{d.owner}> loop reads it as {d.effect}"
            )
        else:
            out["device"] = "read"
            if r.hidden(d):
                out["hidden"] = r.how_hidden(d)
            if d.effect in _COMPONENT_TAGS:
                enabled = self.component_enabled(e)
                if enabled is not True:
                    out["enabled"] = (
                        enabled if isinstance(enabled, bool) else enabled.why
                    )
        if d is not None and d.conditions:
            out["conditions"] = list(d.conditions)
        return out

    def component_enabled(self, e: Element) -> bool | Unresolved:
        """Say whether the device enables a registered component.

        Its own android:enabled and its application's, each as the device's styleable read takes
        it (TypedArray.getBoolean): an enabled placed where the walk passes it is not read.
        """
        d = self.dispatch.of(e)
        own = get_boolean(e, ATTR["enabled"], True)
        app = d.owner_element if d is not None else None
        while app is not None and app.tag != "application":
            o = self.dispatch.of(app)
            app = o.owner_element if o is not None else None
        of_app = get_boolean(app, ATTR["enabled"], True) if app is not None else True
        for v in (own, of_app):
            if isinstance(v, Throws):
                # the device's string load throws here and its parse fails; the replay does not
                # read android:enabled, so it does not carry that into the install
                return Unresolved(
                    f"android:enabled is {v.why} (the device's parse throws on it; not "
                    "applied to the install here)"
                )
            if v is not True:
                return v
        return True

    def tree_permissions(self) -> list[str]:
        """Every uses-permission-family ``android:name`` in the XML tree, at any depth (a tree read)."""
        out: list[str] = []
        for e in self.iter():
            a = e.attr("name") if e.tag in _PERMISSION_TAGS else None
            if a and isinstance(a.value, str):
                out.append(a.value)
        return out

    def tree_components(self) -> list[Element]:
        """Every component-tag element in the XML tree, at any depth (a tree read)."""
        return [e for e in self.iter() if e.tag in _COMPONENT_TAGS]
