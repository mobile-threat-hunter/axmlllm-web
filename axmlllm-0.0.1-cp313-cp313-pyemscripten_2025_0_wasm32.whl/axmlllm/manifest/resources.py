"""resources.arsc resolution — resolve manifest ``@ref`` values the device way.

Backed by the native ``ArscResolver`` (real AOSP ``ApkAssets`` + ``AssetManager2``):
``GetResource`` (best-config) + ``ResolveReference`` (20-hop chain). We CALL AOSP — no
resolution logic is reimplemented. AOSP: AssetManager2.cpp:1126.

``config_axes`` is the ``CONFIG_*`` bitmask of axes the value varies with (nonzero ⇒
config-dependent — a hiding-across-configs hint). Full per-variant enumeration (to flag
``config_value_divergence`` outright) is a later milestone.

Reference chains are instrumented (``was_reference`` / ``resolved_id`` / ``ref_hops`` /
``ref_terminal`` on ``Resolution``): AOSP chases them and keeps only the endpoint, which mixes
the chain's head and tail into one record and hides its shape. Chain depth and dead ends are
themselves obfuscation signals — see the ``ref_chain_deep`` / ``ref_cycle`` detectors.
"""

from __future__ import annotations

import errno
import glob
import os
from dataclasses import dataclass, field, replace
from typing import TYPE_CHECKING, Any

from .._axml_core import ArscResolver as _ArscResolver
from .._axml_core import TableLoadError
from .._axml_core import arsc_entry as _arsc_entry
from .._axml_core import arsc_inflate as _arsc_inflate

if TYPE_CHECKING:  # a stub-only type: the extension has no such runtime name
    from .._axml_core import ArscEntry

# Value pools run to ~181k strings (the SDK framework table) and 3-4k (a typical app); page the
# native read so a hostile stringCount cannot make one call materialize an unbounded list of
# Python strings. See _IndexTally for the other half of that bound.
_POOL_PAGE = 4096
# How many individual flagged pool indices a PoolGap enumerates. Counts stay exact past this.
_MAX_GAP_INDICES = 1024


def arsc_inflate(apk_path: str) -> dict[str, Any] | None:
    """Replay the device's inflate of ``resources.arsc`` without allocating its declared size.

    ``zip_archive::Inflate`` with the entry's declared lengths and no CRC — the call
    ``ZipUtils::inflateToBuffer`` makes for ``_CompressedAsset::getBuffer`` — into a writer that
    only counts. ``code != 0``: the device's inflate of this entry fails, whatever its memory.
    None unless the entry is found and deflated (a stored entry is mapped, not inflated).
    """
    return _arsc_inflate(native_path(apk_path))


def arsc_entry(apk_path: str) -> ArscEntry:
    """Look up the APK's ``resources.arsc`` the way the device's loader does.

    Asked of AOSP's own archive library with the loader's own two calls (``OpenArchive`` +
    ``FindEntry``), never of another zip parser: a second parser is a second opinion an attacker
    can split from AOSP's. One byte (the central directory's "version needed") made Python's
    ``zipfile`` refuse an archive whose table AOSP loads, so the table read "absent"; a name
    differing only in case is found by case-insensitive tools and never by the device.

    ``code`` is libziparchive's raw answer: 0 = found, ``ZIP_ENTRY_NOT_FOUND`` = none listed, any
    other = listed but refused, on which the device loads an empty table exactly as for none.
    ``stage == "open"`` means the archive did not open for this lookup (``code`` says why).
    """
    return _arsc_entry(native_path(apk_path))


def native_path(path: str) -> bytes:
    """Encode a path for the binding: bytes, since a sample's file name need not be UTF-8.

    A NUL cannot be in a file name, and the binding hands the bytes to C as a string, which would
    silently stop at it and open a DIFFERENT file — so a path holding one is refused here.
    """
    raw = os.fsencode(path)
    if b"\0" in raw:
        raise ValueError("path contains a NUL byte")
    return raw


def _stack(paths: list[str], purpose: str = "stack") -> _ArscResolver:
    """Build the native resolver over these paths (see native_path).

    ``purpose`` — ``stack`` (the table), ``fallback`` (the table without a refused framework),
    ``probe:<i>`` (a split's own load check) — tags a worker's load log by structure, so a
    discarded attempt's AOSP text is never read as the table's.
    """
    return _ArscResolver([native_path(p) for p in paths], purpose)


def _source(d: dict[str, Any]) -> str | None:
    """Return a value's stack element path as the str the caller passed (the binding sends bytes)."""
    raw = d.get("source")
    return None if raw is None else os.fsdecode(raw)


def _same_file(a: str, b: str) -> bool:
    try:
        return os.path.samefile(a, b)
    except OSError:
        return False


def discover_framework() -> str | None:
    """Locate a framework resource table so ``@android:`` (0x01......) refs resolve.

    The Android SDK platform ``android.jar`` bundles the framework ``resources.arsc`` (it is a
    zip ApkAssets can load), so it serves as the framework-res stack element. Returns the
    highest-API ``android.jar`` found under the SDK, or None. Framework resource IDs are frozen
    public API, so any recent platform resolves ``@android:`` refs correctly.
    """
    roots = [
        os.environ.get("ANDROID_HOME", ""),
        os.environ.get("ANDROID_SDK_ROOT", ""),
        os.path.expanduser("~/Android/Sdk"),
        "/usr/lib/android-sdk",
    ]
    found: list[str] = []
    for root in roots:
        if root:
            found += glob.glob(
                os.path.join(root, "platforms", "android-*", "android.jar")
            )
    if not found:
        return None

    def _api(path: str) -> int:
        part = path.split("android-", 1)[-1].split(os.sep, 1)[0]
        return int(part) if part.isdigit() else -1

    return max(found, key=_api)


# A real app ships a handful of config splits (density/locale/abi) plus a few feature splits —
# a few dozen at most. Cap accepted splits so an attacker-controlled directory stuffed with valid
# split_*.apk cannot turn every resolve() into an O(splits) package-group walk (a DoS). _MAX_SCAN
# separately bounds how many candidates are even parsed, so a flood of NON-member split_*.apk
# (each excluded, but each costing a manifest parse) cannot DoS discovery itself.
_MAX_SPLITS = 64
_MAX_SCAN = 512


def _apk_package(apk_path: str) -> str | None:
    """Return an APK manifest's ``package`` attribute, or None if it cannot be read.

    Used to verify split membership. Imported lazily to avoid a resources<->model import cycle.
    """
    from .model import Manifest  # lazy: model imports this module at load time

    try:
        return Manifest.from_apk(apk_path).package
    except RuntimeError:  # the native parse rejects bytes only with std::runtime_error
        return None


def discover_splits(apk_path: str) -> tuple[str, ...]:
    """Sibling split APKs of ``apk_path`` — this app's ``split_*.apk`` files next to the base.

    Opt-in helper for an analyst who has a trusted split set on disk. It is NOT called by the
    default per-APK flow: auto-mounting sibling files from an attacker-controlled directory is a
    resolution-contamination / detector-suppression surface and breaks reproducibility (see the
    ``Manifest.resources`` note). Pass the result to ``ResourceTable(extra_apks=...)`` explicitly.

    Play delivers an app as a base APK plus config/feature splits named ``split_config.*.apk``
    (density/locale/abi) and ``split_<feature>.apk``, installed together into one shared package
    (0x7f). Because every app uses 0x7f, a filename match alone would also pull in a DIFFERENT
    app's split that happens to share the directory, merging its resources into this app's package
    group — so each candidate's manifest ``package`` MUST equal the base's to be included. Symlink
    self-references are excluded by real path, results are capped (``_MAX_SPLITS``) and sorted for
    a deterministic stack order. Empty for the common single-file sample.
    """
    directory = os.path.dirname(os.path.abspath(apk_path))
    base_real = os.path.realpath(
        apk_path
    )  # resolve symlinks so a self-link is excluded
    base_pkg = _apk_package(apk_path)
    # glob.escape the directory: a base whose path contains glob metacharacters ([, ], ?, *)
    # would otherwise make glob mis-parse the fixed directory component and silently miss splits.
    pattern = os.path.join(glob.escape(directory), "split_*.apk")
    hits: list[str] = []
    for p in sorted(glob.glob(pattern))[:_MAX_SCAN]:
        if os.path.realpath(p) == base_real:
            continue  # the base itself, reached via a split_*-named symlink
        if base_pkg is None or _apk_package(p) != base_pkg:
            continue  # a foreign / unreadable APK sharing the directory — not this app's split
        hits.append(p)
        if len(hits) >= _MAX_SPLITS:
            break
    return tuple(hits)


def _load_failure(apk_path: str, index: int = 0) -> TableLoadError | None:
    """Whether an APK loads on its own as a resource table (best-effort split gate).

    A sibling ``split_*.apk`` is matched by name only, so it may be corrupt, foreign, or arsc-less.
    The native stack load is all-or-nothing, so a single bad split would sink the whole table — and
    since the base's byte-level tamper detectors need a loaded table (they stop only on
    ``resources_status == "load_failed"``), that would let an attacker SUPPRESS them (and raise a
    false ``arsc_load_failed`` on the healthy base) just by planting a broken ``split_*.apk``
    next to it. So each split is probed here first and
    dropped if it won't load.

    **This bounds per-APK loadability, and only that.** A stack-wide quantity cannot be bounded by
    probing one file at a time, and there is one: AOSP assigns dynamic packages ids from a counter
    that spans the whole stack (AssetManager2.cpp:174 vs :175), so splits that each load alone can
    still push it past 0xFF together — and #13's guard then refuses the assembled stack, giving
    the healthy base ``load_failed`` after all. The refusal names the reason and says the bound is
    stack-wide, so the outcome is reported rather than silent; narrowing it further would mean
    reimplementing AOSP's counter here, a second source of truth for the same rule.
    """
    # A NUL is refused here: inside the try it read as "will not load" and the split was dropped.
    native_path(apk_path)
    try:
        _stack([apk_path], f"probe:{index}")
        return None
    except (
        TableLoadError
    ) as exc:  # the constructor's own account of why it would not load
        return exc


# A field holding a stack element's FILE PATH. The path is the operator's own input and, as the
# sample's file name, attacker-chosen bytes (a raw newline and forged text reached answers an LLM
# reads, unclipped): tools leave every field so marked out of their answers (tools._public), by
# the field's declaration — not by a key name — and the Python API keeps it.
PATH_FIELD = {"path": True}


@dataclass(frozen=True)
class StackDrop:
    """A stack member the best-effort policy left out, and AOSP's reason (never silent)."""

    role: str  # "framework" | "split"
    path: str = field(metadata=PATH_FIELD)
    cause: str  # TableLoadError.cause
    message: str
    not_judged: str | None = (
        None  # host_judgement: why THIS host, not AOSP, may have refused it
    )


@dataclass(frozen=True)
class LoadFailure:
    """How the resolver's constructor refused the stack: which member, and why."""

    cause: str  # load_rejected | allocation_failed | unindexable_package_id | set_apk_assets_failed
    element: int  # index into the stack (the cookie); -1 = the stack as a whole
    role: str  # "base" | "split" | "framework" | "stack"
    message: str
    not_judged: str | None = (
        None  # host_judgement: why THIS host, not AOSP, may have refused it
    )


def host_judgement(exc: TableLoadError) -> str | None:
    """Whether THIS host, rather than AOSP's verdict on the bytes, ended a load — and how.

    Asked of the host, not modelled: the native witness records every refusal the host returned to
    AOSP's code inside that member's ApkAssets::Load (an allocator's NULL, an mmap / dup / fdopen
    refused for memory or descriptors, ANY failed open — the path is the caller's, never the
    bytes' — and zlib's Z_MEM_ERROR). Any refusal, or a bad_alloc out of Load (allocation_failed),
    means this host ended it: not judged, and the note names the last refusal witnessed (which
    one ended the load is not measured; any refusal is enough). None: no refusal — AOSP's own
    verdict on the member's bytes.
    """
    refusals = getattr(exc, "host_refusals", None) or []
    if refusals:
        last = refusals[-1]  # oldest first: the last witnessed
        err = errno.errorcode.get(last["errno"], "") if last["errno"] else ""
        size = f" of {last['size']} bytes" if last["size"] else ""
        more = getattr(exc, "host_refusal_count", len(refusals)) - 1
        return (
            f"this host refused AOSP's loader: {last['call']}{size}"
            + (f" ({err})" if err else "")
            + (f", after {more} more" if more > 0 else "")
        )
    if exc.cause == "allocation_failed":
        return "AOSP's loader could not allocate the memory it needed here"
    return None


def _failed(
    exc: TableLoadError, roles: list[str], dropped: list[StackDrop]
) -> TableLoadError:
    """Attach the failing member's role and the drops made before it, for the caller to read."""
    exc.role = roles[exc.element] if 0 <= exc.element < len(roles) else "stack"
    exc.dropped = tuple(dropped)
    return exc


@dataclass(frozen=True)
class Resolution:
    """The resolved value of one resource id (device best-config match)."""

    id: str
    type: str
    value: object
    entry_name: str | None = None
    type_name: str | None = None
    config: str = "default"
    # ``config_axes`` is the CONFIG_* bitmask the value varies with (SPEC_* visibility bits are
    # masked off natively — see emit_flags). ``public`` is the SPEC_PUBLIC flag (declared in
    # public.xml); app resources default to private. ``staged`` is the rare SPEC_STAGED_API flag.
    config_axes: int = 0
    public: bool = False
    staged: bool = False
    # Cookie attribution: which ApkAssets in the stack supplied the winning value. ``cookie`` is
    # the stack index (-1 if unreported); ``source`` its path; ``source_role`` one of
    # ``"base" | "split" | "framework"``. A ``split`` role means a base-only tool would not see
    # this value — the device selected a split's over the base's. This is the FACTUAL split-override
    # signal (anomalies.py deliberately does not turn it into a zero-FP-impossible boolean).
    cookie: int = -1
    source: str | None = field(default=None, metadata=PATH_FIELD)
    source_role: str | None = None
    # Reference-chain instrumentation (#3). AOSP chases ``@a -> @b -> "x"`` inside
    # ``ResolveReference`` and discards every trace, leaving the chain HEAD (``id``/``entry_name``)
    # and TAIL (``type``/``value``/``config``) mixed in one record. These keep them apart:
    # ``was_reference`` says the stored value was indirected at all, ``original_type`` is its
    # pre-resolution type, and ``resolved_id``/``resolved_name`` name the terminal the chase
    # reached (``resolved_name`` is ``package:entry`` — a chain crossing into an unexpected package
    # is visible here). All None/empty when the value was stored directly.
    was_reference: bool = False
    original_type: str | None = None
    resolved_id: str | None = None
    resolved_name: str | None = None
    # ``ref_hops`` is the id sequence the chase visited, in order (exactly the ids the device
    # visits — the trace walks AOSP's own iteration count, so ``resolved_id == ref_hops[-1]``
    # always). ``ref_terminal`` is why it stopped: ``value`` (reached a real value), ``null``
    # (@null), ``self`` (the hop points at itself — either a true self-reference OR a bag, which
    # AOSP represents the same way; ``entry_is_complex`` tells them apart — NOT ``is_bag``, see
    # its docstring), ``cycle`` (an id recurred, so the hop budget is what ended the walk),
    # ``max_hops`` (longer than AOSP's 20-hop bound with no repeat, so the device gives up),
    # ``unresolved`` (a hop names an id no loaded package defines).
    ref_hops: tuple[str, ...] = ()
    ref_terminal: str | None = None
    # Set when AOSP's own ``ResolveReference`` reported failure: ``not_found`` | ``io_error``.
    # Previously this return value was dropped, so a failed chain was only inferable from the
    # type staying ``reference``.
    resolve_error: str | None = None
    # #17: how many PACKAGES define this id, when more than one — a dynamic (shared-library)
    # package landing on the app's runtime id joins its group, and the id then names two entries
    # while ``value`` shows only the one AOSP picks. ``contention`` says what kind: see
    # ``ResourceEntry.contention``. 0 / None when one package defines it.
    contending_packages: int = 0
    contention: str | None = None

    @property
    def config_dependent(self) -> bool:
        """True if the value varies across configurations (a hiding signal)."""
        return self.config_axes != 0

    @property
    def ref_hop_count(self) -> int:
        """Number of ids the reference chase visited (0 when the value was stored directly)."""
        return len(self.ref_hops)


def _to_id(res_id: str | int) -> int:
    """Coerce ``0x..`` / ``@0x..`` / ``?0x..`` / int to a numeric resource id."""
    if isinstance(res_id, int):
        return res_id
    return int(res_id.lstrip("@?"), 16)


@dataclass(frozen=True)
class ConfigVariant:
    """One configuration's value for a resource id (a device-selectable variant)."""

    config: str
    type: str
    value: object


@dataclass(frozen=True)
class BagEntry:
    """One key-value item of a bag (an array item, or a style/theme attribute)."""

    key: str
    type: str
    value: object
    # For a style/theme, ``key`` is an attr resource id and ``key_name`` is its canonical name
    # (e.g. ``android:windowBackground``); for an array/plurals the key is a synthetic index and
    # ``key_name`` is None. ``source``/``source_role`` attribute the item to a stack APK (see #7).
    key_name: str | None = None
    # When ``value`` is a reference (``@0x..``), ``resolved``/``resolved_type`` carry its one-shot
    # resolved terminal scalar (a style's @drawable/@color, an array of @string refs) so the real
    # value is visible without a second lookup; None when the value is inline or resolves to a bag.
    resolved: object = None
    resolved_type: str | None = None
    cookie: int = -1
    source: str | None = field(default=None, metadata=PATH_FIELD)
    source_role: str | None = None


@dataclass(frozen=True)
class Bag:
    """A resolved complex (map) resource — a style/theme, array/string-array, plurals, or attr.

    The bag counterpart of ``Resolution``: the device flattens the parent/inheritance chain
    (AOSP ``GetBag``) into this key-value list. ``entry_count`` is the true count; ``entries`` may
    be capped (``truncated``) against a hostile table. ``config_axes`` nonzero ⇒ config-dependent.
    ``public``/``staged`` are AOSP's flattened visibility (OR of the bag's own flags with the
    inherited parent chain), i.e. the device-effective value — a private child style inheriting a
    public parent reports ``public=True`` — not necessarily the id's own ``public.xml`` declaration.

    ``parent_cycle``: the parent chain loops back on itself (#15). AOSP's bag cache keeps a
    parent-less copy of the cycle's inner id from whichever walk reached it first, so on a device
    the items depend on which bag the app inflated first. This is AOSP's answer when THIS id is the
    first asked in a fresh process — which every ask is here — not the only one a device can show.

    ``refused``: set when this resolver declined to build the bag, so the empty ``entries`` are
    NOT AOSP's answer — ``"parent_chain"`` for a chain refused before ``GetBag`` could recurse
    without bound (too deep, too costly to walk, a complex parent it could not read, or a loop
    ``GetBag`` never ends), ``"work_cap"`` for a build that would copy more than one ask may
    (2^20 entries; the corpus maximum is 28,128). Both depend on the id alone.
    """

    id: str
    entries: list[BagEntry]
    entry_count: int
    truncated: bool
    entry_name: str | None = None
    type_name: str | None = None
    config_axes: int = 0
    public: bool = False
    staged: bool = False
    parent_cycle: bool = False
    refused: str | None = None


class _IndexTally:
    """Counts pool indices exactly while retaining only the first ``_MAX_GAP_INDICES`` of them.

    ``_POOL_PAGE`` bounds each native call, but accumulating one Python int per flagged slot
    across every page undoes that: ``ResStringPool::setTo`` bounds ``stringCount`` only by
    ``stringCount * 4 <= chunkSize`` (ResourceTypes.cpp:572-580), so four bytes of a highly
    compressible offset table buys one retained index. A 245 KB APK reached 3.2 GB RSS this way —
    a whole corpus run killed by one sample, taking every already-processed result with it.

    The COUNT stays exact, because that is what a coverage figure rests on; only the enumeration
    is capped, and ``truncated`` says when it was.
    """

    __slots__ = ("count", "_kept")

    def __init__(self) -> None:
        self.count = 0
        self._kept: list[int] = []

    def extend(self, indices: list[int]) -> None:
        self.count += len(indices)
        if len(self._kept) < _MAX_GAP_INDICES:
            self._kept.extend(indices[: _MAX_GAP_INDICES - len(self._kept)])

    @property
    def indices(self) -> tuple[int, ...]:
        return tuple(self._kept)

    @property
    def truncated(self) -> bool:
        return self.count > len(self._kept)


_IGNORED_CHUNK_REASON = {
    # Which AOSP branch stepped over the chunk. Defaulting every finding to LoadTable's wording
    # named the wrong mechanism for every level but one.
    "file": "a pool chunk beside the resource table; LoadedArsc::Load parses only RES_TABLE_TYPE",
    "table": "a second pool chunk in the table; the runtime keeps only the first in the whole file",
    "package": "a pool chunk in a package beyond the two it consumes (type/key strings)",
    "overlayable": "a pool chunk inside an overlayable chunk, which holds only policy records",
    "skipped_chunk": "a pool chunk inside a chunk the runtime skipped whole, so it is never parsed",
}


@dataclass(frozen=True)
class EntryRef:
    """One scalar resource entry that STORES a value-pool string — a hit's attribution.

    The join is an exact equality, not an inference: a scalar entry whose ``Res_value.dataType``
    is ``TYPE_STRING`` holds the pool index verbatim in ``data``. It is read from the stored bytes
    of the entry, so an alias (which stores ``TYPE_REFERENCE``) can never claim its target's
    string.

    ``config`` is the configuration of the ``ResTable_type`` chunk the entry was found in, so the
    same id appears once per config that defines it — a string only a ``values-<locale>/`` variant
    selects is attributed, and says so.

    ``id`` is always the id the RUNTIME addresses this entry by, rather than the one composed
    from the stored package byte, so it is the form to feed back into ``resolve``/``declared``/
    ``resolve_bag``. It identifies a SLOT, not this row: a resource id has no field for which
    package supplied it, and AOSP deliberately merges every package sharing a runtime id into one
    group it searches in order (``FindEntryInternal``, AssetManager2.cpp:920-930). So where two
    packages define the same type and index — a split overriding its base, a crafted duplicate —
    several rows carry one id and a lookup returns whichever AOSP selects. That is attribution
    working as intended, not a defect, but it is the reason ``entries`` is a list. See also
    ``enumerated_id``: under a non-zero ``typeIdOffset`` neither id form is guaranteed to
    resolve. ``package_id`` is the id **stored in the arsc**,
    which for a ``dynamic_package`` (shared library) is ``0x00`` while the runtime assigns one at
    load (#7) — the one place the two differ. Both are reported so that difference is visible
    rather than inferred; an earlier cut built ``id`` from the stored byte, and so emitted ids this
    same object's ``declared()`` correctly denied.
    """

    id: str
    type_name: str | None
    entry_name: str | None
    config: str
    package_id: int
    dynamic_package: bool = False
    # True when ``entry_name`` is absent because the walk's retained-name byte budget was already
    # spent, NOT because the pool could not be decoded. Deduplicating identical names does not
    # bound memory — a pool's offsets may point anywhere in its data section, so strings can
    # OVERLAP, and the distinct bytes they name are quadratic in the pool. Past the budget a name
    # is omitted; never truncated, since a shortened name is a fabricated resource name.
    name_omitted: bool = False
    # Set only when AOSP's two resource-id conventions disagree for this entry's type, which
    # happens exactly when the package carries a non-zero ``typeIdOffset`` (``type_id_offset``
    # below). ``id`` is the stored-type-id form, the one AOSP's config-filtered entry lookup is
    # keyed by, while THIS field carries ``stored id + offset``, the form AOSP's own enumeration
    # (``LoadedPackage::iterator``, ``FindEntryByName``) emits. **Neither is guaranteed to resolve** — reaching an entry needs
    # both lookups to land, which requires a type with stored id ``S - offset`` to exist as well,
    # and for an aapt2 feature split that is true of no type in the package. Both are reported and
    # neither is claimed; try both. Absent — the normal case — means the two agree.
    enumerated_id: str | None = None
    # The package's ``ResTable_package::typeIdOffset``, present only when it is non-zero and has
    # therefore split the two conventions apart.
    type_id_offset: int | None = None


@dataclass(frozen=True)
class EntryScan:
    """What the attribution walk read in one stack element — the account behind ``entries``.

    An empty ``StringHit.entries`` means "no scalar entry of this stack element stores this pool
    index" **only when that hit's ``entries_truncated`` is False** — every path on which the walk
    drops an entry (its scan budget, a refused entry, an unverifiable trailing value, a chunk
    skipped whole) can otherwise produce an empty, unflagged-looking attribution for a string a
    real entry holds, and an attacker chooses which entries fall down which path. It never means
    "this string is not really in the table". These counters are what the verdict rests on, and the known reasons a
    real string is unattributed are all visible here or in the design doc: a bag item
    (``complex_entries``), a feature-flag name, a string no entry references at all, or an entry
    the walk could not read (``unreadable_entries`` / ``unverified_values``) or did not reach
    (``unwalked_chunks`` / ``scan_capped`` / ``store_capped``).

    The counts relate as ``scanned_entries == string_entries + complex_entries +
    unverified_values + (scalar entries storing something other than a string)``. A ``NO_ENTRY``
    hole is not an entry and is in none of them; ``unreadable_entries`` counts entries that were
    never read, so it is outside ``scanned_entries`` too. ``out_of_pool_values`` is a **subset of**
    ``string_entries``, not a sibling — adding the two double-counts.
    """

    cookie: int
    source: str | None = field(metadata=PATH_FIELD)
    source_role: str | None
    # False when the element's table holds no packages at all — so there were never any entries to
    # walk. Distinct from the walk being skipped, which shows as this element having no EntryScan.
    table_present: bool
    packages: int
    scanned_entries: int
    string_entries: int
    complex_entries: int
    # Entries the verifier refused: an offset that could not be read, or bytes that claim to be an
    # entry and are not. Counted per entry.
    unreadable_entries: int
    # Entries whose trailing Res_value AOSP's verifier does not validate for room (not flagged
    # complex, yet sized like a map). The device reads it anyway through unchecked pointer
    # arithmetic; this walk touches every entry, so it re-checks and skips instead of risking a
    # read past the mapping. Each one is an attribution not made.
    unverified_values: int
    # String-valued entries the pool will not hand bytes over for: past its end, OR inside a
    # `stringCount` the header over-declares. No reader can fetch them either way, so they are not
    # recorded — an anomaly in their own right. Both halves, because `size()` is the count the
    # header CLAIMS; the enumeration surface moved to this boundary first and the two now agree.
    out_of_pool_values: int = 0
    # Whole config chunks abandoned before any entry was read, with the entry count they DECLARE.
    # Two fields because one skipped chunk is not one skipped entry: a chunk may declare 65535,
    # and reporting it as "1 unreadable entry" understated the gap by that factor.
    unwalked_chunks: int = 0
    unwalked_chunk_entries: int = 0
    # Entry-name SLOTS — distinct ``(key pool, key index)`` pairs — whose name was not decoded
    # because the retained-name byte budget was spent. An **upper bound** on the distinct names
    # lost, not a count of them: the omission path cannot de-duplicate by bytes the way the kept
    # path does (that would mean retaining the bytes the budget just refused), so several indices
    # aliasing one string are counted once each. Rows carry ``name_omitted`` individually and
    # there may be more of those than this, since several rows can name one dropped slot.
    # Zero on any ordinary table.
    #
    # The ONE field here that describes the CALL rather than the cached walk. The budget is spent
    # across all of an element's hits in ascending pool-index order, so for a FIXED query it is
    # reproducible and ordered by the table — but the set of hits is what `needle`, `limit`,
    # `ignore_case` and `include_framework` decide, so all of them change it. Every sibling
    # counter is a property of the walk and is identical across queries; this one is not.
    names_omitted: int = 0
    # Name slots whose bytes were read but did not decode as text. Distinct from
    # ``names_omitted``: those rows carry ``name_omitted``, these show an absent ``entry_name``
    # with the flag clear. Counted because their bytes are still charged against the budget, so
    # they cost OTHER resources their names — silently, without this.
    names_undecodable: int = 0
    # The walk's entry-inspection bound was reached, so later entries were never examined.
    scan_capped: bool = False
    # The element-wide retention budget was reached, so some string-valued entries were counted
    # but not recorded. Deliberately NOT set by the per-hit cap on how many owners of one string
    # are listed — that is reported on the hit as ``entries_truncated``, where a caller can act on
    # it. At a per-index cap of 64 this fired on 84 of 204 ordinary corpus apps; a flag that trips
    # on normal input tells an analyst nothing.
    store_capped: bool = False


def _match_at(value: str, target: str, ignore_case: bool) -> int:
    """Index in `value` where `target` (folded when `ignore_case`) first matches, by the search's fold.

    `str.casefold` maps characters independently, so folding per character and keeping, for each
    folded character, the index of the one it came from is the fold the search used.
    """
    if not target:
        return 0  # an empty needle matches at the start (and `owner` may be empty)
    if not ignore_case:
        return value.find(target)
    owner: list[int] = []
    parts: list[str] = []
    for i, ch in enumerate(value):
        folded = ch.casefold()
        parts.append(folded)
        owner.extend([i] * len(folded))
    j = "".join(parts).find(target)
    return owner[j] if j >= 0 else -1


@dataclass(frozen=True)
class StringHit:
    """One value-pool string matching a search, and where it was read from."""

    value: str
    pool_index: int
    cookie: int
    source_role: str | None = None
    source: str | None = field(default=None, metadata=PATH_FIELD)
    # True when the stored value carries an embedded NUL, so the app's own JNI path
    # (``NewStringUTF``) stops early while we read the whole string. Prefer this to a truth-test on
    # ``device_truncates_at``: that field is legitimately **0** when the NUL is the first byte —
    # the maximum truncation, where the device sees the empty string — and ``if
    # hit.device_truncates_at:`` would classify precisely that worst case as untruncated.
    device_truncated: bool = False
    # Where the app stops, as a **byte** offset into ``value.encode()`` — NOT a ``str`` index.
    # They differ for any value with non-ASCII before the NUL: "日本\x00secret" truncates
    # at byte 6 while "secret" begins at character 3, so comparing a ``value.find()`` result
    # against this would wrongly conclude the device sees the tail.
    device_truncates_at: int | None = None
    # True when the value's bytes are not valid text and U+FFFD was substituted. The value stays
    # searchable — an ASCII needle around the bad byte still matches — but is not byte-exact.
    undecodable: bool = False
    # The scalar entries that store this pool index, within THIS hit's stack element. One-to-many
    # (the pool is de-duplicated, and one id appears once per config that defines it) or none.
    # Empty is not an error and never a filter — see EntryScan for what it does and does not mean.
    # Capped: one ResTable_type chunk may declare 65535 offsets that all point at one entry, so
    # this tuple is bounded while entries_total below stays exact.
    entries: tuple[EntryRef, ...] = ()
    # How many stored references to this index the walk found — offset slots, not distinct
    # entries, so a chunk pointing two indices at one entry counts it twice. Exact past the
    # retention caps; a LOWER BOUND when ``entries_truncated`` is set by a capped walk.
    entries_total: int = 0
    # True when this hit's attribution is not the whole story — either the per-index retention cap
    # trimmed ``entries``, or the element's walk DROPPED entries anywhere (its scan budget, a
    # refused entry, an unverifiable trailing value, a chunk skipped whole). In the second case
    # ``entries`` and ``entries_total`` may both be short, and may be EMPTY and ZERO for a string
    # that a real entry stores. Explicit, and deliberately not derivable from
    # ``len(entries) < entries_total``: after a drop both are 0 and that comparison is False,
    # which is exactly how a suppressed attribution used to read as "nothing owns this".
    entries_truncated: bool = False
    # Where the match starts in ``value``, as a ``str`` index — found by the SAME fold the search
    # matched with. Casefolding can change length ("ß" folds to "ss"), so a position in the folded
    # text is not one in the value: review pushed a C2 URL out of a shown window with 400 "ß".
    match_at: int = -1


@dataclass(frozen=True)
class PoolRead:
    """One stack element's value pool that WAS read, and how much of it."""

    cookie: int
    source: str | None = field(metadata=PATH_FIELD)
    source_role: str | None
    values: int
    encoding: str | None


@dataclass(frozen=True)
class PoolGap:
    """Values a search did NOT cover, and why. The counterpart of ``PoolRead``.

    ``indices`` are absolute pool indices when they are known individually; for a whole element
    that was never opened it is empty and ``values`` carries the count.

    ``kind`` separates reasons that do not aggregate together:

    * ``unreadable`` — the pool refused the slot, so no bytes were seen at all.
    * ``mangled`` — the bytes were read but are not decodable, so what was searched is not what is
      stored. Reported for every such value, hit or not: a needle can lie entirely inside the
      substituted run, which makes the value that hides it exactly the one with no hit to flag.
    * ``out_of_scope`` — a deliberate omission the caller can undo (the framework's ~181k stock
      strings, skipped by default).
    * ``chunks_capped`` — a summary of ignored chunks past the enumeration cap. Its ``values``
      is 0 and ``values_unknown`` is set; the exact chunk total is in ``reason``.
    * ``not_inspected`` — the chunk-level walk could not answer: the raw table could not be
      re-read, or the walk stopped early on a malformed chunk. Distinct from every other kind
      because "could not look" must never read as "looked and found nothing".
    * ``ignored_chunk`` — a second ``RES_STRING_POOL_TYPE`` chunk. The runtime keeps only the
      first (LoadedArsc.cpp:839-850), so searching it would be unfaithful and ignoring it silently
      would be a false zero: a decoy first pool leaves the table loading clean, every id resolving,
      and a search covering exactly the decoy. ``values`` is what the chunk CLAIMS, not a count of
      anything read — the chunk is never loaded, so there is nothing to read it with.

    Summing them hides the real gap inside the chosen one — the framework alone outnumbers a
    typical app's whole pool ~50:1, so a combined figure always reads as "covered nothing".

    ``values`` is always the exact count. ``indices`` enumerates at most ``_MAX_GAP_INDICES`` of
    them, with ``indices_truncated`` set when it did not list them all.
    """

    cookie: int
    reason: str
    values: int
    kind: str = (
        # unreadable | mangled | out_of_scope | ignored_chunk | chunks_capped | not_inspected
        "unreadable"
    )
    indices: tuple[int, ...] = ()
    indices_truncated: bool = False
    # True when ``values`` could not be established at all, so 0 means "unknown", not "none".
    values_unknown: bool = False
    # For ``ignored_chunk``: the chunk's size in bytes. This is the one quantity here that was
    # MEASURED — the chunk iterator validated it against the remaining data — whereas ``values``
    # is only what an unvalidated header claims. A chunk whose header is too short to hold a
    # count still has a real size, so this is what survives when ``values_unknown`` is set.
    chunk_bytes: int | None = None
    source: str | None = field(default=None, metadata=PATH_FIELD)
    source_role: str | None = None


@dataclass(frozen=True)
class StringSearch:
    """An account of a value-pool search: the hits, plus exactly what was and was not read.

    There is deliberately no ``complete`` flag. A caller concluding "this string is absent from
    the table" composes that from ``read`` and ``unread`` and can see what it rests on — the first
    implementation of this feature asserted completeness and was wrong five different ways.
    """

    pattern: str
    hits: tuple[StringHit, ...]
    read: tuple[PoolRead, ...]
    unread: tuple[PoolGap, ...]
    # True when ``limit`` cut the hit list short. Coverage is still described by read/unread —
    # this says only that more matches exist among the values that were searched.
    hits_truncated: bool = False
    # One per stack element whose entries were walked to attribute hits. Exactly two things make
    # it empty for an element that produced hits: ``attribute=False``, or no hits to attribute.
    # Anything the walk itself found — including a table with no packages at all — is reported as
    # a scan, so "did not look" is never spelled the same way as "looked and found no owner".
    scans: tuple[EntryScan, ...] = ()

    @property
    def values_read(self) -> int:
        """How many pool values the search actually looked at."""
        return sum(r.values for r in self.read)

    @property
    def values_unread(self) -> int:
        """In-scope values whose bytes were never seen. Reconciles: ``read + unread == total``.

        Excludes ``out_of_scope`` (the caller's own choice, not a limit on what could be read) and
        ``mangled`` (those bytes WERE read, just not faithfully — they are already inside
        ``values_read``, and counting them here too would break the reconciliation above).
        """
        return sum(g.values for g in self.unread if g.kind == "unreadable")

    @property
    def values_mangled(self) -> int:
        """Values searched with U+FFFD substituted — read, but not as stored.

        An absence claim rests on ``values_unread`` **and** this: a needle can sit entirely inside
        the substituted run, so these values were covered in a form that could not have matched.
        """
        return sum(g.values for g in self.unread if g.kind == "mangled")

    @property
    def ignored_chunks(self) -> int:
        """How many string-pool chunks were found that the runtime loads past.

        **Zero is not a clean bill of health.** It means none was found along the paths AOSP's own
        chunk traversal covers — not that none exists. Bytes can be parked inside a chunk's
        declared size without being a chunk at all, and AOSP steps over them exactly as any
        chunk walk does, so no walk of this kind can establish absence. Three review rounds each
        falsified an earlier, stronger wording of this sentence.

        Prefer it to ``values_in_ignored_chunks`` all the same: this counts chunks that were
        actually found, while that sums a number the chunk's own author wrote.
        """
        return sum(1 for g in self.unread if g.kind == "ignored_chunk")

    @property
    def bytes_in_ignored_chunks(self) -> int:
        """Total measured size of those chunks.

        Measured, not claimed: ``ChunkIterator`` validated each size against the remaining data.
        Unlike the string count this cannot be written down to zero while the payload stays.
        """
        return sum(g.chunk_bytes or 0 for g in self.unread if g.kind == "ignored_chunk")

    @property
    def values_in_ignored_chunks(self) -> int:
        """Strings those chunks CLAIM to hold — attacker-written, and not a clean signal.

        Zero does NOT mean nothing is hidden: the count comes off an unvalidated header of a chunk
        that is never loaded, so it can be set to 0 or made unreadable while the strings remain.
        Use ``ignored_chunks`` to decide whether anything was found and ``bytes_in_ignored_chunks``
        for a quantity that was actually measured; check ``ignored_counts_unknown`` before quoting
        this number at all. It is also a partial sum once the enumeration cap is hit.
        """
        return sum(g.values for g in self.unread if g.kind == "ignored_chunk")

    @property
    def ignored_counts_unknown(self) -> bool:
        """True when ``values_in_ignored_chunks`` cannot be quoted as a total.

        Set when any ignored chunk's claimed count was unreadable, or when the enumeration was
        capped so the sum covers only the chunks that were listed.
        """
        return any(
            g.values_unknown
            for g in self.unread
            if g.kind in ("ignored_chunk", "chunks_capped")
        )

    @property
    def values_out_of_scope(self) -> int:
        """Values deliberately not searched (the framework pool, unless include_framework)."""
        return sum(g.values for g in self.unread if g.kind == "out_of_scope")


@dataclass(frozen=True)
class ResourceEntry:
    """One entry as the table STORES it — the enumeration counterpart of ``Resolution``.

    ``resolve`` answers "what does the device select for this id", which is a question about
    configuration. This answers "what is written here", one row per ``ResTable_type`` chunk, so an
    id defined under three configs appears three times and an entry no config selects still
    appears. That is the *present* half of present-vs-consumed, and until #4 it existed only for
    entries whose stored value was a string — the search index is keyed on the value string pool,
    so integers, booleans, colours, dimensions and references were walked and then dropped.

    At most one shape flag is set: ``is_bag`` (items rather than a scalar — use ``resolve_bag``),
    ``unreadable`` (the bytes claim an entry AOSP's verifier refused), or ``unverified`` (a
    trailing ``Res_value`` the verifier does not size-check — reported rather than read). With none
    of them the row is a scalar and ``value_type`` names its type, but ``value`` may still be None —
    and every reason has a name: ``value_omitted`` (the page's byte budget refused it),
    ``out_of_pool`` (no reader, including the device, can fetch bytes for that index),
    ``no_value_pool`` (the table has no usable value pool at all), ``value_undecodable`` (bytes
    that are not text), or — legitimately — ``value_type == "null"``, where None *is* the value.
    Four of those five were unnamed or misnamed until review measured them, and one counted pool
    slots while its siblings counted rows. Test
    ``value_type is not None`` for "this is a scalar", never ``value is not None``.

    ``id`` is built from the RUNTIME package id and the STORED type id, which is the form that
    normally resolves — but it is **not promised** to. Under a non-zero ``typeIdOffset`` AOSP's two
    type-id conventions disagree and neither form is guaranteed to reach the entry: measured on a
    crafted table, at offset 3 all 64 rows are denied by ``declared()``. ``enumerated_id`` and
    ``type_id_offset`` are emitted exactly when the two conventions differ, and are the per-row
    signal that an id may not round-trip. ``EntryRef`` carries the same caveat with the full
    derivation. aapt2 emits a non-zero offset for feature splits, so this is not only hostile.
    """

    id: str
    type_name: str | None
    entry_name: str | None
    config: str
    package_id: int
    value_type: str | None = None
    value: Any = None
    is_bag: bool = False
    unreadable: bool = False
    unverified: bool = False
    #: The stored value is a pooled string the page's byte budget refused. Omitted, never
    #: truncated — a shortened value is a fabricated one.
    value_omitted: bool = False
    #: No reader, including the device, can fetch bytes for this index — either it is past the
    #: pool, or it is inside a ``stringCount`` the header over-declares and the pool refuses it.
    #: Distinct from ``value_undecodable``, where bytes exist but are not text.
    out_of_pool: bool = False
    #: The table has no usable value string pool at all, so no string value in it can be read. Such
    #: a table LOADS — AOSP does not require the pool — and without this flag every string row
    #: would read as "this entry has no value".
    no_value_pool: bool = False
    #: A reference AOSP's ``DynamicRefTable`` could not map. ``value`` is then the build-time id,
    #: which is what the device reads too — the flag says the mapping failed, not that the value
    #: is wrong.
    unmapped_reference: bool = False
    #: The stored value is a pooled string whose bytes are not text this can render. It is IN the
    #: pool and was charged against the page budget — it simply does not decode. Distinct from
    #: ``out_of_pool``, which is "the pool will not hand any bytes over for this index" — including
    #: a slot inside an over-declared ``stringCount``, a shape measured in 71 of 204 corpus APKs.
    value_undecodable: bool = False
    #: ``value_type == "null"`` and the stored data is exactly ``DATA_NULL_EMPTY`` — ``@empty``, an
    #: explicit nothing. AOSP and aapt2 keep that apart from ``DATA_NULL_UNDEFINED`` (``@null``) and
    #: the shared scalar decoder folds both to None, so it is carried here. It is an equality, not a
    #: partition: a crafted ``TYPE_NULL`` with any other data is out of spec and reads as ``@null``,
    #: which is also what aapt2 does.
    null_empty: bool = False
    #: The device configuration this row's definition is SERVED on — one witness, not the only
    #: one — rendered as AOSP renders configurations (``"default"`` for none) (#17). The rendering
    #: is for reading, not for replay: ``toString()`` hides a COMPUTED script, so the exact device
    #: is the ``device`` bytes ``ArscResolver.slot_selection`` returns, which the real
    #: AssetManager2 answers with this row. ``None`` exactly when ``unserved`` or
    #: ``selection_capped`` is set.
    served_on: str | None = None
    #: No device configuration is served this row's definition. A FACT about AOSP's selection,
    #: not a verdict: the stock framework has none, but ordinary apps do — ``anydpi`` beside
    #: density buckets makes every bucket unserved, because ``isBetterThan`` prefers DENSITY_ANY
    #: before it reads the request. ``unserved_reason`` says which kind:
    #:
    #: * ``"never_matches"`` — no device matches the configuration at all (a value no device can
    #:   present, e.g. orientation 4, or a minor version without an sdk version). A decoy's shape
    #:   for devices; ``app_served_on``, when set, says the app's own code reads it — its absence
    #:   says nothing.
    #: * ``"always_outranked"`` — devices match it, and on every one of them another definition
    #:   wins; nor does the all-zero request pick it (another wins there, or none matches).
    #:   Ordinarily a build artefact.
    #: * ``"zero_request_only"`` — outranked on every device, but AOSP picks it on the all-zero
    #:   request (sdk 0) a never-configured AssetManager2 answers — e.g. stock idmap2 reading the
    #:   xml an overlay's ``android:resourcesMap`` names, over that one APK; an app reaches it
    #:   with a raw ``setConfiguration`` (see ``app_served_on``). ``default`` beside a ``-v1``.
    #: * ``"not_consulted"`` — AOSP never puts this definition on the candidate list: its package
    #:   has no runtime id, or fails the type gate at its stored type id.
    #: * ``"unreadable_entry"`` — AOSP cannot read the entry once it picks it, and then fails the
    #:   whole lookup rather than falling back (GetEntryFromOffset, AssetManager2.cpp:972-975): on
    #:   every device it would win, NOTHING is served.
    #:
    #: The device domain is every field undefined or a value the stock framework assigns it — no
    #: SQUARE, STYLUS, 12KEY, WHEEL or navHidden (see ``native/core/selection.h``), so ``layout`` beside ``layout-port`` and
    #: ``layout-land`` is served (orientation undefined).
    unserved: bool = False
    unserved_reason: str | None = None
    #: On an ``unserved`` row: a configuration the APP builds on which AOSP serves this definition
    #: anyway — data no device is ever served, which the app's own code reads on demand. An app
    #: hands AssetManager.setConfiguration (@UnsupportedAppUsage, reflection) any value of any
    #: field, sdk 0 and raw locale strings included. A positive only: found, then confirmed by the
    #: real AssetManager2; None says nothing about whether an app could reach the row.
    app_served_on: str | None = None
    #: That configuration's ResTable_config bytes, in hex — exact where ``app_served_on`` (AOSP's
    #: ``toString``) is not: it drops a grammatical gender past 3, misprints a uiMode type.
    app_device: str | None = None
    #: The app question was not answered for this unserved row — the page's budget for it ran out,
    #: the row's own search bound (2 M) cut it, its slot's candidate list was cut, no tag spells
    #: its locale, or the real AssetManager2 refuted what the search found: no ``app_served_on``
    #: here means NOT ASKED. (A smaller page helps only the first.)
    app_unasked: bool = False
    #: On an ``always_outranked`` row: AOSP's answer on the all-zero request carries this row's
    #: cookie and configuration bytes, but which of the byte-equal definitions it is could not be
    #: proved (the candidate list was cut, or replaying AOSP's loop ended elsewhere) — so
    #: ``zero_request_only`` was neither claimed nor ruled out.
    zero_request_unasked: bool = False
    #: Undecided — neither served nor unserved: a selection budget ran out before this row was
    #: given a witness, or the witness found was not confirmed by the real resolver.
    #: ``EntryPage.selection_capped_rows`` counts them.
    selection_capped: bool = False
    #: For a pooled string value, its index in this element's value pool — set even when the value
    #: is omitted (``value_omitted``), which ``pool_string`` then reads whole.
    pool_index: int | None = None
    #: How many PACKAGES define this row's id — each prints a row under it when the walk reaches it
    #: (an element whose walk is ``scan_capped`` may not show it, though AOSP resolves it) — when
    #: more than one; exact, read once per package type for the resolver's life. The shape #17 is
    #: named for: a dynamic package landing on the app's runtime id (the package-id counter runs
    #: across the whole stack, base and splits alike) joins its group, and every id it defines then
    #: names two entries. Set on every row of the id, the served one included, because the finding
    #: is the shared id; ``unserved`` alone cannot say it (the ballast copy reads
    #: ``always_outranked`` — or ``not_consulted`` behind a typeIdOffset — like a density bucket
    #: beside ``anydpi``). No exemptions: ``contention`` says what kind of sharing it is. Measured
    #: 0 on the 204-APK corpus (with and without the framework) and on the stock framework.
    contending_packages: int = 0
    #: What the sharing is, set exactly when ``contending_packages`` is — EVERY kind that holds,
    #: '+'-joined (e.g. ``"same_element+cross_element"``), never one ranked pick that hides another:
    #:
    #: * ``"dynamic_package"`` — a counter-assigned (shared-library) package is among them: the
    #:   ballast shape.
    #: * ``"same_element"`` — two packages of one APK define the id: one arsc says it twice.
    #: * ``"cross_element"`` — static packages in different APKs: a split overriding its base
    #:   (ordinary), or an app declaring an id another APK already holds, e.g. ``0x01`` beside the
    #:   framework (not ordinary). Which of the two is read off the cookies' roles.
    contention: str | None = None
    dynamic_package: bool = False
    name_omitted: bool = False
    enumerated_id: str | None = None
    type_id_offset: int | None = None


@dataclass(frozen=True)
class EntryPage:
    """One slice of an enumeration, plus the account of what the walk could not cover.

    ``total`` counts the entries matching the filter across the whole element, so ``offset +
    len(entries) < total`` means there is another page. It is exact **within the scan budget** —
    ``scan_capped`` says it is not.

    No PAGE index is retained between calls: a page is produced by walking, counting and
    emitting the slice. That is O(entries) per page rather than O(1) — measured on the 246k-entry
    stock framework and warm, single-digit ms at ``limit=200`` and tens of ms at ``limit=5000``,
    with the first pass over a table paying for the #17 selection (see the design doc for the
    figures and why they are ranges) — and it is deliberate: every memory defect this module has
    had came from bounding a retained index (see the ``#11`` history in the design doc).

    What IS retained across calls is #17 state — selection results keyed by a slot's candidate
    configurations and per-language locale representatives (bounded by entry count, cleared when
    full), and each (package, stored type)'s printed indices for ``contending_packages`` (bounded
    by the indices the table defines). None of it holds a row or a position, so it cannot make a
    page disagree with the table.

    The page itself IS retained for the life of the call, so it is bounded too: ``rows_capped`` and
    ``values_omitted``/``out_of_pool_values`` are how it says so. Claiming otherwise is what let a
    299 KB APK produce 2.06 GB in one call — see the design doc.
    """

    entries: tuple[ResourceEntry, ...]
    total: int
    offset: int
    cookie: int
    source: str | None = field(default=None, metadata=PATH_FIELD)
    source_role: str | None = None
    packages: int = 0
    table_present: bool = False
    #: The walk stopped early — ``total`` is a floor, not a count.
    scan_capped: bool = False
    #: Config chunks abandoned whole (a size the offset array could not fit), and the entry counts
    #: they declared, so the gap is sized rather than reported as one entry.
    unwalked_chunks: int = 0
    unwalked_chunk_entries: int = 0
    #: Names dropped for the retained-byte budget, and names whose bytes are not valid text. Both
    #: leave ``entry_name`` None; only the first is the caller's to undo (ask for a smaller page).
    names_omitted: int = 0
    names_undecodable: int = 0
    #: String values dropped for the page's own byte budget. The row carries ``value_omitted``.
    values_omitted: int = 0
    #: String values the pool will not hand bytes over for — the row carries ``out_of_pool``. The
    #: same predicate as ``EntryScan``'s field of this name: both mean "no reader can fetch it",
    #: and both count an index inside an over-declared ``stringCount`` as well as one past the end.
    out_of_pool_values: int = 0
    #: ROWS whose pooled string does not decode — the row carries ``value_undecodable``. Counted
    #: per row like its two siblings ``values_omitted`` and ``out_of_pool_values``, not per pool
    #: slot: an aliased index would otherwise report 1 while several rows came back silently None.
    #: (The NAME counters are per SLOT — see ``NameCache`` — so the two accounts differ in unit.)
    values_undecodable: int = 0
    #: Whether the element has a usable value string pool. False means every string value in it is
    #: unreadable for that one reason, and every row says so with ``no_value_pool``.
    value_pool_present: bool = False
    #: Rows on THIS page whose definition no device is served (``ResourceEntry.unserved``).
    unserved_rows: int = 0
    #: Rows on THIS page the selection could not decide within its budget.
    selection_capped_rows: int = 0
    #: Rows on THIS page carrying ``contending_packages`` — the #17 ballast signal.
    contended_rows: int = 0
    #: The ``limit`` asked for exceeded the per-page row cap AND the reduction cost rows. It does
    #: not mean "this page is full" — that is ``offset + len(entries) < total``, and needs no flag.
    rows_capped: bool = False


class ResourceTable:
    """Resolver over an APK's resources.arsc (real AOSP AssetManager2).

    The AssetManager2 is set up like the device's: a stack of ApkAssets (base first, then
    any splits / overlays / framework-res passed in). A single base APK is the common case.
    """

    def __init__(
        self,
        apk_path: str,
        *,
        extra_apks: tuple[str, ...] = (),
        framework_path: str | None = None,
        load_framework: bool = True,
    ) -> None:
        """Load the base APK's resource table plus any splits/overlays/framework.

        A framework resource table (SDK ``android.jar``, which bundles the framework
        ``resources.arsc``) is loaded first so ``@android:`` (0x01......) refs resolve.
        ``framework_path`` pins one explicitly; otherwise it is auto-discovered from the SDK
        when ``load_framework`` is set. Framework loading is **best-effort**: an unloadable
        auto-discovered framework is dropped rather than sinking the whole table — the base
        APK still resolves (just without ``@android:``). A user-pinned ``framework_path`` that
        fails DOES raise (explicit).

        A base APK with **no** ``resources.arsc`` does NOT raise: ``ApkAssets::Load`` succeeds on
        it and yields an empty ``LoadedArsc``, so the object constructs and every lookup simply
        finds nothing. Use ``arsc_entry`` to tell that apart from a table that failed to
        load, and ``search_strings``' ``unread`` account to see it named per stack element.

        A load error names the failing element as "stack element N": N indexes the stack in its
        order — framework (if any), the base, then the splits that loaded — the same index
        ``cookie_role`` maps, never a path (a file name is the sample's and could forge the text).
        """
        # Splits are best-effort enhancements: probe each and drop (and record) any that will not
        # load ON ITS OWN, so a corrupt / foreign / arsc-less sibling does not sink the base's
        # table. That bounds per-member loadability only: members that load alone can still fail
        # TOGETHER (AOSP's stack-wide dynamic-id counter, see _load_failure), and that failure
        # names the split's element and is reported, not hidden. The base and a pinned framework
        # are required — their failure is surfaced, not swallowed.
        self.dropped: list[StackDrop] = []
        good_splits = []
        for index, split in enumerate(extra_apks):
            refused = _load_failure(split, index)
            if refused is None:
                good_splits.append(split)
            else:
                self.dropped.append(
                    StackDrop(
                        "split",
                        split,
                        refused.cause,
                        str(refused),
                        host_judgement(refused),
                    )
                )
        base = [apk_path] + good_splits
        pinned = framework_path is not None
        fw = framework_path or (discover_framework() if load_framework else None)
        # The APK under analysis IS the framework table (android.jar / framework-res.apk triaged
        # directly): mounting it a second time made every one of its ids collide with itself and
        # raised cross_element against "another APK" that is the same file (review). One copy.
        if fw is not None and _same_file(fw, apk_path):
            fw = None
        # Roles parallel to the stack order passed to the native resolver: the cookie a resolved
        # value reports (SelectedValue.cookie) indexes this same list, so cookie -> role is a
        # direct lookup. framework (if any) is loaded first, then the base, then the splits.
        split_roles = ["split"] * len(good_splits)
        roles = (["framework"] if fw else []) + ["base"] + split_roles
        try:
            self._sources = (([fw] if fw else []) + base)[:]
            self._resolver = _stack(self._sources)
            self.framework_path = fw
            self._roles = roles
        except TableLoadError as exc:
            # The constructor names the member it refused. Only an AUTO-DISCOVERED framework
            # that is itself the refused member is dropped (and recorded); the base's, a split's,
            # a pinned framework's or the whole stack's failure is the outcome — no retry that
            # would guess the culprit (batch audit).
            if fw is None or pinned or exc.element != 0:
                raise _failed(exc, roles, self.dropped) from None
            assert fw is not None
            self.dropped.append(
                StackDrop("framework", fw, exc.cause, str(exc), host_judgement(exc))
            )
            self._sources = base[:]
            self.framework_path = None
            self._roles = ["base"] + split_roles
            try:
                self._resolver = _stack(self._sources, "fallback")
            except TableLoadError as again:
                raise _failed(again, self._roles, self.dropped) from None

    def table_headers(self) -> list[dict[str, Any]]:
        """Each stack element's top-level tables: the packageCount declared, the package chunks.

        LoadedArsc::Load runs LoadTable for EACH RES_TABLE_TYPE chunk (:946-958); each reads its
        header's packageCount and refuses more package chunks than that, accepting fewer
        (:875-880). Read by AOSP's own ChunkIterator over the bytes the loader parsed. One row
        per element: ``{"cookie", "role", "tables": [{"declared_packages", "package_chunks"}]}``,
        or ``"unavailable"`` with why when the bytes could not be re-read.
        """
        out = []
        for cookie in range(len(self._sources)):
            report = self._resolver.ignored_pool_chunks(cookie)
            row: dict[str, Any] = {"cookie": cookie, "role": self.cookie_role(cookie)}
            if report.get("unavailable"):
                row["unavailable"] = report["unavailable"]
            row["tables"] = list(report.get("tables", []))
            out.append(row)
        return out

    def cookie_role(self, cookie: int) -> str | None:
        """Map a stack cookie to its role (``"base" | "split" | "framework"``), or None."""
        if 0 <= cookie < len(self._roles):
            return self._roles[cookie]
        return None

    def cookie_count(self) -> int:
        """Return how many stack elements are loaded; cookies run from 0 to one less."""
        return len(self._roles)

    def _to_resolution(
        self, d: dict[str, Any] | None, shared: dict[str, Any] | None = None
    ) -> Resolution | None:
        if not d:
            return None
        cookie = int(d.get("cookie", -1))
        shared = shared or {}
        return Resolution(
            id=d["id"],
            type=d["type"],
            value=d.get("value"),
            entry_name=d.get("entry_name"),
            type_name=d.get("type_name"),
            config=d.get("config", "default"),
            config_axes=int(d.get("config_axes", 0)),
            public=bool(d.get("public", False)),
            staged=bool(d.get("staged", False)),
            cookie=cookie,
            source=_source(d),
            source_role=self.cookie_role(cookie),
            was_reference=bool(d.get("was_reference", False)),
            original_type=d.get("original_type"),
            resolved_id=d.get("resolved_id"),
            resolved_name=d.get("resolved_name"),
            ref_hops=tuple(d.get("ref_hops", ())),
            ref_terminal=d.get("ref_terminal"),
            resolve_error=d.get("resolve_error"),
            contending_packages=int(shared.get("contending_packages") or 0),
            contention=shared.get("contention"),
        )

    def typed_reads(
        self,
        manifest_apk: str,
        sdk_major: int,
        sdk_minor: int,
        max_states: int | None = None,
    ) -> dict[int, dict[str, Any]]:
        """Each manifest element's TypedArray, by start-tag ordinal (``ArscResolver.typed_reads``).

        AOSP's RetrieveAttributes, run with this stack configured as the install parser's (SDK
        ``sdk_major``.``sdk_minor``, and again under each locale the stack offers) over the
        manifest the device opens from ``manifest_apk``, its tree carrying the base's
        DynamicRefTable — what obtainAttributes gives the package parser.
        """
        rows: dict[str, dict[str, Any]] = self._resolver.typed_reads(
            native_path(manifest_apk),
            self._base_cookie(),
            sdk_major,
            sdk_minor,
            *(() if max_states is None else (max_states,)),
        )
        meta = (
            "start_tags",
            "state_runs",
            "state_cost",
        )  # what the rows were read over
        out: dict[int, dict[str, Any]] = {
            int(k): v for k, v in rows.items() if k not in meta
        }
        out[-1] = {k: rows.get(k) for k in meta}
        return out

    def resolve(self, res_id: str | int) -> Resolution | None:
        """Resolve a resource id (``@0x7f..``/``0x7f..``/int) to its best-config SCALAR value.

        None if the id is absent or is a bag (complex/map entry) — use ``resolve_bag`` for those.
        When the stored value was itself a reference the chain is instrumented: ``was_reference``,
        ``original_type``, ``resolved_id``/``resolved_name`` (the tail, kept apart from the head
        ``id``/``entry_name``), ``ref_hops``/``ref_terminal``, and ``resolve_error``.
        """
        rid = _to_id(res_id)
        d = self._resolver.resolve(rid)
        return self._to_resolution(d, self._resolver.contention_for(rid) if d else None)

    def element_packages(self, cookie: int | None = None) -> list[dict[str, Any]]:
        """List the packages one stack element declares (default: the base APK).

        ``[{name, stored_id, runtime_id, dynamic}]`` — ``runtime_id`` is AOSP's assignment (-1 when
        it assigned none). A fact about that APK alone, whatever else is mounted.
        """
        idx = self._base_cookie() if cookie is None else cookie
        result: list[dict[str, Any]] = self._resolver.element_packages(idx)
        return result

    def package_collisions(self) -> list[dict[str, Any]]:
        """Report every runtime id held by more than one package (#17).

        The shape itself — whether or not any id is defined twice — with what is needed to label
        it: ``[{runtime_id, packages, dynamic_packages, same_element, cookies: {cookie: packages}}]``.
        Static packages in different stack elements are listed too (an app declaring another APK's
        id, or a split over its base); android.jar's seven packages at 0x01 are listed as well.
        Nothing is exempted — label by ``cookie_role``, do not filter by it.
        """
        result: list[dict[str, Any]] = self._resolver.package_collisions()
        return result

    def contention_summary(self, cookie: int | None = None) -> dict[str, Any]:
        """#17 for one stack element (default: the base APK).

        ``{by_kind: {kind: id_count}, samples: {kind: [{id, contending_packages, contention}]}}`` —
        every id one of the element's packages defines that more than one package defines, with up
        to five examples per kind. Kinds as in ``ResourceEntry.contention``. No device selection is
        run, and each (runtime id, type) is tallied once, so it costs the indices defined.
        """
        result: dict[str, Any] = self._resolver.contention_summary(
            self._base_cookie() if cookie is None else cookie
        )
        return result

    def _to_bag(self, d: dict[str, Any] | None) -> Bag | None:
        if not d:
            return None
        entries: list[BagEntry] = []
        for e in d.get("entries", []):
            cookie = int(e.get("cookie", -1))
            entries.append(
                BagEntry(
                    key=e["key"],
                    type=e["type"],
                    value=e.get("value"),
                    key_name=e.get("key_name"),
                    resolved=e.get("resolved"),
                    resolved_type=e.get("resolved_type"),
                    cookie=cookie,
                    source=_source(e),
                    source_role=self.cookie_role(cookie),
                )
            )
        return Bag(
            id=d["id"],
            entries=entries,
            entry_count=int(d.get("entry_count", len(entries))),
            truncated=bool(d.get("truncated")),
            entry_name=d.get("entry_name"),
            type_name=d.get("type_name"),
            config_axes=int(d.get("config_axes", 0)),
            public=bool(d.get("public", False)),
            staged=bool(d.get("staged", False)),
            parent_cycle=bool(d.get("parent_cycle", False)),
            refused=d.get("refused"),
        )

    def resolve_bag(self, res_id: str | int) -> Bag | None:
        """Resolve a complex (bag/map) id — style/theme, array, plurals, attr — via AOSP GetBag.

        The complement of ``resolve``: returns the flattened key-value list, or None if the id is
        absent or is a scalar. A common malware sink lives here — ``string-array`` C2/target lists
        and ``style`` UI-impersonation themes are invisible to the scalar ``resolve`` alone.

        Every ask is built on a FRESH AOSP manager, so the answer is a pure function of the id:
        the same whenever, and however often, it is asked. AOSP's ``GetBag`` keeps state that is
        never evicted and that changes answers — a parent-walk stack left dirty by a failure (a
        retry could return a wrongly complete bag) and a bag cache that a walk through a parent
        loop fills with a parent-less copy (#15) — so none of it is kept. A chain that loops is
        marked ``parent_cycle`` (see ``Bag``); use ``bag_parent_cycle`` to ask about the loop when
        this returns None.
        """
        return self._to_bag(self._resolver.resolve_bag(_to_id(res_id)))

    def is_bag(self, res_id: str | int) -> bool:
        """Whether AOSP ``GetBag`` builds this id as a bag (on a fresh manager, as every ask is).

        Note this is a question about *resolution*, not about the entry's shape: ``GetBag`` recurses
        into the parent and propagates the parent's failure (AssetManager2.cpp:1332-1338), so an
        ordinary style reports False whenever its parent chain cannot be walked — an ``@android:``
        parent with no framework table loaded, a parent delivered by an unmounted split, an
        unresolvable shared-library dynamic reference. Use ``entry_is_complex`` to ask what the
        table says about the entry itself; never use this to conclude "not a bag".
        """
        return self._resolver.resolve_bag(_to_id(res_id)) is not None

    def resource_id_for(
        self, name: str, *, default_type: str = "", default_package: str = ""
    ) -> str | None:
        """Look an id up by name exactly as the app's ``Resources.getIdentifier`` does.

        ``name`` is ``[@][package:]type/entry``; an omitted type or package takes ``default_type``
        / ``default_package`` — the ``defType`` / ``defPackage`` of the Java call. This IS AOSP's
        ``AssetManager2::GetResourceId``, so it answers with the CONSUMED view: the first entry AOSP
        finds under that name, in a package group whose first package carries that package name. A
        second entry stored under the same name, or a package hidden behind another at one id, is
        present (``list_entries`` shows it) but not found here — a difference worth reporting, not
        a bug. Returns the runtime id as ``0x7f......``, or None when AOSP finds nothing.
        """
        found = self._resolver.resource_id_for(name, default_type, default_package)
        return None if found is None else f"0x{found:08x}"

    def entry_is_complex(self, res_id: str | int) -> bool | None:
        """Is the entry AOSP selects for this id complex (a map/bag)? None if undeterminable.

        The counterpart of ``is_bag``: it asks what the entry IS, using AOSP's own discriminator
        (``GetResource`` refuses a complex entry when ``may_be_bag`` is false), instead of asking
        whether AOSP could build the flattened bag when first asked. So it does not turn a
        broken/absent
        parent chain — or a missing framework table on the analyst's machine — into "this is a
        scalar". Callers that must not false-positive should treat only an explicit ``False`` as
        "definitely a scalar".
        """
        result = self._resolver.entry_is_complex(_to_id(res_id))
        return None if result is None else bool(result)

    def bag_parent_cycle(self, res_id: str | int) -> bool | None:
        """Report whether this id's bag parent chain loops back; None if the walk was refused first.

        Structural, like ``entry_is_complex`` — read from the entries AOSP selects, never from
        ``GetBag`` — so it answers the same whatever was asked before (#15). True also for a bag
        that merely inherits from a cycle. False for a scalar or absent id as well — there is no
        chain to loop; ask ``entry_is_complex`` for what the id is. It is the question to ask when ``resolve_bag`` returns
        None: a ``Bag`` that was built carries the same fact as ``parent_cycle``.
        """
        result = self._resolver.bag_parent_cycle(_to_id(res_id))
        return None if result is None else bool(result)

    def declared(self, res_id: str | int) -> bool:
        """Report whether a loaded package reserves a slot for the id.

        Faithful to AOSP ``FindEntry``'s precondition (``TypeSpec`` present and entry index within
        ``entryCount`` — LoadedArsc.h:67): weaker than "has a value", so an id whose value lives
        only in a not-loaded config split, a ``public.xml`` id reserved without a value, and a bag
        entry are all *declared*. Only a forged id (no ``TypeSpec`` for the type, or an entry past
        ``entryCount``) or a wholly-stripped type reads as not-declared — the true dangling case.

        The id is the one the RUNTIME addresses, which for a shared library is not the one stored
        in the arsc: a ``--shared-lib`` package stores ``0x00`` and AOSP assigns it from a counter
        that starts at ``0x02`` and spans the whole mounted stack (#7). So a dynamic package's id
        is decided by **how many dynamic packages precede it in the stack**, not by its own file.
        The APK passed as ``apk_path`` is always the first dynamic package here (only the static
        framework can precede it), so its library is always ``0x02……``; one passed via
        ``extra_apks=`` lands at ``0x02`` plus the number of dynamic packages ahead of it, and so
        reads as ``0x02……`` probed alone and ``0x03……`` behind a dynamic base. That is the
        device's own behaviour; a dynamic package's resid is not a stable identifier. Ordinary
        packages are unaffected. ``resolve``, ``resolve_bag``, ``config_variants`` and the ``id``
        on a ``search`` hit's ``entries`` all speak this same id space.
        """
        return bool(self._resolver.declared(_to_id(res_id)))

    def declaring_roles(self, res_id: str | int) -> list[str]:
        """Roles of the stack APKs that declare the id, in stack order (deduped).

        ``["base", "split"]`` means both the base and a split reserve a slot for the id. Introspection
        for the opt-in multi-APK case — pairs with a resolution's ``source_role`` (which stack element
        the device actually selects) to let a caller reason about base-vs-split provenance.
        """
        roles: list[str] = []
        for c in self._resolver.declaring_cookies(_to_id(res_id)):
            role = self.cookie_role(int(c))
            if role is not None and role not in roles:
                roles.append(role)
        return roles

    def config_variants(self, res_id: str | int) -> list[ConfigVariant]:
        """Return one entry per configuration that defines the id (values may repeat).

        The default-config ``resolve`` sees only one variant; this reads what a device under
        each configuration would select (locale/density/sdk). One row per defining config, so
        two configs holding the same value both appear — use distinct values for divergence.
        Bag-typed resources (styles/arrays) are omitted (scalar-only for now).
        """
        return [
            ConfigVariant(config=v["config"], type=v["type"], value=v.get("value"))
            for v in self.config_variants_report(res_id)["variants"]
        ]

    def list_entries(
        self,
        *,
        cookie: int | None = None,
        package_id: int | None = None,
        type_id: int | None = None,
        type_name: str | None = None,
        offset: int = 0,
        limit: int = 200,
    ) -> EntryPage:
        """Enumerate what one stack element STORES — every type, config and entry index.

        The complement of ``search_strings``, which can only reach entries whose stored value is a
        string. This reaches all of them, so an integer flag, a colour, or a reference is visible
        for the first time (#4).

        ``cookie`` selects the stack element and defaults to the base APK; a split or the framework
        is enumerated by passing its cookie (see ``cookie_role``). Filters are AND-ed:
        ``package_id`` and ``type_id`` match the two bytes ``id`` is built from — the RUNTIME
        package id and the STORED type id — so a filter always agrees with the ids it returns.
        ``type_name`` matches the decoded name (``"string"``, ``"array"``, …); a type whose name
        could not be decoded matches nothing rather than everything.

        Order is deterministic for a given table — packages in load order, then type, then config
        chunk, then entry index — which is what makes ``offset`` mean anything. It is NOT a
        promise across tables or across versions of this library.
        """
        idx = self._base_cookie() if cookie is None else cookie
        d = self._resolver.list_entries(
            idx,
            -1 if package_id is None else package_id,
            -1 if type_id is None else type_id,
            "" if type_name is None else type_name,
            offset,
            limit,
        )
        rows = tuple(
            ResourceEntry(
                id=r["id"],
                type_name=r.get("type_name"),
                entry_name=r.get("entry_name"),
                config=r["config"],
                package_id=r["package_id"],
                value_type=r.get("value_type"),
                value=r.get("value"),
                is_bag=bool(r.get("is_bag")),
                value_omitted=bool(r.get("value_omitted")),
                out_of_pool=bool(r.get("out_of_pool")),
                no_value_pool=bool(r.get("no_value_pool")),
                unmapped_reference=bool(r.get("unmapped_reference")),
                value_undecodable=bool(r.get("value_undecodable")),
                null_empty=bool(r.get("null_empty")),
                served_on=r.get("served_on"),
                unserved=bool(r.get("unserved")),
                unserved_reason=r.get("unserved_reason"),
                app_served_on=r.get("app_served_on"),
                app_device=r.get("app_device"),
                app_unasked=bool(r.get("app_unasked")),
                zero_request_unasked=bool(r.get("zero_request_unasked")),
                selection_capped=bool(r.get("selection_capped")),
                pool_index=r.get("pool_index"),
                contending_packages=int(r.get("contending_packages") or 0),
                contention=r.get("contention"),
                unreadable=bool(r.get("unreadable")),
                unverified=bool(r.get("unverified")),
                dynamic_package=bool(r.get("dynamic_package")),
                name_omitted=bool(r.get("name_omitted")),
                enumerated_id=r.get("enumerated_id"),
                type_id_offset=r.get("type_id_offset"),
            )
            for r in d["rows"]
        )
        return EntryPage(
            entries=rows,
            total=d["total"],
            offset=d["offset"],
            cookie=idx,
            source=self._sources[idx] if 0 <= idx < len(self._sources) else None,
            source_role=self.cookie_role(idx),
            packages=d["packages"],
            table_present=d["table_present"],
            scan_capped=d["scan_capped"],
            unwalked_chunks=d["unwalked_chunks"],
            unwalked_chunk_entries=d["unwalked_chunk_entries"],
            names_omitted=d["names_omitted"],
            names_undecodable=d["names_undecodable"],
            values_omitted=d["values_omitted"],
            out_of_pool_values=d["out_of_pool_values"],
            values_undecodable=d["values_undecodable"],
            value_pool_present=d["value_pool_present"],
            unserved_rows=d["unserved_rows"],
            selection_capped_rows=d["selection_capped_rows"],
            contended_rows=d["contended_rows"],
            rows_capped=d["rows_capped"],
        )

    def _base_cookie(self) -> int:
        """Stack index of the APK this table was opened for (the framework may precede it)."""
        try:
            return self._roles.index("base")
        except ValueError:  # pragma: no cover - _roles always contains "base"
            return 0

    def pool_string(
        self, pool_index: int, cookie: int | None = None
    ) -> dict[str, Any] | None:
        """Return the whole string at ``pool_index`` of one element's value pool (base by default).

        ``{"text", "undecodable", "device_truncates_at"}``: bytes that are not valid text come back
        with replacement characters and ``undecodable`` set — shown, never hidden, as
        ``search_strings`` does; ``device_truncates_at`` is the BYTE offset of an embedded NUL,
        where the app's own copy stops (None when it has none). None when the slot is not handed
        over: past the pool's end, no pool, or a slot the pool will not give (``unread`` in a
        search).
        """
        idx = self._base_cookie() if cookie is None else cookie
        page = self._resolver.pool_values(idx, int(pool_index), 1)
        if int(pool_index) in page["unreadable"] or not page["values"]:
            return None
        return {
            "text": str(page["values"][0]),
            "undecodable": int(pool_index) in page["undecodable"],
            "device_truncates_at": page["device_truncates_at"].get(int(pool_index)),
        }

    def config_variants_report(self, res_id: str | int) -> dict[str, Any]:
        """Raw per-config result: ``{"variants": [...], "truncated": bool}``.

        ``truncated`` is True when the walk hit its safety bound (a hostile table with an
        absurd number of config chunks) — itself a signal, not a silent drop.
        """
        d: dict[str, Any] = self._resolver.resolve_config_variants(_to_id(res_id))
        return {
            "variants": d.get("variants", []),
            "truncated": bool(d.get("truncated")),
        }

    def pool_report(
        self, cookie: int, *, offset: int = 0, limit: int = _POOL_PAGE
    ) -> dict[str, Any]:
        """Read one page of a stack element's global value string pool.

        The primitive under ``search_strings``, which is what you want for a whole-table read.

        Keys: ``values``, ``total``, ``offset``, ``encoding``, ``pool_present``, ``table_present``,
        ``unreadable``, ``undecodable``, ``device_truncates_at``. Index lists are ABSOLUTE.

        Returns at most ``limit`` values starting at ``offset`` — this is a PAGE, not the pool.
        The default returns 4096 of the framework's 180,915, so a caller scanning ``values`` for a
        needle would miss 97% of it; page while ``offset + len(values) < total``.
        """
        d: dict[str, Any] = self._resolver.pool_values(cookie, offset, limit)
        return d

    def _ignored_chunk_gaps(
        self, cookie: int, source: str | None, role: str | None
    ) -> list[PoolGap]:
        """Chunk-level findings for one stack element.

        Pools the runtime loads past, plus the cases where the walk could not answer.
        Three outcomes, and they must stay distinct. An empty list means the walk completed and
        found no ignored pool chunk — it must never also mean "could not look", which is what an
        exception-swallowing or failure-to-empty design would produce.
        """
        report = self._resolver.ignored_pool_chunks(cookie)
        gaps: list[PoolGap] = []

        if not report["inspected"]:
            # AssetManager2 has the table loaded and is searching it; only the second, raw read
            # failed. Silence here would upgrade "could not look" into a clean bill of health.
            return [
                PoolGap(
                    cookie=cookie,
                    reason=f"chunk-level inspection unavailable: {report['unavailable']}",
                    kind="not_inspected",
                    values=0,
                    source=source,
                    source_role=role,
                )
            ]

        for chunk in report["chunks"]:
            claimed = chunk["declared_string_count"]
            gaps.append(
                PoolGap(
                    cookie=cookie,
                    reason=_IGNORED_CHUNK_REASON.get(
                        chunk["level"], "a pool chunk the runtime never loads"
                    ),
                    kind="ignored_chunk",
                    # What the chunk CLAIMS. None when its header is too short to even hold the
                    # field — unknown, which is not zero, so values_unknown carries that rather
                    # than letting `or 0` flatten the two into one number.
                    values=int(claimed) if claimed is not None else 0,
                    values_unknown=claimed is None,
                    chunk_bytes=int(chunk["bytes"]),
                    source=source,
                    source_role=role,
                )
            )

        if report["chunks_truncated"]:
            gaps.append(
                PoolGap(
                    cookie=cookie,
                    reason=(
                        f"{report['total_ignored']} ignored pool chunks in total; "
                        f"only the first {len(report['chunks'])} are listed"
                    ),
                    # NOT "ignored_chunk": that kind is defined as one gap per chunk, carrying that
                    # chunk's measured size. This is a summary of the ones not listed, so counting
                    # it as a chunk would inflate `ignored_chunks` by one and contribute a
                    # sizeless entry to `bytes_in_ignored_chunks`.
                    kind="chunks_capped",
                    values=0,
                    values_unknown=True,
                    source=source,
                    source_role=role,
                )
            )
        if report["depth_capped"]:
            gaps.append(
                PoolGap(
                    cookie=cookie,
                    reason=(
                        "chunk nesting exceeded the walk's depth bound; deeper chunks not examined"
                    ),
                    kind="not_inspected",
                    values=0,
                    source=source,
                    source_role=role,
                )
            )
        if report["walk_error"]:
            # A NON-fatal ChunkIterator stop leaves the table loading and resolving normally while
            # our walk ended early (ChunkIterator.cpp:44-64). Reporting the chunks found so far
            # without this would assert the walk reached the end of the table.
            gaps.append(
                PoolGap(
                    cookie=cookie,
                    reason=f"chunk walk stopped early: {report['walk_error']}",
                    kind="not_inspected",
                    values=0,
                    source=source,
                    source_role=role,
                )
            )
        return gaps

    def _attribute(
        self,
        cookie: int,
        source: str | None,
        role: str | None,
        hits: list[StringHit],
        slots: list[int],
    ) -> EntryScan:
        """Attach the scalar entries that store each of this element's hits, and account for it.

        Rewrites ``hits`` in place at ``slots`` — the positions this stack element contributed —
        so attribution is joined only against the table that owns those pool indices.

        Always returns the account, including for a table with no packages at all: the walk DID
        run and established that there was nothing to walk, which is the very fact that explains
        the empty ``entries`` (and a strings-only table with no packages is itself worth seeing).
        Returning None there spelled "no packages" exactly like ``attribute=False``.

        A walk that dropped ANYTHING marks EVERY one of this element's hits, including the ones it
        found nothing for. That is the whole point: each drop path can lose the one entry that
        stores a string, leaving an empty ``entries`` and a zero ``entries_total`` — identical to a
        genuinely unowned string — while the only signal sits on the element-wide account, a
        different object a per-hit renderer never carries. An attacker picks which entries fall
        down which path, so every one of them is a targeted suppression channel, and the cheap ones
        are the dangerous ones: ``unverified_values`` costs a two-byte ``size`` field and
        ``unwalked_chunks`` a four-byte ``entryCount``, against the ~4 MB of padding the scan
        budget needs. Wiring up only ``scan_capped`` — the expensive one — left the other three
        exactly as they were.

        On ordinary input none of these fire (0 across the 204-APK corpus), so this does not buy
        the signal with noise.
        """
        want = sorted({hits[i].pool_index for i in slots})
        report: dict[str, Any] = self._resolver.entries_for_pool_indices(cookie, want)
        found = report["entries"]
        dropped = (
            bool(report["scan_capped"])
            or bool(report["unreadable_entries"])
            or bool(report["unverified_values"])
            or bool(report["unwalked_chunks"])
        )
        for i in slots:
            rec = found.get(hits[i].pool_index)
            if not rec:
                if dropped:
                    # No owner found AND the walk lost entries: say so on the hit itself.
                    hits[i] = replace(hits[i], entries_truncated=True)
                continue
            rows = rec["rows"]
            hits[i] = replace(
                hits[i],
                entries=tuple(
                    EntryRef(
                        id=r["id"],
                        type_name=r.get("type_name"),
                        entry_name=r.get("entry_name"),
                        config=r["config"],
                        package_id=r["package_id"],
                        dynamic_package=bool(r.get("dynamic_package")),
                        name_omitted=bool(r.get("name_omitted")),
                        enumerated_id=r.get("enumerated_id"),
                        type_id_offset=r.get("type_id_offset"),
                    )
                    for r in rows
                ),
                # Exact past the retention caps, so "N resources hold this" never silently
                # becomes "N we kept" — but only a FLOOR past the scan budget, which stops
                # counting as well as listing.
                entries_total=int(rec["total"]),
                entries_truncated=int(rec["total"]) > len(rows) or dropped,
            )
        return EntryScan(
            cookie=cookie,
            source=source,
            source_role=role,
            table_present=bool(report["table_present"]),
            packages=int(report["packages"]),
            scanned_entries=int(report["scanned_entries"]),
            string_entries=int(report["string_entries"]),
            complex_entries=int(report["complex_entries"]),
            unreadable_entries=int(report["unreadable_entries"]),
            unverified_values=int(report["unverified_values"]),
            out_of_pool_values=int(report["out_of_pool_values"]),
            unwalked_chunks=int(report["unwalked_chunks"]),
            unwalked_chunk_entries=int(report["unwalked_chunk_entries"]),
            names_omitted=int(report["names_omitted"]),
            names_undecodable=int(report["names_undecodable"]),
            scan_capped=bool(report["scan_capped"]),
            store_capped=bool(report["store_capped"]),
        )

    def search_strings(
        self,
        needle: str,
        *,
        ignore_case: bool = True,
        include_framework: bool = False,
        limit: int = 500,
        attribute: bool = True,
    ) -> StringSearch:
        """Substring-search the value string pool of each stack element.

        This is the whole-table counterpart of ``resolve``: the pool is flat, so a value reaches it
        regardless of whether any *entry* pointing at it can still be reached — which is what every
        known way of hiding a resource string breaks (see docs/resource-query-design.md). It is
        therefore the completeness floor for "what strings does this app's table hold", and the way
        to find C2 URLs and impersonation copy that nothing in the manifest references.

        The framework's pool is ~181k strings of stock Android text and is skipped by default;
        it is still listed in ``unread`` so a caller can see the omission rather than infer it.

        With ``attribute`` (the default) each hit also carries the scalar ``entries`` that store
        it — the resource id, name and configuration an analyst needs to act on a URL — and the
        walk behind that is accounted for in ``scans``. It is enrichment only: an unattributed hit
        is reported exactly as it would be without it. Pass ``attribute=False`` to skip the entry
        walk when only the presence of a string matters.

        Returns a ``StringSearch`` — hits plus an explicit account of what was and was not read.
        """
        target = needle.casefold() if ignore_case else needle
        hits: list[StringHit] = []
        read: list[PoolRead] = []
        unread: list[PoolGap] = []
        scans: list[EntryScan] = []
        truncated = False

        for cookie, role in enumerate(self._roles):
            source = self._sources[cookie] if cookie < len(self._sources) else None
            # Positions in `hits` contributed by THIS stack element. Attribution is per cookie
            # because a Res_value's string index addresses its own table's pool, so index 182 in
            # the base and in a split name unrelated strings.
            hit_slots: list[int] = []
            if role == "framework" and not include_framework:
                total = int(self._resolver.pool_values(cookie, 0, 0)["total"])
                unread.append(
                    PoolGap(
                        cookie=cookie,
                        reason="framework pool not searched (pass include_framework=True)",
                        values=total,
                        kind="out_of_scope",
                        source=source,
                        source_role=role,
                    )
                )
                continue

            offset, seen, encoding = 0, 0, None
            refused, mangled = _IndexTally(), _IndexTally()
            while True:
                page = self._resolver.pool_values(cookie, offset, _POOL_PAGE)
                values = page["values"]
                encoding = page["encoding"]
                if not page["pool_present"]:
                    # "No table" and "table present, no value pool" are different facts, and the
                    # second is the dangerous one: the table resolves ids normally while an entire
                    # pool of unknown size goes unread, so a gap sized 0 would understate it to
                    # nothing. Never say "no resource table" about a table we can resolve from.
                    unread.append(
                        PoolGap(
                            cookie=cookie,
                            reason=(
                                "table present but it has no value string pool — pool size unknown"
                                if page["table_present"]
                                else "stack element has no resource table"
                            ),
                            values=0,
                            source=source,
                            source_role=role,
                        )
                    )
                    break
                refused.extend(page["unreadable"])
                page_refused = set(page["unreadable"])
                # Undecodable indices go into the account UNCONDITIONALLY, not just when they hit.
                # The searched text differs from the stored bytes there, and a needle can lie
                # entirely inside the substituted run (see decode_lossy in module.cpp) — so the one
                # value whose corruption hides the needle is exactly the one that produces no hit
                # to attach the flag to. Recording it only on a hit is a guarantee of silence in
                # the case that matters.
                mangled.extend(page["undecodable"])
                lossy = set(page["undecodable"])
                truncates = page["device_truncates_at"]
                for i, value in enumerate(values, start=offset):
                    if i in page_refused:
                        continue  # an empty placeholder, not a value we searched
                    hay = value.casefold() if ignore_case else value
                    if target not in hay:
                        continue
                    if len(hits) >= limit:
                        truncated = True
                        continue
                    at = truncates.get(i)
                    hit_slots.append(len(hits))
                    hits.append(
                        StringHit(
                            value=value,
                            pool_index=i,
                            cookie=cookie,
                            source_role=role,
                            source=source,
                            device_truncated=at is not None,
                            device_truncates_at=at,
                            undecodable=i in lossy,
                            match_at=_match_at(value, target, ignore_case),
                        )
                    )
                seen += len(values)
                offset += len(values)
                if offset >= int(page["total"]) or not values:
                    break

            # Chunk-level inspection runs whether or not a value pool loaded. A table with NO
            # usable pool is the more suspicious shape, not the less, so skipping the walk there
            # would leave exactly the anomalous element unexamined.
            unread.extend(self._ignored_chunk_gaps(cookie, source, role))

            if not page["pool_present"]:
                continue
            # A refused slot yields no bytes at all, so it was *not* searched — subtract it from
            # the read count instead of letting an empty placeholder pass for a value we covered.
            read.append(
                PoolRead(
                    cookie=cookie,
                    source=source,
                    source_role=role,
                    values=seen - refused.count,
                    encoding=encoding,
                )
            )
            if refused.count:
                unread.append(
                    PoolGap(
                        cookie=cookie,
                        reason="pool refused these indices (inflated stringCount)",
                        values=refused.count,
                        indices=refused.indices,
                        indices_truncated=refused.truncated,
                        source=source,
                        source_role=role,
                    )
                )
            if mangled.count:
                unread.append(
                    PoolGap(
                        cookie=cookie,
                        reason="value bytes were not decodable; searched with U+FFFD substituted",
                        kind="mangled",
                        values=mangled.count,
                        indices=mangled.indices,
                        indices_truncated=mangled.truncated,
                        source=source,
                        source_role=role,
                    )
                )
            if attribute and hit_slots:
                scans.append(self._attribute(cookie, source, role, hits, hit_slots))

        return StringSearch(
            pattern=needle,
            hits=tuple(hits),
            read=tuple(read),
            unread=tuple(unread),
            hits_truncated=truncated,
            scans=tuple(scans),
        )
