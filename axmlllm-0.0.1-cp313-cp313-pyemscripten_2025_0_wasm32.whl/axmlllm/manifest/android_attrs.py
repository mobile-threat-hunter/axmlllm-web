"""Curated android attribute ResID → canonical name map (frozen platform constants).

The framework keys on the **ResID**, not the string name (verified: ``RetrieveAttributes``
matches on ``getAttributeNameResID``). So the domain model must resolve attributes by ResID
too — otherwise a ResID-spoofed attribute (string-name ``"label"`` carrying ResID
``android:name``) is invisible to us, the exact attack axmlllm exists to defeat.

This is a **focused** subset of the manifest-critical attributes, extracted verbatim from
AOSP ``frameworks/base/core/res/res/values/public-final.xml`` (anchor
android16-qpr2-release). These IDs are public-API frozen. The FULL platform
``R.styleable.AndroidManifest*`` tables (needed for the ``not_consumed`` overlay across every
element) are a later milestone; this map covers the attributes that drive triage today.
"""

from __future__ import annotations

# ResID (lowercase hex string) → canonical android attr name. AOSP: public-final.xml.
ANDROID_ATTR_BY_RESID: dict[str, str] = {
    "0x01010000": "theme",
    "0x01010001": "label",
    "0x01010002": "icon",
    "0x01010003": "name",
    "0x01010006": "permission",
    "0x01010007": "readPermission",
    "0x01010008": "writePermission",
    "0x01010009": "protectionLevel",
    "0x0101000b": "sharedUserId",
    "0x0101000d": "persistent",
    "0x0101000e": "enabled",
    "0x0101000f": "debuggable",
    "0x01010010": "exported",
    "0x01010011": "process",
    "0x01010018": "authorities",
    "0x0101001b": "grantUriPermissions",
    "0x01010024": "value",
    "0x0101020c": "minSdkVersion",
    "0x0101021b": "versionCode",
    "0x0101021c": "versionName",
    "0x01010270": "targetSdkVersion",
    "0x010102b7": "installLocation",
    "0x010104ec": "usesCleartextTraffic",
    "0x01010505": "directBootAware",
    "0x01010527": "networkSecurityConfig",
    "0x01010599": "foregroundServiceType",
    "0x01010603": "requestLegacyExternalStorage",
}


def canonical_name(resid: str | None, string_name: str) -> str:
    """Return the framework's canonical attr name for an attribute.

    ResID wins (the framework keys on it); falls back to the string-pool name when the ResID
    is absent or not in the curated map. ``resid`` is normalised to lowercase first.
    """
    if resid is not None:
        mapped = ANDROID_ATTR_BY_RESID.get(resid.lower())
        if mapped is not None:
            return mapped
    return string_name
