"""The attributes each manifest tag is read through, as the device's parser reads them.

The framework reads a manifest tag through ``res.obtainAttributes(parser,
R.styleable.AndroidManifest<Tag>)`` — only the attribute ResIDs that styleable declares, in its
array order. Extracted from AOSP by ``scripts/gen_styleables.py`` into
``data/manifest_styleables.json``.
"""

from __future__ import annotations

import json
from pathlib import Path

_PATH = Path(__file__).parent / "data" / "manifest_styleables.json"
_RAW: dict[str, dict[str, str]] = json.loads(_PATH.read_text())

# tag -> the styleable's attribute ResIDs in the native parser's 0x%08x form
CONSUMED: dict[str, set[str]] = {
    tag: {f"0x{int(r, 16):08x}" for r in attrs.values()} for tag, attrs in _RAW.items()
}

# android attribute name -> its public ResID (public-final.xml), for the readers in dispatch.py:
# the device reads these by ResID, so the replay must too
ATTR: dict[str, int] = {
    name: int(r, 16) for attrs in _RAW.values() for name, r in attrs.items()
}
