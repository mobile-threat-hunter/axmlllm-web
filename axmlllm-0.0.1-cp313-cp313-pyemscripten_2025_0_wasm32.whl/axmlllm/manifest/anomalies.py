"""Dual-parser / present-vs-consumed anomaly detection over the parsed manifest.

The threat-hunting payoff: what is *present* in the AXML is not what the device *consumes*
(AOSP reads lazily + selectively, keyed on ResID — see the project's ``aosp-load-model``
notes). This module surfaces the gap as structured signals.

Implemented here are the detectors computable from the v1 tree alone (no platform tables).
Detectors that need the platform ``R.styleable.AndroidManifest*`` ResID sets or arsc
resolution are declared with anchored TODOs and land in later milestones.
"""

from __future__ import annotations

import functools
import json
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Callable, Iterator

from .._axml_core import ZIP_ENTRY_NOT_FOUND
from .._host import memory_limits
from . import reads as R
from .android_attrs import ANDROID_ATTR_BY_RESID
from .dispatch import _SPEC as _DISPATCH_SPEC
from .dispatch import Dispatched, Replay, _witness
from .model import Attribute, Element, Manifest
from .resources import Resolution, ResourceTable
from .styleables import CONSUMED

# a removed-sibling run this long is reported high: next() recurses once per removal, and the
# depth a device's binder thread survives is not probed (said, not judged)
_DEEP_RECURSION = 1000

# Res_value.dataType — AOSP: ResourceTypes.h:323.
_TYPE_DYNAMIC_REFERENCE = 0x07

# Per-tag set of android attribute ResIDs the framework actually CONSUMES (styleables.py). An
# android attribute (0x0101xxxx) present on a tag but absent from this set is never read by the
# device — present-vs-consumed evasion. See the project's aosp-load-model notes.
_CONSUMED_RESIDS = CONSUMED

# Android framework attributes live in package 0x01, attr type 0x01 → 0x0101xxxx.
_ANDROID_ATTR_PREFIX = "0x0101"

# Substring of the canonical android namespace URI. The native binding maps the EXACT URI to
# "android"; a near-miss (trailing space, extra path, look-alike host) comes back as the raw
# URI. A string tool that matches the android namespace by substring is fooled by such a
# mimic while the device keys on ResID — surface it.
_ANDROID_NS_MARKER = "schemas.android.com/apk/res/android"

# not_consumed is only worth flagging for ACCESS-CONTROL attributes: if one of these is
# present on a tag whose styleable ignores it, a string-based tool reads a guard/exposure
# that the device never applies (security misrepresentation). Cosmetic ignored attrs
# (screenOrientation on <application>, persistent on <service>, ...) are common benign dev
# errors — device-ignored but not a threat signal, so excluded to keep precision high.
_ACCESS_CONTROL_ATTRS = frozenset(
    {
        "exported",
        "permission",
        "readPermission",
        "writePermission",
        "protectionLevel",
        "grantUriPermissions",
        "authorities",
    }
)

# Package id of the APK's OWN resources — aapt assigns 0x7f to the app package. A manifest
# reference into this package MUST be satisfied by the base resources.arsc, so an id here that
# no entry defines is a dangling ref. Framework (0x01) refs need the SDK framework table loaded,
# and a 0x00 ref is a shared library's BUILD-TIME form — the runtime rewrites it through the
# DynamicRefTable before any lookup, and since #7 this table answers only at the rewritten id, so
# probing at 0x00 would read as dangling for a resource that resolves. Both are out of scope for
# this check — that avoids false dangling reports for @android refs when no framework is loaded.
_APP_PACKAGE_ID = 0x7F

# ref_chain_deep threshold: the number of reference hops above which a chain stops looking like
# ordinary resource aliasing. Grounded in measurement, not taste — sweeping every scalar entry of
# the SDK framework table (10,661 entries) and of 40 corpus APKs (62,481 entries) found chains of
# at most 3 hops (one single framework entry; every app topped out at 2), and none of the 1,096
# manifest @refs across the 204-APK corpus was indirected at all. 6 leaves a 2x margin over the
# deepest real chain ever observed while still firing well below AOSP's own 20-hop cliff, so an
# attacker cannot sit just under the runtime cap and stay invisible.
_DEEP_CHAIN_HOPS = 6

# Reverse map: canonical android attr name → its (normalized) ResID. Used to catch the
# inverse spoof — a string-name claiming a known android attr while the ResID is junk/absent.
_RESID_BY_NAME: dict[str, str] = {
    name: resid for resid, name in ANDROID_ATTR_BY_RESID.items()
}


# The three severities, most severe first, each a fixed meaning (docs/tree-schema.md "Anomaly
# entry"): high — a plain read of the bytes, as other tools do it, shows something the device does
# not do; medium — a construction that makes analysis harder, while a plain read is not misled;
# info — a fact about this analysis (the host, a detector, a skipped check), not about the APK.
SEVERITIES = ("high", "medium", "info")


@dataclass(frozen=True)
class Anomaly:
    """One finding: a way the APK's bytes and the device's view diverge, or a fact about this run."""

    kind: str
    severity: str
    path: str
    detail: str
    attr: str | None = None

    def __post_init__(self) -> None:
        """Refuse a severity outside the three defined (SEVERITIES)."""
        if self.severity not in SEVERITIES:
            raise ValueError(f"severity {self.severity!r} is not one of {SEVERITIES}")


def _walk(element: Element, prefix: str) -> Iterator[tuple[Element, str]]:
    """Yield ``(element, path)`` depth-first, with ``tag[index]`` disambiguation."""
    yield element, prefix
    counts: dict[str, int] = {}
    for child in element.children:
        idx = counts.get(child.tag, 0)
        counts[child.tag] = idx + 1
        yield from _walk(child, f"{prefix}/{child.tag}[{idx}]")


def detect(manifest: Manifest) -> list[Anomaly]:
    """Run all currently-implemented detectors and return the findings."""
    doc = manifest.root.tag if manifest.root else ""
    # Each pass that touches the table (native resource I/O on attacker-controlled bytes) is
    # isolated: one that raises cannot suppress the others or the byte-level detectors, and it
    # is REPORTED (detector_failed) — a silent [] read the same as "nothing found".
    out = _isolated("archive", functools.partial(_detect_archive, manifest), doc)
    out.extend(_detect_manifest_entry(manifest, doc))
    if manifest.root is None:
        return out
    capped: list[tuple[str, int]] = []
    paths: dict[int, str] = {}
    for element, path in _walk(manifest.root, manifest.root.tag):
        paths[id(element)] = path
        out.extend(_detect_on_element(element, path))
        if element.dropped_descendants:
            capped.append((path, element.dropped_descendants))
    # depth_capped: elements nested past the model's depth cap. The device's package parser reads
    # them when every handler above leaves its subtree (a chain of <uses-feature>, verified
    # dispatch), and the app can read its own manifest at any depth
    # (AssetManager.openXmlResourceParser), so it is a place to keep data no tool shows — and no
    # real manifest is nested hundreds of levels deep (review). ONE finding per manifest: one per
    # capped element let a fan-out at the cap bury every other finding (review).
    if capped:
        shown = ", ".join(p for p, _ in capped[:3])
        out.append(
            Anomaly(
                kind="depth_capped",
                severity="high",
                path=capped[0][0],
                detail=f"{sum(n for _, n in capped)} elements are nested past the depth this tool "
                f"parses, below {len(capped)} element(s) (first: {shown}) — present in the "
                "manifest and readable by the app, shown by no tool",
            )
        )
    roots = manifest.roots
    if len(roots) > 1:
        # the parsers read the first top-level element XmlBlock keeps: a flagged decoy <manifest>
        # can make the device read another one than every tree view here shows
        out.append(
            Anomaly(
                kind="multiple_roots",
                severity="high",
                path=doc,
                detail=f"{len(roots)} top-level elements (lines "
                f"{', '.join(str(r.line) for r in roots[:4])}): the device's parsers read the first "
                "one XmlBlock keeps, which a flag on an earlier one decides; the tree tools show the "
                "first only, the permission and component lists every one",
            )
        )
    out.extend(_detect_dispatch(manifest, paths))
    out.extend(_detect_attribute_reads(manifest, paths))
    # The arsc-aware pass performs native resource I/O; isolate it so a hostile-but-loadable
    # table (one that makes a native lookup raise) can never suppress the byte-level detectors
    # above — an attacker must not be able to hide a name_resid_mismatch behind a bad arsc.
    for name, run in (
        ("resource_refs", _detect_resource_refs),
        ("shared_resource_ids", _detect_shared_resource_ids),
        ("package_counts", _detect_package_counts),
    ):
        out.extend(_isolated(name, functools.partial(run, manifest), doc))
    return out


def _isolated(
    name: str, run: Callable[[list[Anomaly]], None], path: str
) -> list[Anomaly]:
    """Run one detector pass; if it raises, keep what it found and add ONE ``detector_failed``.

    The pass appends into the list it is given, so findings made before the failure are kept
    (returning a list lost them all). MemoryError is not caught: the process's state is then
    unknown, and the tool boundary answers ``memory_exhausted`` for the whole call. Anything else
    means the rest of this pass's findings are missing, which must not read as "found nothing".
    """
    found: list[Anomaly] = []
    try:
        run(found)
    except MemoryError:
        raise
    # any failure of a pass is reported, never dropped
    except Exception as exc:  # noqa: BLE001
        found.append(
            Anomaly(
                kind="detector_failed",
                severity="info",
                path=path,
                attr=name,
                detail=f"the {name} pass raised {_exc_text(exc)} — the findings it had not yet "
                "reached are missing, and their absence says nothing about the APK",
            )
        )
    return found


_EXC_CHARS = 300


def _exc_text(exc: BaseException) -> str:
    """``Type: message``, the message cut at _EXC_CHARS with its length said (it may be native)."""
    try:
        msg = str(exc)
    except Exception:  # noqa: BLE001 - an exception whose own __str__ raises
        msg = "<message unreadable>"
    if len(msg) > _EXC_CHARS:
        msg = f"{msg[:_EXC_CHARS]}…(cut: {len(msg)} chars)"
    return f"{type(exc).__name__}: {msg}"


def _detect_manifest_entry(manifest: Manifest, doc: str) -> list[Anomaly]:
    """How the manifest's zip entry is built, where that stops other readers but not the device.

    Both kinds are medium: the read here is the device's, and another reader is stopped, not
    misled. Neither occurs in the 204 corpus APKs (every manifest entry there is deflated and
    exactly its XML chunk).

    * ``manifest_trailing_data`` — bytes past the XML chunk. The device hands its XML parser the
      whole entry and the parser reads the chunk's header.size bytes of it (ResXMLTree::setTo);
      the rest is inflated (or mapped) and held, never read. Padding of this kind stops an
      analyzer that caps the entry's size; the device installed one with 70 MiB of it (device
      golden manifest_padding), holding the declared length twice — a larger one installs or
      not by the device's memory. Whether another reader parses bytes there as XML (a tail of
      more than one value) is not judged. NOT detected: padding INSIDE the chunk (a header.size
      that covers chunks the parser skips) — its size shows as ``xml_size`` only.
    * ``manifest_entry_method`` — a compression method neither stored nor deflated: the device's
      asset provider maps every entry it does not inflate, as stored (AssetsProvider.cpp:216-217);
      method 99 installs (device golden manifest_method_unknown, v2-signed), while Python's
      zipfile refuses it. A reader that DEcompresses the method (bzip2, 12) reads other bytes than
      the device.
    """
    entry = manifest.manifest_entry
    if entry is None:
        return []
    out = []
    if entry["method"] not in (0, 8):
        out.append(
            Anomaly(
                kind="manifest_entry_method",
                severity="medium",
                path=doc,
                detail=f"the AndroidManifest.xml entry's compression method is {entry['method']}, "
                "neither stored (0) nor deflated (8): the device reads its bytes as they are "
                "stored, without decompressing them — Python's zipfile, for one, refuses an "
                "unsupported method, and a reader that decompresses this method reads other bytes "
                "than the device",
            )
        )
    if entry["trailing"]:
        fill = entry["trailing_fill"]
        held = f"all 0x{fill:02x}" if fill is not None else "not one repeated value"
        read = "inflated" if entry["method"] == 8 else "mapped"
        out.append(
            Anomaly(
                kind="manifest_trailing_data",
                severity="medium",
                path=doc,
                detail=f"the AndroidManifest.xml entry is {entry['length']} bytes but its XML "
                f"chunk declares {entry['xml_size']}: the last {entry['trailing']} bytes "
                f"({held}) are never read by the device's XML parser, though it is handed the "
                f"whole entry ({read}) — an analyzer whose size cap is below the entry's length "
                "stops here",
            )
        )
    return out


def _detect_archive(manifest: Manifest, out: list[Anomaly]) -> None:
    """Report the table's load status and AOSP's own archive lookup behind it."""
    doc = manifest.root.tag if manifest.root else ""
    load = manifest.table_load
    # The device's own inflate of the entry, replayed with nothing of its declared size allocated:
    # a fact about the APK, the same under every memory cap under which the entry can be mapped.
    inflate = load.inflate
    if inflate is not None and inflate["stage"] != "inflate":
        out.append(
            Anomaly(
                kind="arsc_inflate_unasked",
                severity="info",
                path=doc,
                detail=f"the replay of the device's read of resources.arsc could not run on this "
                f"host (stage {inflate['stage']} {inflate['code']}: {inflate['message']}"
                f"{', ' + inflate['errno'] if 'errno' in inflate else ''}) — whether the "
                "device reads it was not asked",
            )
        )
    elif inflate is not None and inflate["code"] != 0:
        out.append(
            Anomaly(
                kind="arsc_inflate_rejected",
                severity="high",
                path=doc,
                detail="the device's inflate of resources.arsc fails too (the replay's "
                f"zip_archive::Inflate {inflate['code']}: {inflate['message']}; the device's "
                "own code may differ, as it inflates into a buffer): the archive declares "
                f"{inflate['declared']} bytes uncompressed, {inflate['stored']} stored, and the "
                f"stream does not yield exactly that (the replay accepted {inflate['written']} "
                "bytes before Inflate stopped — fewer, or a window that would overrun) — the "
                "device loads no table from it, while tools that inflate leniently decode one",
            )
        )
    # The load's outcome is reported only when the status is load_failed: a file that did not
    # reopen (arsc_unopenable) or a lookup that found no entry is not a table AOSP refused
    # (review: a vanished file read as a high load_rejected).
    failure = load.failure if manifest.resources_status == "load_failed" else None
    # Whether THIS host ended the load is the host's own answer (host_judgement: a refusal the host
    # returned to AOSP inside Load, witnessed natively), never a model of what it could map.
    if failure is not None and failure.not_judged is not None:
        # A host event, not a fact about the APK. The APK-level verdict on the declared size is
        # arsc_inflate_rejected above, computed without the allocation.
        out.append(
            Anomaly(
                kind="arsc_load_failed",
                severity="info",
                path=doc,
                attr=failure.cause,
                detail=f"resources.arsc was not judged on this host: {failure.not_judged} "
                f"(the archive declares {_declared(manifest)} bytes uncompressed, "
                f"{_stored(manifest)} stored){_host_memory_facts()} — a host that grants what this one "
                "refused judges it; a device may grant it or refuse it — the table's findings are "
                "missing; the manifest's are not",
            )
        )
    elif failure is not None:
        rejected = (
            inflate is not None and inflate["stage"] == "inflate" and inflate["code"]
        )
        see = " (see arsc_inflate_rejected)" if rejected else ""
        out.append(
            Anomaly(
                kind="arsc_load_failed",
                severity="high",
                path=doc,
                attr=failure.cause,
                detail=f"resources.arsc is listed but AOSP's loader produced no table from the "
                f"{failure.role} ({failure.cause}: {failure.message}){see} — tools that "
                "reconstruct resources from it see a table the device does not load",
            )
        )
    for drop in load.dropped:
        out.append(
            Anomaly(
                kind="stack_member_dropped",
                severity="info",
                path=doc,
                attr=drop.role,
                detail=f"the {drop.role} was left out of the resource stack: "
                + (
                    f"it was not judged on this host — {drop.not_judged}"
                    if drop.not_judged is not None
                    else "AOSP's loader refused it"
                )
                + f" ({drop.cause}: {drop.message}) — its resources are not resolved here",
            )
        )
    # The archive facts behind the status, from AOSP's own lookup (``Manifest.arsc_entry``).
    entry = manifest.arsc_entry
    if (
        entry is not None
        and entry["stage"] == "find"
        and entry["code"] not in (0, ZIP_ENTRY_NOT_FOUND)
    ):
        # Listed in the central directory, refused by the loader's own FindEntry: the device
        # loads an EMPTY table in its place (ApkAssets.cpp:153), while a zip tool that ignores the
        # refusal decodes the listed one — a table only analysis tools ever see.
        out.append(
            Anomaly(
                kind="arsc_entry_refused",
                severity="high",
                path=manifest.root.tag if manifest.root else "",
                detail=f"the APK lists resources.arsc but AOSP's archive reader refuses it "
                f"(FindEntry {entry['code']}: {entry['message']}) — the device loads an empty "
                "table instead, so a table decoded by other zip tools is one the device never uses",
            )
        )
    if entry is not None and entry["stage"] == "open":
        out.append(
            Anomaly(
                kind="arsc_unopenable",
                severity="info",
                path=manifest.root.tag if manifest.root else "",
                detail=f"the APK did not reopen for the resources.arsc lookup (OpenArchive "
                f"{entry['code']}: {entry['message']}) — the file changed or vanished after it was "
                "parsed, or the process ran out of descriptors; the lookup has no answer about "
                "the APK's resources.arsc",
            )
        )


def _declared(manifest: Manifest) -> object:
    entry = manifest.arsc_entry
    return "?" if entry is None else entry.get("uncompressed_length", "?")


def _stored(manifest: Manifest) -> object:
    entry = manifest.arsc_entry
    return "?" if entry is None else entry.get("compressed_length", "?")


def _host_memory_facts() -> str:
    """Name this host's memory limits that make an allocation fail (facts, not a judgement)."""
    # imported with the module: an import here, under descriptor exhaustion, failed the detector
    limits = memory_limits()
    facts = []
    if "inherited_memory_limit" in limits:
        facts.append(
            f"inherited memory limit {limits['inherited_memory_limit']} bytes "
            "(RLIMIT_AS / RLIMIT_DATA)"
        )
    if limits.get("strict_overcommit"):
        facts.append("strict overcommit (vm.overcommit_memory = 2)")
    return f" ({'; '.join(facts)})" if facts else ""


def _reserve_size(declared: int) -> str:
    """Say what AOSP's reserve of ``declared`` pointers asks for, on 64- and 32-bit devices."""
    sixty_four = f"{declared * 8} bytes on a 64-bit device"
    # a 32-bit vector<unique_ptr> holds at most max_size() = 0x3FFFFFFF elements: past it the
    # reserve throws length_error instead of allocating
    thirty_two = (
        "past the 32-bit vector's max_size: a length_error there"
        if declared > 0x3FFFFFFF
        else f"{declared * 4} on 32-bit"
    )
    return f"{sixty_four}, {thirty_two}"


def _detect_package_counts(manifest: Manifest, out: list[Anomaly]) -> None:
    """Report a table header declaring more packages than the table carries.

    ResTable_header.packageCount is a u32 AOSP reads before any package (LoadedArsc.cpp:822-827)
    and reserves room for — a pointer each — while refusing only MORE package chunks than declared
    (:875-880). Over-declared, it changes nothing the table holds and makes the load ask for up to
    32 GiB: refused on a host or device short of it, allocated on one with room. This build reads
    the table as AOSP does wherever that reserve succeeds (the reserve is capacity only, removed at
    build time — see CMakeLists.txt), so the analysis no longer depends on the host's memory; the
    declared count is reported here. aapt and aapt2 write the number of packages they write
    (TableFlattener.cpp:642, ResourceTable.cpp:3298); 71 of 204 corpus APKs over-declare it, with
    every byte of the count in 0x01..0x06. When the table's bytes could not be re-read the finding
    says it was not asked.
    """
    table = manifest.resources
    if table is None:
        return
    doc = manifest.root.tag if manifest.root else ""
    for row in table.table_headers():
        if row["role"] == "framework":
            continue  # the stock framework the analysis mounts, not this APK's bytes
        if row.get("unavailable"):
            out.append(
                Anomaly(
                    kind="package_count_unasked",
                    severity="info",
                    path=doc,
                    attr=row["role"],
                    detail=f"the {row['role']}'s table header was not read here "
                    f"({row['unavailable']}): whether it over-declares its packages was not asked",
                )
            )
            continue
        for i, t in enumerate(row["tables"]):
            declared, present = t["declared_packages"], t["package_chunks"]
            if declared <= present:
                continue
            out.append(
                Anomaly(
                    kind="package_count_overdeclared",
                    severity="medium",
                    path=doc,
                    attr=row["role"],
                    detail=f"the {row['role']}'s resources.arsc table #{i} declares {declared} "
                    f"packages and carries {present}: AOSP reserves a pointer for every declared "
                    f"one before reading any (LoadedArsc.cpp:827) — {_reserve_size(declared)}; "
                    "the table's contents are the same either way. aapt and aapt2 write the "
                    "number of packages they write",
                )
            )


def _detect_shared_resource_ids(manifest: Manifest, out: list[Anomaly]) -> None:
    """Report #17's sharing: ``shared_resource_id``, ``shared_package_id``, ``framework_package_id``.

    Only where this APK is one of the holders — see Scope below.

    AOSP's shared-library id counter starts at 0x02 and does not skip an id a static package holds
    (AssetManager2.cpp:174, :211), so 126 ballast packages put the 126th on the app's own 0x7f; it
    joins the app's group (:226-228) and every id it defines names two entries, while the app runs
    and every value resolves normally. Every kind is a finding, and the kind is the label:

    * ``dynamic_package`` (high) — a counter-assigned package is among the holders: the ballast;
    * ``same_element`` (medium) — two packages of this one APK: one arsc says it twice;
    * ``cross_element`` (high) — this APK's package joins an id another stack element holds. In a
      ``Manifest`` (which mounts no split) that is an app claiming another APK's id: declaring the
      framework's 0x01 replaced ``android:id/background`` on every ``en`` device. An earlier version
      exempted this kind as "a split over its base" and the audit built exactly that hijack: no
      finding at all. Detect the fact; let the label carry the interpretation.

    Measured 0 of every kind on the 204-APK corpus, with and without the framework. Scope: groups
    THIS APK takes part in — the framework's own seven packages at 0x01 are not the app's act, and
    analysing android.jar itself as the APK reports them, truthfully. A package is counted whether
    or not AOSP consults it at that type: counting only consulted packages let a typeIdOffset hide
    a ballast whose rows still print under the app's ids.
    """
    table = manifest.resources
    if table is None:
        return
    path = manifest.root.tag if manifest.root else ""
    # The raw fact, read from this APK alone: a static package storing 0x01, the id AOSP gives the
    # framework. As a COLLISION it is visible only when a framework table is mounted — with no
    # android.jar on the analyst's machine the same APK produced exactly the pristine findings,
    # while on every device (where the framework is always loaded) its definitions join the
    # framework's group (review). So the declaration itself is raised, whatever else is mounted.
    # One finding per APK, however many such packages: a finding per package let 20,000 of them
    # (104 KB deflated) make detect() return 20,015 anomalies, 4.8 MB through the tool, with the
    # shared_* findings last (review). The count is exact; the names are samples.
    claims = [
        p
        for p in table.element_packages()
        if p["stored_id"] == 0x01 and not p["dynamic"]
    ]
    if claims:
        names = sorted({str(p["name"]) for p in claims})
        out.append(
            Anomaly(
                kind="framework_package_id",
                severity="high",
                path=path,
                detail=f"this APK declares {len(claims)} package(s) with id 0x01 — the "
                "framework's — so on a device their entries join android's own and can override "
                "them, e.g. " + ", ".join(repr(n) for n in names[:5]),
                attr=names[0],
            )
        )
    # THE SHAPE, independent of any shared id: a ballast whose types are disjoint from the app's
    # defines no id twice, yet the device serves its entries under the app's runtime id.
    for c in table.package_collisions():
        cookies: dict[int, int] = c.get("cookies", {})
        mine = [k for k in cookies if table.cookie_role(k) != "framework"]
        if not mine:
            continue  # only the framework's own packages: not this APK's act
        # Every kind that holds is its own finding — a single ranked pick let a crowd inside the
        # APK hide a foreign holder: a second 0x01 package turned the framework hijack from
        # cross_element (high) into same_element (medium), device behaviour unchanged (review).
        crowded = [k for k in mine if cookies[k] > 1]
        kinds: list[tuple[str, str, str]] = []
        if c["dynamic_packages"] > 0:
            n = c["dynamic_packages"]
            kinds.append(("high", "dynamic_package", f"{n} of them shared libraries assigned it by AOSP's counter"))  # fmt: skip
        if crowded:
            n = max(cookies[k] for k in crowded)
            kinds.append(("medium", "same_element", f"{n} of them in one APK"))
        if len(cookies) > 1:
            kinds.append(("high", "cross_element", "this APK's package joins an id another APK holds"))  # fmt: skip
        for severity, attr, why in kinds:
            out.append(
                Anomaly(
                    kind="shared_package_id",
                    severity=severity,
                    path=path,
                    detail=f"runtime package id 0x{c['runtime_id']:02x} is held by "
                    f"{c['packages']} packages, {why} — their entries resolve under that id "
                    "beside the owner's",
                    attr=attr,
                )
            )
    summary = table.contention_summary()
    by_kind: dict[str, int] = summary.get("by_kind", {})
    for kind, severity, why in (
        (
            "dynamic_package",
            "high",
            "a shared-library package assigned the same runtime id",
        ),
        ("same_element", "medium", "a second package of this APK defining the same id"),
        ("cross_element", "high", "a package of another APK defining the same id"),
    ):
        n = int(by_kind.get(kind, 0))
        if n == 0:
            continue
        ids = [e["id"] for e in summary.get("samples", {}).get(kind, [])][:5]
        out.append(
            Anomaly(
                kind="shared_resource_id",
                severity=severity,
                path=path,
                detail=f"{n} resource id(s) name more than one entry — {why} ({kind}); the "
                "device resolves one while static tools may show the other. e.g. "
                + ", ".join(ids),
                attr=kind,
            )
        )


def _ref_id(value: object) -> int | None:
    """Numeric resource id of a reference attribute value (``@0x7f..``/``0x7f..``/int)."""
    if isinstance(value, int):
        return value
    if isinstance(value, str):
        try:
            return int(value.lstrip("@?"), 16)
        except ValueError:
            return None
    return None


def _detect_resource_refs(manifest: Manifest, out: list[Anomaly]) -> None:
    """Join the AXML tree with the loaded resource table and judge every manifest ``@ref``.

    Two families of finding come out of the same walk (one resolve per reference):

    * ``dangling_resource_ref`` — the id names no entry at all. The arsc was stripped/replaced
      after build, the id was hand-edited to break analysis tooling, or the resource is expected
      from a split/RRO that is not present (see #7).
    * ``ref_cycle`` / ``ref_chain_deep`` — the id resolves, but only through a reference chain
      whose shape is itself the signal (see ``_chain_anomalies``).

    Runs on whatever table AOSP loaded — the EMPTY one included, which the device loads when the
    APK has no ``resources.arsc`` or lists one AOSP refuses: a manifest referencing app resources
    the device will not find is reported, whatever the archive looks like to other tools. (Gating
    on the status let one zip byte, or a ``Resources.arsc`` decoy, switch these detectors off.)
    With NO table (no APK, or a load failure — reported once as ``arsc_load_failed``) nothing is
    judged, and one ``resource_refs_unchecked`` says how many references went unchecked and why.
    Dangling uses
    ``declared`` (TypeSpec reservation), not ``resolve``: a present-but-bag resource (#6), a value
    delivered only by a config split, and a ``public.xml``-reserved id are all *declared* and so
    are NOT flagged — only a forged or wholly-stripped id reads as dangling, keeping false
    positives out.

    Both checks are scoped to the app package (0x7f). For dangling that avoids reporting
    ``@android:`` refs when no framework is loaded; for the chain checks it keeps the verdict
    reproducible — framework chains are not attacker-controlled and would otherwise vary with
    whichever SDK ``android.jar`` the analyst happens to have. A chain that *starts* in the app
    package is still traced all the way through, including hops that cross into the framework.
    """
    if manifest.root is None:
        return
    table = manifest.resources
    if table is None:
        out.extend(_unchecked_refs(manifest))
        return
    # The APK's own entry, when the device loads none of it: named in every dangling detail, so a
    # finding on an empty table says WHY the table is empty (AOSP's own code), not just that it is.
    entry = manifest.arsc_entry
    no_own_table = (
        f" (the device loads no table from this APK: resources.arsc lookup {entry['stage']} "
        f"{entry['code']}: {entry['message']})"
        if entry is not None and manifest.loads_no_own_table
        else ""
    )
    # (id, exception type) of each per-id check (declared / chain) that raised
    id_failed: list[tuple[int, str]] = []
    # One resolve per DISTINCT id, not per attribute. A manifest may repeat the same @ref thousands
    # of times (``<meta-data>`` fan-out), and the chain verdict depends only on the id — without
    # this, a crafted manifest turns detection into O(refs x chain work) and takes minutes.
    chain_verdict: dict[int, list[Anomaly]] = {}
    for path, a, rid in _app_refs(manifest.root):
        try:
            declared = table.declared(rid)
        except MemoryError:
            raise
        except Exception as exc:  # noqa: BLE001 - reported per id (detector_failed)
            id_failed.append((rid, type(exc).__name__))
            continue
        if not declared:
            out.append(
                Anomaly(
                    kind="dangling_resource_ref",
                    severity="high",
                    path=path,
                    attr=a.key,
                    detail=f"{a.key} references {a.value} (0x{rid:08x}) which the app's "
                    "resources.arsc does not declare (no TypeSpec slot reserved) — the "
                    "table was stripped/replaced after build or the id was hand-forged"
                    + no_own_table,
                )
            )
            continue  # nothing declared, so there is no chain to walk
        # Per-id guard: the checks decode attacker-controlled pool bytes, and one id that
        # raises would otherwise end the pass and leave every LATER id unjudged (_isolated keeps
        # what was found before, but cannot judge what comes after).
        if rid not in chain_verdict:
            try:
                chain_verdict[rid] = _chain_findings(table, rid)
            except MemoryError:
                raise
            # reported per id (detector_failed)
            except Exception as exc:  # noqa: BLE001
                chain_verdict[rid] = []
                id_failed.append((rid, type(exc).__name__))
        # The cached findings describe the ID; bind them to the attribute that referenced it.
        for template in chain_verdict[rid]:
            out.append(
                replace(
                    template,
                    path=path,
                    attr=a.key,
                    detail=f"{a.key} {template.detail}",
                )
            )
    if id_failed:
        distinct = list(
            dict.fromkeys(id_failed)
        )  # an id repeated across attributes once
        shown = ", ".join(f"0x{rid:08x} ({why})" for rid, why in distinct[:3])
        out.append(
            Anomaly(
                kind="detector_failed",
                severity="info",
                path=manifest.root.tag,
                attr="resource_ref",
                detail=f"the per-id reference check raised {len(id_failed)} time(s) (first: "
                f"{shown}) — those ids' dangling / ref_cycle / ref_chain_deep verdicts are "
                "missing, and their absence says nothing about the APK",
            )
        )


def _app_refs(root: Element) -> Iterator[tuple[str, Attribute, int]]:
    """Every attribute that references an id in the app package: (path, attribute, id).

    The one predicate both reference detectors use (a second copy of it drifted untested).
    """
    for element, path in _walk(root, root.tag):
        for a in element.attributes:
            rid = _ref_id(a.value) if a.type == "reference" else None
            if rid is not None and (rid >> 24) & 0xFF == _APP_PACKAGE_ID:
                yield path, a, rid


def _unchecked_refs(manifest: Manifest) -> list[Anomaly]:
    """Say how many app references went unjudged when no table loaded to judge them.

    No table means a manifest parsed from raw AXML (no APK) or a table that failed to load.
    Without this finding the reference detectors returned nothing, which reads the same as
    "every reference checks out".
    """
    if manifest.root is None:
        return []
    refs = 0
    first = ""
    for path, a, _rid in _app_refs(manifest.root):
        refs += 1
        first = first or f"{path}@{a.key}"
    if not refs:
        return []
    why = (
        "no APK: the manifest was parsed from raw AXML"
        if manifest.arsc_entry is None
        else f"no resource table loaded (resources_status {manifest.resources_status})"
    )
    return [
        Anomaly(
            kind="resource_refs_unchecked",
            severity="info",
            path=manifest.root.tag,
            detail=f"{refs} app resource reference(s) were not checked (first: {first}) — {why}",
        )
    ]


def _chain_findings(table: ResourceTable, rid: int) -> list[Anomaly]:
    """Chain-shape findings for one id, with placeholder ``path``/``attr`` filled in by the caller."""
    resolution = table.resolve(rid)
    if resolution is None or not resolution.was_reference:
        return []  # absent, a bag, or a value stored directly — no chain
    return _chain_anomalies(table, resolution)


def _chain_anomalies(table: ResourceTable, resolution: Resolution) -> list[Anomaly]:
    """Judge one resolved reference chain's *shape* (``ref_cycle`` / ``ref_chain_deep``).

    The chain the device walks is instrumented in ``Resolution`` (#3); depth and dead ends are
    obfuscation indicators in their own right, and a chain the runtime refuses to finish is a
    dual-parser gap — a tool that chases references itself reports a value the device never sees.
    Findings carry a placeholder ``path``/``attr``; the caller fills in the referencing attribute.

    Two gates keep this at zero false positives, and both were added because the obvious version
    was wrong:

    * ``ref_terminal == "self"`` cannot be trusted on its own — AOSP represents a *bag* as a
      self-pointing reference so the chase stops on it (AssetManager2.cpp:1141-1143), making a
      plain ``@style``/``@array`` reference indistinguishable from a true self-reference at the
      value level. The discriminator must be ``entry_is_complex`` (a structural read of the entry),
      NOT ``is_bag`` (whether ``GetBag`` succeeded when first asked): ``GetBag`` propagates a
      parent's
      failure, so an ordinary style reports "not a bag" when its ``@android:`` parent is missing —
      which would make this fire or not fire on the same APK depending on whether the analyst has
      an SDK installed. Only an explicit ``False`` fires; ``None`` (undeterminable) does not.
    * the depth check excludes ``unresolved`` and nothing else. A chain ending in a resource this
      table cannot see is the non-reproducible case excluded at the bottom of this module (an
      unmounted split, a stripped framework), and claiming it "resolves" would contradict the
      ``resolve_error`` on the same record. Every other terminal is fully determined by the loaded
      table, so it counts — in particular ``self``, which is what a chain ending at a BAG reports:
      gating on ``terminal == "value"`` instead let an attacker hide a 6-to-20 hop chain simply by
      pointing its last alias at an ``@array``/``@style`` rather than an ``@string``.
    """
    out: list[Anomaly] = []
    hops = resolution.ref_hop_count
    terminal = resolution.ref_terminal
    tail = resolution.resolved_name or resolution.resolved_id or "?"

    # The two ways a chain can loop are mechanically different and must not share one sentence:
    # a self-reference stops AOSP immediately (1 hop, no repeat), while a longer cycle spins out
    # the full hop budget. Saying "revisits an id it already passed after 1 hop" for the former is
    # contradicted by the ref_hops on the very same record.
    self_ref = (
        terminal == "self"
        and resolution.resolved_id is not None
        and table.entry_is_complex(resolution.resolved_id) is False
    )
    if terminal == "cycle" or self_ref:
        loop = (
            f"references a resource that points at itself ({tail}), so the device stops there"
            if self_ref
            else f"references a resource whose chain revisits {tail}, an id it already passed, "
            f"so the device exhausts its {hops}-hop budget"
        )
        out.append(
            Anomaly(
                kind="ref_cycle",
                severity="high",
                path="",
                attr=None,
                detail=f"{loop} and never reaches a value — any tool that reports one for this "
                "attribute is showing something the device does not",
            )
        )
    elif terminal == "max_hops":
        out.append(
            Anomaly(
                kind="ref_chain_deep",
                severity="high",
                path="",
                attr=None,
                detail="references a chain longer than AOSP's 20-hop ResolveReference bound — the "
                f"device gives up at {tail} and keeps an unresolved reference, so a tool that "
                "chases the chain to its end reports a value the device never uses",
            )
        )
    elif terminal != "unresolved" and hops >= _DEEP_CHAIN_HOPS:
        out.append(
            Anomaly(
                kind="ref_chain_deep",
                severity="medium",
                path="",
                attr=None,
                # Terminal-aware: `value` reaches a scalar, `null` resolves to @null, and `self`
                # lands on a bag — only the first has "a value", so the wording must not claim one.
                detail=f"is indirected through {hops} reference hops before it ends at {tail} "
                f"(terminal: {terminal}) — real tables alias at most 3 deep, so a chain this long "
                "is built to make what it points at hard to follow",
            )
        )
    return out


def _detect_on_element(element: Element, path: str) -> list[Anomaly]:
    out: list[Anomaly] = []
    consumed = _CONSUMED_RESIDS.get(element.tag)
    for a in element.attributes:
        # not_consumed: an access-control android attribute present on a tag whose styleable
        # does not declare it → the device never reads it (obtainAttributes keys on the tag's
        # ResID set), so a string-based tool sees a guard/exposure the device never applies.
        # Only judged for tags we have a consumed-set for.
        resid_l = a.resid.lower() if a.resid else None
        canon = ANDROID_ATTR_BY_RESID.get(resid_l) if resid_l else None
        if (
            consumed is not None
            and resid_l is not None
            and resid_l.startswith(_ANDROID_ATTR_PREFIX)
            and resid_l not in consumed
            and canon in _ACCESS_CONTROL_ATTRS
        ):
            out.append(
                Anomaly(
                    kind="not_consumed",
                    severity="high",
                    path=path,
                    attr=canon,
                    detail=f"access-control attribute android:{canon} ({a.resid}) is on "
                    f"<{element.tag}> but not in its styleable — the device never reads it, "
                    f"so any guard/exposure it implies is not actually applied",
                )
            )
        # name-by-ResID-only: the framework keys on ResID, so an attribute with a ResID
        # but no (or empty) string name is invisible to string-based manifest tools.
        if a.resid is not None and not a.name:
            out.append(
                Anomaly(
                    kind="name_by_resid_only",
                    severity="high",
                    path=path,
                    attr=a.resid,
                    detail=f"attribute has ResID {a.resid} but an empty string-name "
                    "— string-based tools see nothing; the device processes it by ResID",
                )
            )
        # dynamic_reference masking: getAttributeDataType masks 0x07→0x01 before Java sees
        # it; we read the raw type via getAttributeValue, so the original 0x07 is visible.
        if a.type_code == _TYPE_DYNAMIC_REFERENCE:
            out.append(
                Anomaly(
                    kind="dynamic_reference_masked",
                    severity="medium",
                    path=path,
                    attr=a.name or a.resid,
                    detail=f"value is TYPE_DYNAMIC_REFERENCE (0x07) {a.value} — masked to "
                    "TYPE_REFERENCE before static inspectors observe it",
                )
            )
        # name_resid_mismatch: the ResID resolves to a known android attribute but the
        # string-name disagrees. Legit builds (aapt) always store the canonical name, so any
        # divergence is tampering — tools believe the string, the device acts on the ResID.
        # Fires for both impersonation ("label"→name) and random decoys ("zz"→name).
        # AOSP: RetrieveAttributes keys on getAttributeNameResID. (resid_l/canon computed above.)
        if a.name and canon is not None and a.name != canon:
            out.append(
                Anomaly(
                    kind="name_resid_mismatch",
                    severity="high",
                    path=path,
                    attr=a.name,
                    detail=f"string-name '{a.name}' but ResID {a.resid} is android:{canon} "
                    f"— string-based tools read it as '{a.name}'; the device treats it as "
                    f"'{canon}'",
                )
            )
        # Inverse spoof: the attribute is in the android namespace and its string-name is a
        # known android attr, but its ResID is NOT that attr's ResID (junk/absent/non-android).
        # The framework keys on ResID so it does NOT treat it as android:<name>; string tools
        # do. `canon is None` keeps this disjoint from the case above (resid is a known attr).
        if (
            a.ns == "android"
            and canon is None
            and a.name in _RESID_BY_NAME
            and resid_l != _RESID_BY_NAME[a.name]
        ):
            out.append(
                Anomaly(
                    kind="name_resid_mismatch",
                    severity="high",
                    path=path,
                    attr=a.name,
                    detail=f"android:{a.name} carries ResID {a.resid or '(none)'}, not the "
                    f"real android:{a.name} ({_RESID_BY_NAME[a.name]}) — string tools honor "
                    f"the name; the device ignores the attribute",
                )
            )
        # lookalike_android_ns: the attribute's namespace mimics the android URI but is not
        # the exact one (so the binding did not normalize it to "android"). String tools that
        # match by substring treat it as android; the device does not.
        if a.ns is not None and a.ns != "android" and _ANDROID_NS_MARKER in a.ns:
            out.append(
                Anomaly(
                    kind="lookalike_android_ns",
                    severity="high",
                    path=path,
                    attr=a.name or a.resid,
                    detail=f"attribute namespace {a.ns!r} mimics the android namespace but is "
                    "not the exact URI — string tools may treat it as android; the device "
                    "does not",
                )
            )
    out.extend(_java_string_divergence(element, path))
    return out


def _java_string_divergence(element: Element, path: str) -> list[Anomaly]:
    """java_string_divergence: a stored string the device's Java parser reads differently.

    The parser gets every pooled string through StringBlock.getSequence -> nativeGetString
    (docs/java-string-design.md): a UTF-8 pool's string8At through ART's NewStringUTF, a UTF-16
    pool's units with their length. Where that differs from the stored string — a crafted pool —
    a tool reading the stored string reports another name than the device acts on.
    """
    out: list[Anomaly] = []

    def found(
        what: str, attr: str | None, stored: object, java: object, styled: bool
    ) -> None:
        if java is None:
            told = "a read that throws (nativeGetString: IndexOutOfBounds), so the parse fails"
        else:
            told = f"{java!r}"
        if styled:
            told += " — a styled string, whose style application is not replayed"
        out.append(
            Anomaly(
                kind="java_string_divergence",
                severity="high",
                path=path,
                attr=attr,
                detail=f"{what} is stored as {stored!r}; the device's Java parser reads {told}",
            )
        )

    if (
        element.tag_unreadable
        or element.tag != element.stored_tag
        or element.tag_styled
    ):
        found(
            "the tag name",
            None,
            element.stored_tag,
            None if element.tag_unreadable else element.tag,
            element.tag_styled,
        )
    for a in element.attributes:
        if a.raw_java_present and (a.raw_java != a.raw_string or a.raw_styled):
            found(
                "its raw string",
                a.name or a.resid,
                a.raw_string,
                a.raw_java,
                a.raw_styled,
            )
        if a.typed_java_present and (a.typed_java != a.typed_string or a.typed_styled):
            found(
                "its typed string",
                a.name or a.resid,
                a.typed_string,
                a.typed_java,
                a.typed_styled,
            )
    return out


_STYLEABLE_ATTRS: dict[str, dict[int, str]] = {
    styleable: {int(r, 16): name for name, r in attrs.items()}
    for styleable, attrs in json.loads(
        (Path(__file__).parent / "data" / "manifest_styleable_attrs.json").read_text()
    ).items()
}


def _styleable_text(a: Attribute) -> str:
    """Return what a styleable read takes from ``a``, for display: a string's TYPED pool string."""
    if a.type_code != 0x03:  # TYPE_STRING
        return repr(a.value)
    if a.typed_string is not None:
        return repr(a.typed_string)
    if a.typed_out_of_pool:
        return f"a typed string index {a.raw} past the string pool"
    return f"a typed string at pool entry {a.raw} this host does not decode"


def _typed_key(a: Attribute) -> object:
    """Return what a styleable read sees of an occurrence: the typed value, never the raw string."""
    return (a.type_code, a.raw)


def _nullish(a: Attribute) -> bool:
    """Say whether an occurrence gives no value either way (TYPE_NULL, or @null)."""
    return a.type_code == 0x00 or (a.type_code == 0x01 and a.raw == 0)


_ANDROID_URI = "http://schemas.android.com/apk/res/android"
_ANDROID = "android"


def _model_ns(ns: str | None) -> str | None:
    """Map a reader's namespace URI to the model's (the exact android URI is "android")."""
    return "android" if ns == _ANDROID_URI else ns


def _lite_reads(e: Element, r: Replay) -> list[tuple[str | None, str, str]]:
    """Return the (ns, name) pairs ApkLite reads by name on ``e`` (matched on its XML ancestry)."""
    chain = []
    x: Element | None = e
    while x is not None:
        chain.append(x.tag)
        x = r.parent(x)
    path = list(reversed(chain))
    out = []
    for row in _DISPATCH_SPEC.get("lite_by_name", []):
        if row.get("condition"):
            continue  # read only under a condition the lite parse checks first: not judged
        p = row["path"]
        # any depth only BELOW the parent the lite parse itself reaches by depth
        # (<uses-static-library> directly under <application>, ApkLiteParseUtils.java:529-536)
        hit = path == p or (
            row["any_depth"]
            and len(path) > len(p)
            and path[-1] == p[-1]
            and path[: len(p) - 1] == p[:-1]
        )
        if hit:
            out.append((_model_ns(row["ns"]), row["name"], row["accessor"]))

    return out


def _unjudged(e: Element, styleable: str | None) -> str:
    """Say why a repeat on ``e`` is not judged against a device reader here."""
    if styleable is None:
        return f"<{e.tag}> is not dispatched to a styleable reader"
    if not e.styleable_reads:
        return "the native reader did not run on this element"
    return f"{styleable}, which <{e.tag}> is read through, does not hold it"


def _detect_attribute_reads(manifest: Manifest, paths: dict[int, str]) -> list[Anomaly]:
    """Attributes the device's readers take differently from a tree reader, or from each other.

    The full parser reads a dispatched element through its handler's styleable — AOSP's
    RetrieveAttributes, a merge walk over ResIDs (run natively: ``Element.styleable_reads``) —
    plus a few attributes by name (the spec's ``reads.by_name``); the lite parse (ApkLite, every
    install) reads its own list by name (``lite_by_name``). A by-name read takes the first
    attribute whose namespace and name strings match; the walk takes the first occurrence of a
    ResID it reaches, and passes one placed after a higher ResID.

    attribute_unread (high): an attribute the styleable holds that the walk passes — the full
    parser applies no value where a tree reader shows one (device-verified: an
    android:enabled="false" so placed leaves the activity enabled); when ApkLite reads the same
    attribute by name it still takes a value (device-verified: minSdkVersion 99 refused the
    install), and the finding says so — the device's own readers disagree.
    duplicate_attribute: a ResID or a by-name attribute repeated — high when the readers'
    occurrences hold different values, medium when equal; a repeat no device reader is replayed
    for here is a medium fact, with why it is not judged.
    """
    out: list[Anomaly] = []
    root = manifest.root
    if root is None:
        return out
    r = manifest.dispatch
    handlers = _DISPATCH_SPEC["handlers"]
    for e in root.iter():
        path = paths.get(id(e), e.tag)
        d = r.of(e)
        styleable = None
        by_name: list[tuple[str | None, str, str]] = []
        if d is not None and d.outcome == "read" and d.handler is not None:
            styleable = handlers[d.handler]["reads"].get("styleable")
            by_name = [
                (_model_ns(ns), name, accessor)
                for ns, name, accessor in handlers[d.handler]["reads"]["by_name"]
            ]
        if d is not None and d.owner is not None:
            # the reads a feature-flag loop makes on every start tag it reaches (featureFlag)
            if _DISPATCH_SPEC["owners"][d.owner].get("feature_flag"):
                by_name += [
                    (_model_ns(g["ns"]), g["name"], g["accessor"])
                    for g in _DISPATCH_SPEC.get("global_by_name", [])
                ]
        lite = _lite_reads(e, r)
        read_attrs = _STYLEABLE_ATTRS.get(styleable or "", {})
        named = {name for _, name, _ in by_name + lite}
        lite_names = {(ns, name): accessor for ns, name, accessor in lite}
        groups: dict[str, list[tuple[int, Attribute]]] = {}
        for i, a in enumerate(e.attributes):
            if a.resid is not None:
                groups.setdefault(a.resid, []).append((i, a))
        unread: list[str] = []
        repeats: list[tuple[str, str]] = []  # (severity, text)
        for resid, occ in groups.items():
            name = read_attrs.get(int(resid, 16))
            if name is not None and e.styleable_reads:
                taken = e.styleable_reads.get(resid)
                if taken is None:
                    if not all(_nullish(a) for _, a in occ):
                        shown = occ[-1][1].value
                        text = f"android:{name} ({shown!r}, line {e.line})"
                        accessor = lite_names.get((_ANDROID, name))
                        if accessor is not None:
                            found = R.by_name(e, _ANDROID, name)
                            text += (
                                " — ApkLite still reads it by name: "
                                f"{_accessor_value(found, accessor)!r}"
                                if found is not None
                                else " — ApkLite, reading it by name, finds no attribute "
                                f"named {name!r} either"
                            )
                        unread.append(text)
                    continue
                if len(occ) > 1:
                    differ = len({_typed_key(a) for _, a in occ}) > 1
                    repeats.append(
                        (
                            "high" if differ else "medium",
                            f"android:{name} {len(occ)}× — the styleable read takes "
                            f"#{taken} ({_styleable_text(e.attributes[taken])})"
                            + (
                                f", a reader keeping the last occurrence #{occ[-1][0]} "
                                f"({_styleable_text(occ[-1][1])})"
                                if differ
                                else ", all the same typed value"
                            ),
                        )
                    )
            elif len(occ) > 1 and not any(a.name in named for _, a in occ):
                repeats.append(
                    (
                        "medium",
                        f"ResID {resid} {len(occ)}× — not judged here: {_unjudged(e, styleable)}",
                    )
                )
        for ns, name, accessor in dict.fromkeys(by_name + lite):
            # the attributes this read can take: indexOfAttribute's test on the stored strings
            same = [a for a in e.attributes if R.by_name_matches(a, ns, name)]
            # compared on what this accessor reads (XmlBlock): a string reader the raw string,
            # an int / boolean reader the typed int data (its default for any other type)
            if len({_accessor_value(a, accessor) for a in same}) > 1:
                who = [
                    label
                    for label, rows in (("the full parser", by_name), ("ApkLite", lite))
                    if (ns, name, accessor) in rows
                ]
                repeats.append(
                    (
                        "high",
                        f"{'android:' if ns else ''}{name} {len(same)}× by name — "
                        f"{' and '.join(who)} read(s) the first "
                        f"({_accessor_value(same[0], accessor)!r}); a reader keeping the last "
                        f"shows {_accessor_value(same[-1], accessor)!r}",
                    )
                )
        if unread:
            out.append(
                Anomaly(
                    kind="attribute_unread",
                    severity="high",
                    path=path,
                    attr=unread[0].split(" ")[0],
                    detail=f"{len(unread)} attribute(s) on <{e.tag}> the package parser's "
                    "styleable read passes (AOSP's RetrieveAttributes walk takes no value for "
                    "them — placed after a higher ResID, or a null reached first): the full "
                    "parser applies none where a tree reader shows one — "
                    + "; ".join(unread[:5]),
                )
            )
        if repeats:
            severity = "high" if any(sev == "high" for sev, _ in repeats) else "medium"
            out.append(
                Anomaly(
                    kind="duplicate_attribute",
                    severity=severity,
                    path=path,
                    attr=(
                        repeats[0][1].split(" ")[0]
                        if not repeats[0][1].startswith("ResID")
                        else repeats[0][1].split(" ")[1]
                    ),
                    detail=f"repeated attribute(s) on <{e.tag}>: "
                    + "; ".join(t for _, t in repeats[:5]),
                )
            )
    return out


def _accessor_value(a: Attribute | None, accessor: str) -> object:
    """Return what ``XmlResourceParser.<accessor>(ns, name)`` gets from the attribute ``a``.

    getAttributeValue: the raw string, else the typed value as text (XmlBlock.java:288);
    getAttributeIntValue / BooleanValue: the typed data of an int-range type, else the
    caller's default (XmlBlock.java:514-559) — never the raw string.
    """
    if a is None:
        return None
    if accessor == "getAttributeValue":
        return _by_name_text(a)
    if 0x10 <= a.type_code <= 0x1F:
        return (a.raw != 0) if "Boolean" in accessor else a.raw
    return "(the reader's default)"


def _by_name_text(a: Attribute) -> object:
    """Return what ``XmlBlock.getAttributeValue`` gives for ``a`` (``reads.by_name_text``)."""
    text = R.by_name_text_of(a)
    if isinstance(text, (R.Unresolved, R.Throws)):
        return f"<not known: {text.why}>"  # never the explanation shown as if it were the value
    return text


def _removed_run_finding(r: Replay, doc: str) -> list[Anomaly]:
    """Report the longest run of siblings XmlBlock removes (next() recurses once per removal)."""
    out: list[Anomaly] = []
    if r.removed_run > 1:
        # a raw fact: XmlBlock.Parser.next() recurses once per removed sibling (XmlBlock.java:367)
        deep = r.removed_run >= _DEEP_RECURSION
        out.append(
            Anomaly(
                kind="dispatch_divergence",
                severity="high" if deep else "info",
                path=doc,
                attr="removed_run",
                detail=f"{r.removed_run} consecutive sibling elements are removed by their "
                "binary-XML flags"
                + (
                    " (the longest among the flag settings run; not every setting was run)"
                    if r.capped is not None
                    else ""
                )
                + (
                    f" ({_witness(r.removed_run_with)})"
                    if r.removed_run_with is not None
                    else ""
                )
                + ": XmlBlock's next() recurses once per removal"
                + (
                    "; whether the device's parse survives that depth (a StackOverflowError "
                    "fails the install) is not probed"
                    if deep
                    else ""
                ),
            )
        )
    return out


def _detect_dispatch(manifest: Manifest, paths: dict[int, str]) -> list[Anomaly]:
    """Where the device's package parser reads the manifest differently from its XML tree.

    The parser's loops dispatch every start tag an earlier handler left unconsumed, at any depth,
    and skip a tag they do not know with its subtree (dispatch.py, verified on a device): a tree
    reader shows what is visible where it looks, the device reads what its loops reach. Each
    finding is one fact with a count and examples — never one finding per element (a hostile
    manifest could fan out thousands).
    """
    r = manifest.dispatch
    root = manifest.root
    doc = root.tag if root else ""
    out: list[Anomaly] = []
    if r.install_error is not None:
        out.append(
            Anomaly(
                kind="dispatch_divergence",
                severity="high",
                path=doc,
                attr="install_error",
                detail=f"the device's package parser refuses this manifest — {r.install_error} "
                "— so the package never installs, whatever a tree reader shows of it",
            )
        )
        out.extend(_removed_run_finding(r, doc))  # a raw fact on every path
        return out
    if r.conditional_install_error is not None:
        out.append(
            Anomaly(
                kind="dispatch_divergence",
                severity="high",
                path=doc,
                attr="install_error",
                detail=f"the device's package parser refuses this manifest {r.conditional_install_error} "
                "— a flag decides whether the package installs at all, which no tree reader shows",
            )
        )
    if r.capped is not None:
        out.append(
            Anomaly(
                kind="dispatch_divergence",
                severity="high",
                path=doc,
                attr="flag_settings",
                detail=f"{r.capped} — an element a flag combination past those run exposes "
                "(a component, a permission) is read on such a device and not shown here",
            )
        )
    out.extend(_removed_run_finding(r, doc))
    if r.incomplete is not None:
        out.append(
            Anomaly(
                kind="dispatch_divergence",
                severity="info",
                path=doc,
                attr="incomplete",
                detail=f"the dispatch replay is incomplete: {r.incomplete}",
            )
        )

    def where(e: Element) -> str:
        return paths.get(id(e), e.tag)

    def top(e: Element) -> Element:
        while (up := r.parent(e)) is not None:
            e = up
        return e

    # The application a tree reader takes (the first <application> under <manifest>) against the
    # one the device reads (the first the manifest loop dispatches — possibly nested).
    visible = (
        next((c for c in root.children if c.tag == "application"), None)
        if root
        else None
    )
    read = r.effective("application")
    effective = read[0].element if read else None
    if effective is not None and effective is not visible:
        seen = (
            f"the <application> at line {visible.line}"
            if visible
            else "no <application>"
        )
        out.append(
            Anomaly(
                kind="dispatch_divergence",
                severity="high",
                path=where(effective),
                attr="application",
                detail=f"the device reads the <application> at line {effective.line} "
                f"({where(effective)}), "
                + (
                    "in a later top-level element (the parsers read the first one XmlBlock "
                    "keeps)"
                    if top(effective) is not root
                    else "nested where a handler leaves its subtree"
                )
                + f"; a tree reader takes {seen} — its components, flags and label are not the "
                "ones installed",
            )
        )
    hidden: dict[str, list[Dispatched]] = {}
    unread: dict[str, list[Dispatched]] = {}
    for d in r.dispatched:
        if d.outcome == "read" and d.effect is not None and r.hidden(d):
            hidden.setdefault(d.effect, []).append(d)
        elif (
            d.element.tag in _UNREAD_TAGS
            and (d.outcome != "read" or d.effect is None)
            and not d.by_value  # an SDK range or a non-string name: the parser's own rule
        ):
            unread.setdefault(d.element.tag, []).append(d)
    for effect, ds in hidden.items():
        e = ds[0].element
        out.append(
            Anomaly(
                kind="dispatch_divergence",
                severity="high",
                path=where(e),
                attr=f"hidden:{effect}",
                detail=f"{len(ds)} <{e.tag}> element(s) the device reads from a place a tree "
                f"reader does not look — e.g. line {e.line}, {r.how_hidden(ds[0])}",
            )
        )
    for tag, ds in unread.items():
        d = ds[0]
        why = d.because or d.outcome.replace("_", " ")
        if d.outcome == "read":
            why = "its handler records nothing for it here"
        out.append(
            Anomaly(
                kind="dispatch_divergence",
                severity="high",
                path=where(d.element),
                attr=f"unread:{tag}",
                detail=f"{len(ds)} <{tag}> element(s) a tree reader shows that the device does not "
                + (
                    "read in any flag setting run (not every setting was run)"
                    if r.capped is not None
                    else "read"
                )
                + f" — e.g. line {d.element.line}: {why}",
            )
        )
    return out


# Tags whose absence from the device's reading changes what the app is: what it requests,
# declares and registers. Their descendants (a skipped activity's intent filters) are not counted
# again: the element itself is the fact.
_UNREAD_TAGS = frozenset(
    {
        "uses-permission",
        "uses-permission-sdk-23",
        "uses-permission-sdk-m",
        "permission",
        "permission-group",
        "permission-tree",
        "application",
        "activity",
        "activity-alias",
        "service",
        "receiver",
        "provider",
        "instrumentation",
    }
)


# Implemented: name_resid_mismatch, name_by_resid_only, dynamic_reference_masked,
# duplicate_attribute, not_consumed (access-control attrs vs per-tag styleable set),
# arsc_load_failed (resources.arsc present in the zip but rejected on load),
# dangling_resource_ref (app-package @ref that no arsc entry defines),
# ref_cycle + ref_chain_deep (reference-chain shape, from the #3 instrumentation).
#
# DELIBERATELY NOT a detector — an `unresolved` chain terminal (a hop naming an id no loaded
# package defines). It looks like a dangling ref but is not reproducible: the SDK android.jar we
# load as framework-res carries a stripped table, so 5 stock framework entries
# (alertDialog_material_*_margin) already terminate that way on a clean device image, and a
# not-mounted config split produces the same shape for a healthy app. dangling_resource_ref
# already covers the attacker-controlled case at the app-package HEAD using declared(), which has
# no such blind spot. The terminal is still reported factually on Resolution (ref_terminal /
# resolve_error) for the LLM to weigh.
#
# DELIBERATELY NOT a detector — split override: a split shadowing a base resource cannot be
# surfaced as a zero-FP anomaly. AOSP FindEntryInternal (AssetManager2.cpp:904-932) keeps the
# first stack package at an EQUAL config (the base loads before its splits, and splits are not
# custom loaders), and ResTable_config::match() is asymmetric so a config-qualified split variant
# (locale/density) never wins the default-config resolve — a split "winning" is unreachable for
# standard AAB/Play split sets. The one case a device DOES take a split's value (a config-specific
# variant on a matching device) is mechanically identical to benign localization, so flagging it
# would false-positive on every localized app. That signal is instead surfaced FACTUALLY via
# Resolution.source / source_role (which stack element supplied the value) for the LLM to weigh,
# not manufactured into a boolean. Splits are opt-in (ResourceTable extra_apks); the default
# per-APK flow never mounts sibling files (reproducibility + attacker-controlled-directory safety).
# DELIBERATELY NOT a detector — config_value_divergence (one id resolving to different values
# under different configurations). The enumeration this needed EXISTS (resolve_config_variants,
# #5/#8-era; the `resource_config_variants` tool already reports `diverges`), so the old "blocked
# on richer enumeration" note was stale. It is not an anomaly because localization is exactly this
# shape: measured over 40 corpus apps and 2,206 resolvable ids, 67 ids diverge and **17 of the 40
# apps (42%)** carry at least one. A detector that fires on nearly half of ordinary input is noise.
# The per-config values are surfaced factually by the tool for the LLM to weigh.
#
# DELIBERATELY NOT a detector — hidden_resource (SPEC_PUBLIC=0). The enumeration this needed also
# EXISTS now (#4: search_strings / pool_values / the #11 entries join), and `public` / `staged` are
# on every Resolution. It is not an anomaly because the flag is near-constant on app tables:
# measured over the same 40 apps, **98.6% of resolvable entries are non-public** (1,413 of 1,433).
# The flag is read correctly — the stock framework, which really does ship a public.xml, is 28.5%
# public by the same probe — it simply does not partition an APP's own resources. So "non-public
# AND suspicious content" is a content detector with a near-always-true conjunct.
#
# What WOULD be worth building is a narrower predicate the #11 join now makes answerable:
# non-public AND unreachable from the manifest AND carrying a URL. That is a different claim from
# either of the above and needs its own measurement before it earns a detector.
