"""Facts about this host's limits that change what a native allocation does (facts, not judgements).

Read where they matter: by the worker Session when it spawns a worker (the worker inherits them) and
by the anomaly detector that labels a table this host could not allocate. POSIX only.
"""

from __future__ import annotations

try:
    import resource
except ImportError:  # emscripten/wasm: no rlimits — a browser tab's memory cap
    resource = None  # is the wasm heap limit, not an inherited POSIX limit.


def memory_limits() -> dict[str, int | bool]:
    """Read the host's memory limits a worker inherits; each key is present only when it holds.

    ``inherited_memory_limit`` is the smaller finite RLIMIT_AS / RLIMIT_DATA soft limit in bytes;
    ``strict_overcommit`` is ``vm.overcommit_memory == 2``.

    Under either, an allocation AOSP makes can fail on this host where a device's would not; no
    label repairs what that failure became inside AOSP, so it is stated wherever answers are given.
    """
    facts: dict[str, int | bool] = {}
    if resource is None:
        return facts
    finite = [
        soft
        for soft, _ in (
            resource.getrlimit(resource.RLIMIT_AS),
            resource.getrlimit(resource.RLIMIT_DATA),
        )
        if soft != resource.RLIM_INFINITY
    ]
    if finite:
        facts["inherited_memory_limit"] = min(finite)
    try:
        with open("/proc/sys/vm/overcommit_memory") as f:
            if f.read().strip() == "2":
                facts["strict_overcommit"] = True
    except OSError:
        pass
    return facts


def cpu_limit() -> int | None:
    """Return the finite RLIMIT_CPU soft limit in seconds (a SIGXCPU's cause), or None."""
    if resource is None:
        return None
    soft = resource.getrlimit(resource.RLIMIT_CPU)[0]
    return None if soft == resource.RLIM_INFINITY else soft
