"""Run the tools in a worker process, so a hostile APK that crashes the native core costs one call.

The analyzer is AOSP's own C++ (libandroidfw) on attacker-built input. Where AOSP reads without
checking, the binding guards the paths it knows (the name lookup, the bag parent chain, the package
id), but every guard is one more hand-copied piece of AOSP, and an audit still found an unguarded
out-of-chunk read under ``resolve()``. This module is the backstop under every guard: the
``Manifest`` and its native objects live in a child process, a call that kills the child with a
FAULT signal returns a structured ``native_crash`` result (itself a finding — the APK attacks the
parser), and the next call starts a fresh child. A call that does not answer within ``timeout`` ends
the child (``native_timeout``).

What it does not do: a read that stays inside mapped memory does not fault, so it gives a silent
answer — the guards remain the only defence there. And it protects only callers that dispatch
THROUGH it: a server calling ``tools.execute`` directly gets none of this. POSIX only.

Its scope is a crash or a hang. It is NOT a sandbox: the child runs as the caller's user, so a
parser exploit that gains code execution in it can harm the caller directly (kill it, write its
files) — containing that needs privilege separation, which this does not attempt (review). Within
that scope, nothing the child SENDS can do more than produce an error result:

* answers are length-capped JSON, never pickle (review: a pickled answer ran code in the parent),
  and a frame that does not decode — malformed, or nested to exhaust the decoder — is refused;
* each call has ONE deadline over the write of the request and the read of the whole answer, waited
  on with ``poll`` (``select`` refuses fds past 1024, which a busy server reaches — review); a
  worker the Session kills is then waited for until it is reaped, which can pass the deadline by
  the time it takes to unmap (milliseconds per GB);
* the child runs from ``/`` with only absolute import paths (review: a planted ``axmlllm/`` in the
  server's working directory was imported first). It keeps the caller's environment: the framework
  lookup reads ANDROID_HOME, and stripping it changed the answers (review);
* its stdout and stderr never reach the caller's (an MCP stdio server's stdout is its JSON-RPC
  channel): both go into one pipe the Session owns and drains while it waits — an inherited,
  undrained stderr stalled the worker into native_timeout (measured).

What the worker writes there comes back as data. AOSP logs to fd 2; in the worker its liblog floor
is FATAL, so query-time liblog lines (an attacker can multiply them per query; the facts the
structured answers do not carry yet are a tracked gap, D1) cost one priority check, and only
across each AOSP load step (ApkAssets::Load, each SetApkAssets) is it ERROR — so the reason a
table did not load is AOSP's own text. Each step is bracketed by
``<nonce> BEGIN|END <attempt> <purpose> <step> [<status>]`` markers; the nonce is drawn per worker
and handed to the Session in the hello frame on the answer pipe, so no text on the log pipe can
forge a boundary. A call's answer carries what was written outside any step during it
(``aosp_log``: a crash's last words, an assert, a direct writer AOSP has outside liblog). Each
load step that said something or did not end ok is told ONCE, on the first answer after it
finished — whichever tool made the worker load the table — or on the record of a worker that died
inside it (``aosp_load_log``: its status ok / failed / unwound / unterminated, and whether it was
the table's own attempt or a discarded one: a split's probe, a stack attempt a fallback
replaced); ``Session.load_log`` keeps all of the worker last used (an earlier worker's rode on
its answers and its death record), and steps past the cap are told as a count as it grows. No file path reaches that text from the sample: AOSP is handed the APK as
``/proc/self/fd/N`` (or ``/dev/fd/N``) — the descriptor the worker opened — and on a host with
neither, as a link with a fixed name in a private temporary directory the Session makes and
removes when it settles the worker (the link's path is replaced by ``<apk>``). The framework's host
path is replaced by ``<framework>`` wherever it occurs, and the worker's own Python output prints
no traceback (see _quiet_paths). Bounds: each stretch keeps its first and last 2 KB read and
counts the rest; at most 64 steps per worker, the rest counted; at most 16 K characters of step
text per answer, the rest on the next. While a call waits, the pipe is read at most one 50 ms
slice at a time and the answer is taken first (a flood cannot starve it); after the answer, and
when a worker ends, exactly what the pipe holds at that moment is read and parsed — bounded by
the pipe's 1 MiB, not by time (measured: up to about 0.4 s for 1 MiB of one-byte lines), so a
writer that keeps going, or a process the worker left holding the pipe, cannot hold a call. Every byte outside printable ASCII is escaped. All of it is attacker-influenced
and is passed as labelled data, never as a finding. In-process callers' logging is unchanged.

Memory is bounded from OUTSIDE the worker. An in-worker RLIMIT is not used: under one, AOSP's
load fails where a device's would not, and the most the analysis can then do is say "not judged
on this host" (the host's refusal is witnessed natively) — so the worker never sees a limit, and
every answer is either identical to an unbounded run or labelled. While a
call waits, the parent samples the worker's anonymous memory (``RssAnon + VmSwap`` from its
``/proc/<pid>/status``, opened once at its start) about every 50 ms (at most two slices apart),
whether the worker is silent or writing; past ``memory_limit`` (default ``DEFAULT_MEMORY_LIMIT``;
None disables) the worker is ended and the call answers ``native_memory_bound`` with
``memory_at_call_start`` / ``memory_observed`` — neutral like ``native_timeout``, not a crash.
Limits of the bound, stated: the overshoot is about the allocation rate times 50 ms (measured 700
MB/s inflate: +44 MB); a spike freed between samples is not seen (its answer is identical anyway);
an idle worker is not sampled (it is blocked reading; growing then takes code running in another of
its threads); the bound is per worker, so N Sessions can hold N times it; shared memory, page
tables, kernel memory and any process the worker forks are not counted — reaching those takes code
execution in the worker, which this does not contain (above). Whether a worker's memory can be read
at all is decided once, at its start: no ``/proc``, an unopenable status, or a kernel that prints
VmRSS without RssAnon (before 4.5; WSL1, gVisor) puts ``memory_bound_unenforced`` on the answers of
the calls that worker served, including the one that ended it, as does a later read that fails other
than by the worker's reap; the next worker is judged afresh. A worker whose main thread has exited
while others run is measured through a task that still holds its address space. Without a status the
worker's phase is its wait status alone: it reads as live, so it is reused, and ended at once, never
awaited. A limit the worker inherits (a finite RLIMIT_AS / RLIMIT_DATA, ``vm.overcommit_memory =
2``) still fails AOSP's allocations inside the worker, which no label repairs, so every answer
states it (``inherited_memory_limit``, ``strict_overcommit``); a cgroup limit, which kills rather
than failing an allocation, is not read. The worker sets its ``oom_score_adj`` to 1000: victim
choice only, so the kernel's OOM killer takes it before the caller — systemd's OOMPolicy=stop and
systemd-oomd still act on the whole scope; the parent's bound firing first is what protects the
host.

Every end is settled by ONE rule. Whether a worker has ended is its wait status's alone; until then
its phase is read from the kernel's status text of its address space: live; dumping (``CoreDumping:
1`` — apport keeps it alive about a second); exiting (its address space already dropped, not yet a
zombie — measured about 18 ms per GB it had mapped). A dumping or exiting worker is waited for
within the call's deadline, not killed (a kill during a dump turns its SIGSEGV into SIGKILL); a live
one is killed only when the Session ends it. A worker between the end of its dump and its exit reads
live and may be sent that kill; the kill cannot change the status the fault fixed, and the fault is
reported as itself (only a fault in the microseconds between the last read and the kill, before the
kernel fixed a status, becomes the kill). The status reported is always the one the worker's wait
gives, and only two ends are not told as the worker's own: the SIGKILL the Session sent, and the
exit an open-error hello ends with. The Session closes a worker's pipes only once it has settled
it — killed, or ended by itself (closing first handed a live one an EOF or EPIPE to exit on — an
end it caused, read as the worker's own; measured) — and a worker that broke the protocol, or
says it cannot open the APK, gets a moment, within the call's deadline, to end by itself first; so a fault that came first, before a bound, a deadline or a close, and an
exit the worker chose, are reported as themselves. A worker still ending at the deadline
is kept, and the call answers ``core_dumping`` (or ``worker_exiting``) with ``during``; one killed
that has not yet ended keeps its reason's answer, and a next call held by it says
``worker_unreaped``; the next call, within its own one deadline, or ``close()`` settles it. A worker that ends outside a call — after answering (a fault from another of
its threads, an outside kill), or before it took the next request (it writes a one-byte receipt the
moment it has; a request it never took runs on a fresh worker) — is reported on the next answer as
``previous_worker_died``: its raw status, with ``after`` (the tool it last answered — also for an
end before it took the request of the call that found it) or ``during`` (the call it was ending in)
— a list, one record per death. It rides on every return path and is kept across an exception until
delivered. A FAULT there counts in ``crashes`` — a stated model: a fault outside a call is taken as
the APK's (a deferred teardown of what it built); an outside SIGSEGV would be misattributed the same
way, and a fault from another worker thread while a call is in flight lands in that call.
``close()`` records what it settles, and any death no answer carried, in ``last_worker_status``. An
answer carrying a key only the Session states (``native_crash``, ``previous_worker_died``, the host
facts, ...) is refused. Kernels without the CoreDumping line degrade to killing at once; a core
helper that never finishes holds every call at ``core_dumping`` until it does.

Everything a worker holds lives and dies with it: whatever replaces a worker (any of the ends
above) takes every ``read_string`` ref it handed out with it, and such a ref answers as one from
a replaced worker — re-run the call that showed it.

Known gaps, left documented rather than patched over: a child spinning in native code outlives a
caller that is SIGKILLed mid-call, until it is killed (PR_SET_PDEATHSIG fires when the spawning
THREAD exits, and broke thread-pool servers — review); a host that restores SIGPIPE to SIG_DFL dies
writing to a dead worker (Python ignores SIGPIPE by default). And nothing about a failed start is
remembered, so an APK that hangs while being OPENED costs the full ``timeout`` on every call —
callers serving many APKs should set ``timeout`` to what they can afford per call.

Usage::

    with Session("app.apk") as s:
        s.execute("list_resources", {"limit": 50})
"""

from __future__ import annotations

import fcntl
import importlib
import json
import os
import re
import select
import shutil
import signal
import struct
import subprocess
import sys
import tempfile
import termios
import threading
import time
from typing import Any, Callable

from axmlllm._host import cpu_limit, memory_limits

DEFAULT_TIMEOUT = 60.0
# A documented policy like DEFAULT_TIMEOUT, not a fact about any APK: the most anonymous memory one
# worker may hold before the Session ends it (None disables the bound).
DEFAULT_MEMORY_LIMIT = 8 * 1024**3
MAX_ANSWER_BYTES = 1024 * 1024  # a tool response is bounded at ~160 KB by tools.execute
_EXECUTE = "axmlllm.tools:execute"
# The worker's entry: a traceback names every source file on its stack (the host's install, the
# user's home), so before ANY import — a broken or mismatched native module fails right here —
# an uncaught exception is told by its type alone; _quiet_paths then installs the full hooks.
_BOOT = (
    "import sys\n"
    # -c puts '' (the working directory, '/') first on sys.path: a planted axmlllm/ there
    # would be imported first (review). (-P does this, from Python 3.11 only.)
    "sys.path[:] = [p for p in sys.path if p]\n"
    "sys.excepthook = lambda t, e, tb: sys.stderr.write('uncaught ' + t.__name__ + '\\n')\n"
    "from axmlllm.isolated import _main\n"
    "_main()\n"
)
_HEADER = struct.Struct("<Q")
# The worker's one-byte receipt: it has read the whole request. A death before it is not this call's.
_ACK = b"\x06"
_SLICE = 0.05  # seconds between memory samples while a call waits on its worker
_STATUS_CHUNK = 65536  # one pread of /proc/<pid>/status; the read loops to EOF past it
# The worker's fd 1 and fd 2 go into one pipe the Session drains (an undrained inherited stderr
# stalled the worker: native_timeout on a 30 KB APK under an MCP parent). Each stretch of it —
# one call's bytes, one load step's — keeps its first and its last _LOG_KEEP bytes and counts the
# middle; the pipe is enlarged so a burst waits in the kernel, not in the worker.
# escaped, at most 4 characters per byte: <= 16 K characters per stretch
_LOG_KEEP = 2048
_LOG_PIPE_SIZE = 1 << 20
_WORKER_DIR_ENV = "AXMLLLM_WORKER_DIR"  # see _fixed_name
_MAX_STEPS = 64  # load steps kept per worker (an honest table takes 5 per attempt)
_LOG_NEWS_CHARS = 16384  # load-step text one answer carries; the rest rides on the next
# A worker that closed its answer pipe while its memory is still mapped (a protocol violation: an
# exiting process unmaps first and closes its files after) gets this long to exit before it is
# ended. A policy, not a measurement: by the kernel's order it could be 0; one second costs a
# broken worker nothing and spares an honest one that closed early by design.
_PIPE_CLOSED_GRACE = 1.0
# Signals a FAULT in the process raises itself. Anything else (SIGTERM, SIGINT; a SIGKILL — possibly
# the OOM killer, which the worker's oom_score_adj steers to it — is not evidence of a parser fault)
# came from outside and says nothing about the APK (review). SIGQUIT / SIGXCPU / SIGXFSZ also dump
# core, so a worker they hit is waited for like a faulting one, but they are not counted here.
_FAULTS = {signal.SIGSEGV, signal.SIGBUS, signal.SIGILL, signal.SIGFPE, signal.SIGABRT,
           signal.SIGTRAP, signal.SIGSYS}  # fmt: skip
# Keys only the Session states. An answer from the worker that carries one is refused: a worker
# cannot report its own crash, the host's limits, or another worker's death.
_SESSION_KEYS = frozenset({
    "native_crash", "native_timeout", "native_memory_bound", "core_dumping", "worker_exiting",
    "worker_unreaped", "still_ending",
    "worker_killed", "worker_exit", "worker_refused", "session_closed", "previous_worker_died",
    "memory_bound_unenforced", "inherited_memory_limit", "strict_overcommit",
    "inherited_cpu_limit", "memory_observed", "memory_at_call_start", "aosp_log", "aosp_load_log",
})  # fmt: skip


class _Deadline(Exception):
    pass


class _OverMemory(Exception):
    def __init__(self, observed: int) -> None:
        super().__init__(observed)
        self.observed = observed


class _StatusUnreadable(Exception):
    """Reading a worker's status failed (any reason, its reap included: wait() says ended)."""


class _Watch:
    """What a wait does besides waiting: sample the worker's memory, drain its log pipe."""

    def __init__(
        self, sample: Callable[[], None] | None, log: _Worker | None = None
    ) -> None:
        self.sample = sample
        self.log = log


def _wait(fd: int, event: int, deadline: float, watch: _Watch | None = None) -> bool:
    """Wait for ``event`` on ``fd`` until ``deadline``; True when it came, False at the deadline.

    Per slice the sampler is offered (it may raise; it keeps its own clock across waits, so a
    worker that trickles its answer a byte at a time is sampled all the same), and the worker's log
    pipe is drained whenever it is readable. Draining is a side effect: it never ends the wait,
    and a flood cannot starve it — the deadline is re-checked between chunks (see _Worker.drain).
    """
    p = select.poll()
    p.register(fd, event)
    log = watch.log if watch is not None else None
    err = log.err if log is not None else None
    if err is not None:
        p.register(err, select.POLLIN)
    while True:
        left = deadline - time.monotonic()
        if left <= 0:
            return False
        if watch is not None and watch.sample is not None:
            watch.sample()
        events = p.poll(min(left, _SLICE) * 1000)
        if any(ready == fd for ready, _ in events):
            return True  # the answer first: a log flood must not starve an answer that came
        if log is not None and err is not None and events:
            # the pipe's write end gone: nothing more comes
            if not log.drain(min(deadline, time.monotonic() + _SLICE)):
                p.unregister(err)
                err = None


def _write_all(
    fd: int, data: bytes, deadline: float, watch: _Watch | None = None
) -> None:
    """Write all of ``data`` to the NON-BLOCKING ``fd`` by ``deadline``.

    On a blocking pipe a write of more than its buffer waits for the reader whatever the poll
    answered — measured: the write deadline was no deadline until the fd was made non-blocking.
    """
    view = memoryview(data)
    while view:
        if not _wait(fd, select.POLLOUT, deadline, watch):
            raise _Deadline
        try:
            view = view[os.write(fd, view) :]
        except BlockingIOError:
            continue


def _read_exact(fd: int, n: int, deadline: float, watch: _Watch | None = None) -> bytes:
    out = bytearray()
    while len(out) < n:
        if not _wait(fd, select.POLLIN, deadline, watch):
            raise _Deadline
        chunk = os.read(fd, n - len(out))
        if not chunk:
            raise EOFError
        out += chunk
    return bytes(out)


def _frame(obj: Any) -> bytes:
    body = json.dumps(obj, default=str).encode()
    return _HEADER.pack(len(body)) + body


def _signal_name(sig: int) -> str:
    try:
        return signal.Signals(sig).name
    except ValueError:
        return f"signal {sig}"


def _escape(raw: bytes) -> str:
    r"""Render printable ASCII, tab and newline as they are; every other byte as \xNN."""
    return "".join(
        chr(b) if 32 <= b < 127 or b in (9, 10) else f"\\x{b:02x}" for b in raw
    )


class _Kept:
    """One stretch of log bytes: its first and last _LOG_KEEP bytes kept, the middle counted."""

    def __init__(self) -> None:
        self.head = bytearray()
        self.tail = bytearray()
        self.total = 0

    def add(self, data: bytes) -> None:
        self.total += len(data)
        room = _LOG_KEEP - len(self.head)
        if room > 0:
            self.head += data[:room]
            data = data[room:]
        if data:
            self.tail += data
            del self.tail[:-_LOG_KEEP]

    def render(self) -> dict[str, Any]:
        dropped = self.total - len(self.head) - len(self.tail)
        text = _escape(bytes(self.head))
        if dropped:
            text += f"\n[... {dropped} bytes not kept ...]\n"
        return {"text": text + _escape(bytes(self.tail)), "dropped_bytes": dropped}


class _LogSink:
    """The worker's log pipe, read: per-call bytes, and the load steps its nonce'd markers bound.

    A marker is ``<nonce> BEGIN <attempt> <purpose> <step>`` / ``<nonce> END ... <status>``; the
    nonce came in the worker's hello frame, on the ANSWER pipe, so text on this pipe (AOSP lines
    carrying table bytes) cannot forge one — a marker-looking line without it is data. Bytes
    between a BEGIN and its END are that step's; all others belong to the call in flight. The
    sample's file name never reaches this text (the worker hands AOSP a descriptor spelling, or
    a fixed-name link); the framework's path, a host path, is replaced wherever it occurs. A
    line is split only past 2 x _LOG_KEEP bytes without a newline. At most _MAX_STEPS steps are
    kept per worker, the rest counted with their bytes: an honest load takes 5, so the cap
    bounds what a worker running code of its own can make the parent hold.
    """

    def __init__(self) -> None:
        self.nonce: bytes | None = None
        self._paths: list[tuple[re.Pattern[bytes], bytes]] = []
        self._buf = bytearray()
        self.call = _Kept()
        self.steps: list[dict[str, Any]] = []
        self.delivered = 0  # steps[:delivered] went out on an answer already
        self._open: dict[str, Any] | None = None
        self._omitted = 0
        self._omitted_told = 0
        self._omitted_bytes = _Kept()
        self._omitting = False

    def add_path(self, path: bytes, label: bytes) -> None:
        """Replace ``path`` wherever it occurs: an absolute file path, too long to match by chance."""
        if len(path) > 1:
            self._paths.append((re.compile(re.escape(path)), label))

    def feed(self, data: bytes) -> None:
        self._buf += data
        while (nl := self._buf.find(b"\n")) >= 0:
            line = bytes(self._buf[: nl + 1])
            del self._buf[: nl + 1]
            self._line(line)
        if (
            len(self._buf) > 2 * _LOG_KEEP
        ):  # a line with no end: keep it, but not unboundedly
            # what is cut off ends 512 bytes back: a marker or a path split across reads stays whole
            cut = len(self._buf) - 512
            self._data(bytes(self._buf[:cut]))
            del self._buf[:cut]

    def flush(self) -> None:
        if self._buf:
            self._data(bytes(self._buf))
            self._buf.clear()

    def _line(self, line: bytes) -> None:
        nonce = self.nonce
        at = line.find(nonce + b" ") if nonce else -1
        if nonce is None or at < 0:
            self._data(line)
            return
        fields = line[at + len(nonce) + 1 :].rstrip(b"\n").split(b" ")
        begin = len(fields) == 4 and fields[0] == b"BEGIN"
        end = (
            len(fields) == 5
            and fields[0] == b"END"
            and fields[4] in (b"ok", b"failed", b"unwound")
        )
        if not (begin or end) or not fields[1].isdigit():
            self._data(line)
            return
        if at:  # what preceded it on that line is the current stretch's
            self._data(line[:at])
        key = (int(fields[1]), fields[2].decode("ascii", "replace"),
               fields[3].decode("ascii", "replace"))  # fmt: skip
        if begin:
            if len(self.steps) >= _MAX_STEPS:
                self._omitted += 1
                self._omitting = True
                return
            self._open = {"attempt": key[0], "purpose": key[1], "step": key[2], "status": None,
                          "kept": _Kept()}  # fmt: skip
            self.steps.append(self._open)
        elif self._omitting:
            self._omitting = False
        elif (
            self._open is not None
            and (self._open["attempt"], self._open["purpose"], self._open["step"])
            == key
        ):
            self._open["status"] = fields[4].decode()
            self._open = None
        else:
            self._data(line)

    def _data(self, raw: bytes) -> None:
        for pattern, label in self._paths:
            raw = pattern.sub(label, raw)
        if self._omitting:
            self._omitted_bytes.add(raw)
        else:
            (self._open["kept"] if self._open is not None else self.call).add(raw)

    def take_call(self) -> dict[str, Any] | None:
        """Take this call's bytes outside any load step, rendered; None when there were none."""
        kept, self.call = self.call, _Kept()
        return kept.render() if kept.total else None

    def _render(self, steps: list[dict[str, Any]], ended: bool) -> list[dict[str, Any]]:
        own = max(
            (
                st["attempt"]
                for st in self.steps
                if st["purpose"] in ("stack", "fallback")
            ),
            default=None,
        )
        out = []
        for st in steps:
            status = st["status"] or ("unterminated" if ended else "running")
            if status == "ok" and not st["kept"].total:
                continue
            out.append({"attempt": st["attempt"], "purpose": st["purpose"], "step": st["step"],
                        "status": status, "discarded": st["attempt"] != own,
                        **st["kept"].render()})  # fmt: skip
        return out

    def load_log(self, ended: bool = False) -> list[dict[str, Any]]:
        """Every load step that said something or did not end ok, the table's own marked.

        The table's own attempt is the LAST ``stack`` or ``fallback`` one, whatever its status;
        a split's probe, and a ``stack`` attempt a ``fallback`` superseded, are ``discarded``. A
        step with no END is ``unterminated`` once the worker has ended (``running`` before).
        """
        out = self._render(self.steps, ended)
        if self._omitted:
            out.append({"omitted_steps": self._omitted, **self._omitted_bytes.render()})
        return out

    def news(self, ended: bool) -> list[dict[str, Any]]:
        """Take the steps no answer has carried yet: each is told once, when it has finished.

        A step still open is held back until it ends — or until the worker has (unterminated).
        At most _LOG_NEWS_CHARS of text go out at once; the rest wait for the next answer.
        """
        ready = []
        for st in self.steps[self.delivered :]:
            if st["status"] is None and not ended:
                break
            ready.append(st)
        out: list[dict[str, Any]] = []
        size = 0
        for st, rendered in zip(ready, [self._render([st], ended) for st in ready]):
            text = sum(len(x["text"]) for x in rendered)
            if out and size + text > _LOG_NEWS_CHARS:
                break
            out.extend(rendered)
            size += text
            self.delivered += 1
        # told as it grows, never only at the end
        if self._omitted > self._omitted_told:
            out.append({"omitted_steps": self._omitted, **self._omitted_bytes.render()})
            self._omitted_told = self._omitted
        return out


def _status_field(status: str, key: str) -> str | None:
    for line in status.splitlines():
        name, sep, value = line.partition(":")
        if sep and name == key:
            return value.strip()
    return None


def _anon_bytes(status: str) -> int | None:
    """``RssAnon + VmSwap`` in bytes from a ``/proc/<pid>/status`` text; None without ``RssAnon``.

    Anonymous memory only: the APK and the native module are file-backed mappings the kernel can drop
    and re-read, and counting them would charge a big APK for being mapped, not for what it makes
    the parser allocate.
    """
    anon = _status_field(status, "RssAnon")
    if anon is None:
        return None
    swap = _status_field(status, "VmSwap")
    return (int(anon.split()[0]) + (int(swap.split()[0]) if swap else 0)) * 1024


# A worker's phase. ONE rule: whether it has ended is its wait status's alone; how it stands until
# then is read from the kernel's status text of its address space (fs/proc/array.c):
#   live     — it has an address space (the Vm*/Rss* lines are printed only while task->mm is set),
#              or nothing can be read (no /proc, a failed read): unknown is not gone;
#   dumping  — ``CoreDumping: 1`` (mm->core_state: shown by every task still holding the mm);
#   exiting  — no task holds the address space any more: do_exit has run exit_mm (measured: about
#              18 ms per GB still mapped) and will close its files and become a zombie next;
#   gone     — its wait status is in.
# Dumping and exiting are ENDING: the worker is waited for, not killed (a kill during a dump turns
# its SIGSEGV into SIGKILL, measured -9 vs -11; during exit it changes nothing but wastes the status
# the exit is about to give).
_ENDING = ("dumping", "exiting")


def _phase(status: str | None, alive: bool, vm_lines: bool = True) -> str:
    """Name a worker's phase from its address space's status text and its wait status.

    ``status`` None: nothing could be read. ``vm_lines`` False: this kernel prints no VmRSS even
    for a live process (none known; then a missing line says nothing).
    """
    if not alive:
        return "gone"
    if status is None:
        return "live"
    if _status_field(status, "CoreDumping") == "1":
        return "dumping"
    if vm_lines and _status_field(status, "VmRSS") is None:
        return "exiting"
    return "live"


class _Worker:
    """One spawned worker: its process, its pipes, and its ``/proc`` status opened at its start.

    The status fd is opened while the Session still holds the unreaped child, so the pid it names
    cannot be reused; after the reap a read fails with ESRCH.
    """

    def __init__(
        self,
        proc: subprocess.Popen[bytes],
        req: int,
        ans: int,
        err: int,
        sink: _LogSink,
    ) -> None:
        self.proc = proc
        self.err: int | None = err  # read end of its fd 1 + fd 2 (non-blocking)
        self.sink = sink
        # the Session's directory for its fixed-name APK link
        self.link_dir: str | None = None
        self.pipe_closed = False  # its answer pipe gave EOF before it took a request
        self.req: int | None = req  # write end, parent -> child
        self.ans: int | None = ans  # read end, child -> parent
        self.ready = False  # it has opened the APK and said so
        self.after: str | None = None  # the last tool it answered
        self.during: str | None = None  # the call that was ending it when it was kept
        # anonymous memory sampled during the current call (kept until it takes the request)
        self.observed: int | None = None
        self.cpu_limit = cpu_limit()  # inherited at spawn, like the memory facts
        # the exit status its protocol ends with (the open-error hello: it returns, exit 0) —
        # the one end of its own the Session expects; every other status is told
        self.expected_exit: int | None = None
        self.killed = False  # the Session sent it SIGKILL: a -9 status is the Session's
        self.closed = False  # ...and that kill was close()'s
        # close() reads the phase from another thread; the fd must not close (and its number be
        # reused by some other open) between that read's check and its pread.
        self._fd_lock = threading.Lock()
        try:
            self.status: int | None = os.open(
                f"/proc/{proc.pid}/status", os.O_RDONLY | os.O_CLOEXEC
            )
        except OSError:
            self.status = None
        # Whether THIS worker's memory can be read: decided once, from its status at its start (an
        # exec'd process always has an address space). A kernel without RssAnon prints VmRSS
        # without it (before 4.5; WSL1, gVisor); no /proc or an unopenable status is the same.
        # Per worker, never sticky: a later worker on a sound host is bounded again. Only a read
        # that later FAILS can still turn it off (the sampler), and that is a different fact.
        try:
            first = self.read_status()
        except _StatusUnreadable:
            first = None
        self.enforced = first is not None and _anon_bytes(first) is not None
        self.vm_lines = first is None or _status_field(first, "VmRSS") is not None

    def read_status(self) -> str:
        """Read the whole status text (to EOF: a long Groups line passes 4 KB).

        Any failure — ESRCH after the reap, an ENOMEM under the very pressure the bound is for, no
        status to read at all (no /proc, an open that failed) — raises _StatusUnreadable: whether
        the worker has ended is its wait status's to say (see _phase), never a failed read's.
        """
        with self._fd_lock:
            if self.status is None:
                raise _StatusUnreadable("no status fd")
            out = bytearray()
            try:
                while chunk := os.pread(self.status, _STATUS_CHUNK, len(out)):
                    out += chunk
            except OSError as exc:
                raise _StatusUnreadable(exc) from exc
        return out.decode("ascii", "replace")

    def space_status(self) -> str | None:
        """Read the status of whichever task still holds the address space; None: unreadable.

        The main thread's own, unless it has exited (a zombie leader has no mm) while other
        threads run on: then theirs (/proc/<pid>/task/<tid>/status), which show the shared address
        space — its memory, and CoreDumping while a fault in any thread dumps. Only when the other
        threads WERE read and none holds it, the leader's text: no memory lines, so exiting. A
        listing or reads that fail are unknown (None), never exiting: an exiting worker is not
        killed, so an unknown one must not read as one.
        """
        try:
            status = self.read_status()
        except _StatusUnreadable:
            return None
        if _status_field(status, "VmRSS") is not None:
            return status
        if not (_status_field(status, "State") or "").startswith(("Z", "X")):
            return status
        try:
            tids = os.listdir(f"/proc/{self.proc.pid}/task")
        except OSError:
            return None
        read_any = False
        for tid in tids:
            if tid == str(self.proc.pid):
                continue
            try:
                with open(f"/proc/{self.proc.pid}/task/{tid}/status", "rb") as f:
                    text = f.read().decode("ascii", "replace")
            except OSError:
                continue
            read_any = True
            if _status_field(text, "VmRSS") is not None:
                return text
        # every other thread read, none holding the address space: exiting (or a lone leader)
        return status if read_any or len(tids) <= 1 else None

    def phase(self) -> str:
        """Read this worker's phase (see _phase): ended only by its wait status."""
        alive = self.proc.poll() is None
        return _phase(self.space_status() if alive else None, alive, self.vm_lines)

    def close_pipes(self) -> None:
        for fd in (self.req, self.ans):
            if fd is not None:
                os.close(fd)
        self.req = self.ans = None

    def drain(self, deadline: float) -> bool:
        """Read what its log pipe holds now into the sink; False once its write end is gone.

        Non-blocking, in chunks until EAGAIN or ``deadline`` (re-checked per chunk), so a worker
        that floods the pipe cannot hold a call past it.
        """
        err = self.err
        if err is None:
            return False
        while time.monotonic() < deadline:
            try:
                chunk = os.read(err, 65536)
            except BlockingIOError:
                return True
            if not chunk:
                return False
            self.sink.feed(chunk)
        return True

    def read_held(self) -> None:
        """Read exactly what the pipe holds at this moment (FIONREAD), every byte parsed.

        Bounded by the pipe's size (_LOG_PIPE_SIZE), not by time: a writer that keeps going adds
        only what follows the snapshot, which the next read takes. Nothing is skipped unparsed,
        so a load step's END in it is always seen.
        """
        err = self.err
        if err is None:
            return
        try:
            held = int.from_bytes(
                fcntl.ioctl(err, termios.FIONREAD, b"\0\0\0\0"), sys.byteorder
            )
        except OSError:
            return
        while held > 0:
            try:
                chunk = os.read(err, min(held, 65536))
            except BlockingIOError:
                return
            if not chunk:
                return
            self.sink.feed(chunk)
            held -= len(chunk)

    def close(self) -> None:
        self.close_pipes()
        with self._fd_lock:
            if self.status is not None:
                os.close(self.status)
                self.status = None
        if (
            self.link_dir is not None
        ):  # it takes no more requests: no more opens to serve
            shutil.rmtree(self.link_dir, ignore_errors=True)
            self.link_dir = None
        if self.err is not None:
            # its last words: what the pipe holds now (a process it left behind may hold the
            # pipe open and keep writing; what it adds later is not this worker's)
            self.read_held()
            self.sink.flush()
            os.close(self.err)
            self.err = None


class Session:
    """One APK's tools, answered by a worker process that a crash or a hang cannot take down."""

    def __init__(
        self,
        apk_path: str,
        *,
        timeout: float = DEFAULT_TIMEOUT,
        memory_limit: int | None = DEFAULT_MEMORY_LIMIT,
        _execute: str = _EXECUTE,
    ) -> None:
        """Bind to ``apk_path``; the worker starts on the first call."""
        self.apk_path = os.path.abspath(apk_path)
        self.timeout = timeout
        self.memory_limit = memory_limit
        self._execute = _execute
        self._w: _Worker | None = None
        # A worker whose end is not settled yet — ending (dumping / exiting) at its call's deadline,
        # or held while a call waits for it — kept, never killed into SIGKILL, until the next call
        # or close() settles it. At most one; no worker starts beside it.
        self._prev: _Worker | None = None
        # The death of a worker outside any call that reported it, attached to the next answer on
        # every return path and kept across an exception until it is delivered.
        self._pending: list[dict[str, Any]] = []
        self._served: _Worker | None = None  # the worker the call being answered used
        self._last: _Worker | None = None  # the worker last used, kept for its load_log
        self._host = memory_limits()
        self._closing = False
        # One request in flight: answers must not interleave. Nothing about a worker's start is
        # remembered across calls — a death or a hang may be the host's (an OOM kill, a loaded
        # machine), and an open error the file's of the moment (an APK still being copied).
        self._lock = threading.Lock()
        self.crashes = 0
        # What close() found, every time it ran (cumulative despite the name: a second close() does
        # not erase the first's record): deaths it settled and any not yet delivered.
        self.last_worker_status: list[dict[str, Any]] = []

    @property
    def _proc(self) -> subprocess.Popen[bytes] | None:
        return None if self._w is None else self._w.proc

    @property
    def memory_bound_enforced(self) -> bool:
        """Whether the current worker's memory is being bounded (False with no worker or limit)."""
        w = self._w
        return self.memory_limit is not None and w is not None and w.enforced

    def _start(self) -> None:
        req_r, req_w = os.pipe()
        ans_r, ans_w = os.pipe()
        err_r, err_w = os.pipe()
        env = dict(os.environ)
        link_dir = None
        if (
            not _fd_spellings()
        ):  # the worker will need a fixed name for the APK: made here
            link_dir = tempfile.mkdtemp(prefix="axmlllm-worker-")
            env[_WORKER_DIR_ENV] = link_dir
        try:
            fcntl.fcntl(err_r, fcntl.F_SETPIPE_SZ, _LOG_PIPE_SIZE)
        except (
            OSError,
            AttributeError,
        ):  # capped by pipe-max-size, or not Linux: the default
            pass
        try:
            paths = [p for p in sys.path if p and os.path.isabs(p)]
            # -u: Python's own fd 1 / fd 2 writes leave as made, in order with AOSP's
            proc = subprocess.Popen(
                [sys.executable, "-u", "-c", _BOOT, str(req_r), str(ans_w),
                 self.apk_path, self._execute],
                pass_fds=(req_r, ans_w), stdin=subprocess.DEVNULL, stdout=err_w, stderr=err_w,
                cwd="/", env=dict(env, PYTHONPATH=os.pathsep.join(paths)),
            )  # fmt: skip
        except BaseException:
            for fd in (req_r, req_w, ans_r, ans_w, err_r, err_w):
                os.close(fd)
            if link_dir is not None:
                shutil.rmtree(link_dir, ignore_errors=True)
            raise
        os.close(req_r)
        os.close(ans_w)
        os.close(err_w)
        os.set_blocking(req_w, False)  # see _write_all
        os.set_blocking(err_r, False)
        sink = _LogSink()
        if link_dir is not None:  # a host path in AOSP's text, like the framework's
            sink.add_path(os.fsencode(os.path.join(link_dir, "apk")), b"<apk>")
        self._w = _Worker(proc, req_w, ans_r, err_r, sink)
        self._w.link_dir = link_dir
        self._host = memory_limits()  # what this worker inherited

    def _stop(self, during: str | None = None, grace: float = 0.0) -> None:
        """End the current worker on the Session's own account; an ending one is kept, not killed.

        A live one is killed BEFORE its pipes close: closing them first handed it an EOF or an
        EPIPE to exit on, an end the Session caused that read as the worker's own (measured), so
        any status but the Session's SIGKILL is the worker's and is told. ``grace``: how long a
        live one may take to end by itself first (a worker that broke the protocol — a refused
        answer — is often ending already: killed at once, its own exit read as the Session's,
        measured 1 in 2).
        """
        w, self._w = self._w, None
        if w is None:
            return
        w.during = during
        # _prev is free whenever _stop runs (a call starts only once it is) — except, on Python
        # 3.9/3.10, between the two stores of a park interrupted by a signal; kept here, an ending
        # or unreaped worker is settled by the next call or close(), and a kept one found here is
        # told as still ending rather than overwritten.
        if self._prev is not None:
            self._pending.append(
                {"still_ending": True, **self._kept(self._prev, False)[1]}
            )
            self._prev.close()
        self._prev = w
        code, _ = self._settle(w, time.monotonic() + grace, grace=grace)
        if code is None:
            return
        self._prev = None
        record = self._death(code, w)
        if record is not None:
            self._pending.append(record)

    def execute(self, name: str, args: dict[str, Any] | None = None) -> dict[str, Any]:
        """Run tool ``name`` in the worker; a crash or a hang comes back as a result."""
        with self._lock:
            self._served = None
            # No worker can open it (a NUL ends a C path): that is the answer.
            if "\0" in os.fsdecode(self.apk_path):
                return self._annotate({"error": "the APK path contains a NUL byte"})
            try:
                answer = self._call(name, args)
            except BaseException:
                # The caller abandoned a request in flight (KeyboardInterrupt, a request timeout
                # raised by a signal): its answer would be read by the NEXT call (review).
                self._stop(during=name)
                raise
            return self._annotate(answer)

    def _annotate(self, answer: dict[str, Any]) -> dict[str, Any]:
        """Attach the raw facts every answer carries: host limits, an unenforced bound, a death."""
        out = dict(answer)
        out.update(self._host)
        # the worker this call used, even when the call has ended it: an unbounded worker's
        # timeout or OOM kill is where the label matters most
        w = self._served
        if self.memory_limit is not None and w is not None and not w.enforced:
            out["memory_bound_unenforced"] = True
        if self._pending:
            out["previous_worker_died"], self._pending = self._pending, []
        if w is not None:
            # What the worker wrote outside any load step during this call (a crash's last words,
            # an assert) — AOSP's and Python's own text, attacker-influenced, passed as data.
            # an honest worker writes nothing between its answer and the next request, so what
            # the pipe holds at this moment is this call's: all of it, parsed
            w.read_held()
            log = w.sink.take_call()
            if log is not None:
                out["aosp_log"] = log
            # Each load step that said something or did not end ok, told ONCE, on the first
            # answer after it finished — the call that loaded the table, whichever tool it was;
            # a worker that died inside a step tells it as unterminated. Session.load_log keeps
            # them all.
            if steps := w.sink.news(ended=w.err is None):
                out["aosp_load_log"] = steps
        return out

    @property
    def load_log(self) -> list[dict[str, Any]]:
        """AOSP's own text of each load step of the worker last used (see _LogSink.load_log)."""
        w = self._w or self._last
        return [] if w is None else w.sink.load_log(ended=w.err is None)

    def _sampler(self, w: _Worker) -> Callable[[], None] | None:
        """Sample ``w``'s anonymous memory; raise _OverMemory past the limit (read each sample)."""
        if not w.enforced:
            return None
        last = [
            0.0
        ]  # when this call last read the status: at most once per slice, busy or not

        def sample() -> None:
            limit = self.memory_limit
            now = time.monotonic()
            if limit is None or now - last[0] < _SLICE:
                return
            last[0] = now
            status = w.space_status()
            if status is None:
                # a live worker's read failed: this answer, and its later ones, say so (a worker
                # another thread has already reaped fails every read, and has no memory to bound)
                if w.proc.poll() is None:
                    w.enforced = False
                return
            # No memory lines: no task holds its address space any more (exiting). Over the bound
            # while dumping is still over: _end_worker waits for the dump, it never kills one.
            anon = _anon_bytes(status)
            if anon is None:
                return
            w.observed = anon
            if anon > limit:
                raise _OverMemory(anon)

        return sample

    def _call(self, name: str, args: dict[str, Any] | None) -> dict[str, Any]:
        # The deadline is taken FIRST: a previous worker's end is awaited within it, never on top.
        deadline = time.monotonic() + self.timeout
        while True:
            held = self._settle_previous(deadline)
            if held is not None:
                return held
            if (
                time.monotonic() >= deadline
            ):  # spent settling the previous worker: none starts
                return {
                    "error": f"{name} was not run: its {self.timeout:g} s went to settling the "
                    "previous worker",
                    "native_timeout": True,
                }
            if self._closing:
                return {
                    "error": f"the Session was closed while {name} waited to start",
                    "session_closed": True,
                }
            if self._w is None:
                self._start()
                # close() came while it started: it found no worker to end
                if self._closing:
                    self._stop()
                    return self._closed(name)
            w = self._w
            assert w is not None
            outcome = self._exchange(w, name, args, deadline)
            if outcome is not None:
                return outcome
            # It died before taking the request, after answering an earlier one: that death was the
            # earlier call's (now pending); this request never ran, so it runs on a fresh worker.

    def _exchange(
        self, w: _Worker, name: str, args: dict[str, Any] | None, deadline: float
    ) -> dict[str, Any] | None:
        """Ask ``w``; None when it died before taking the request it had no part in."""
        assert w.req is not None
        self._served = self._last = w
        prior, w.observed = w.observed, None
        sample = self._sampler(w)
        watch = _Watch(sample, w)
        at_start = None
        if sample is not None:
            status = w.space_status()
            at_start = None if status is None else _anon_bytes(status)
        acked = False
        try:
            if not w.ready:  # the worker's first frame says whether it opened the APK
                hello = self._read_frame(w, deadline, watch)
                if not isinstance(hello, dict) or _SESSION_KEYS & hello.keys():
                    return self._refused(name, deadline)
                hello = dict(hello)
                nonce = hello.pop("nonce", None)
                if isinstance(nonce, str) and nonce:
                    w.sink.nonce = nonce.encode("ascii", "replace")
                framework = hello.pop("framework", None)
                if isinstance(framework, str):
                    w.sink.add_path(os.fsencode(framework), b"<framework>")
                # it cannot open this file: its answer, on every call
                if "error" in hello:
                    # it returns after this frame: given time to, and not told
                    w.expected_exit = 0
                    self._stop(grace=_remaining_grace(deadline))
                    return dict(hello)
                w.ready = True
            _write_all(w.req, _frame([name, dict(args or {})]), deadline, watch)
            assert w.ans is not None
            if _read_exact(w.ans, 1, deadline, watch) != _ACK:
                return self._refused(name, deadline)
            acked = True
            answer = self._read_frame(w, deadline, watch)
        except _Deadline:
            return self._end_worker("deadline", name, deadline, acked=acked)
        except _OverMemory as over:
            return self._end_worker(
                "memory",
                name,
                deadline,
                acked=acked,
                observed=over.observed,
                at_start=at_start,
            )
        except (EOFError, BrokenPipeError, ConnectionResetError):
            # Only the pipe's own failures: a caller's TimeoutError is an OSError too, and catching
            # it lost the caller's interrupt and reported the Session's own kill (review).
            if not acked and w.after is not None:
                self._prev, self._w = w, None  # held before anything can interrupt
                w.during = None
                w.pipe_closed = True
                if w.observed is None:  # nothing sampled in this call: the last call's
                    w.observed = prior
                # settled, and told as after w.after, by the loop in _call
                return None
            return self._end_worker("died", name, deadline, acked=acked)
        if not isinstance(answer, dict) or _SESSION_KEYS & answer.keys():
            return self._refused(name, deadline)
        w.after = name
        # memory ran out in the worker: its state is unknown, so the next call starts afresh
        if answer.get("memory_exhausted"):
            self._stop()
        return answer

    def _settle_previous(self, deadline: float) -> dict[str, Any] | None:
        """Report a worker that ended (or is ending) outside a call; hold the call while it ends.

        Returns the answer for this call when a kept worker is still ending at the deadline (no new
        worker starts beside it), else None with its death, if it needs telling, in ``_pending``.
        """
        w = self._w
        if self._prev is None and w is not None and w.phase() != "live":
            self._prev, self._w = w, None
        prev = self._prev
        if prev is None:
            return None
        # A worker whose answer pipe closed is ending by itself: it gets the grace the in-call
        # "died" path gives (measured: an outside SIGKILL of a stopped worker read live for a
        # moment after the EOF, and a kill sent then made its death the Session's own).
        code, killed = self._settle(prev, deadline, grace=_grace(prev))
        if code is None:
            text, fields = self._kept(prev, killed)
            return {
                "error": f"the previous worker is still {text}; no new worker starts beside it "
                "— call again",
                **fields,
            }
        self._prev = None
        record = self._death(code, prev)
        if record is not None:
            self._pending.append(record)
        return None

    def _settle(
        self, w: _Worker, deadline: float, grace: float
    ) -> tuple[int | None, bool]:
        """Bring ``w`` to its end by ONE rule, THEN close its pipes; see _bring_to_end.

        The order is the rule: a live worker's pipes are never closed before it is killed or has
        ended (closing first handed it an EOF or EPIPE to exit on — an end the Session caused,
        read as the worker's own; measured).
        """
        try:
            return self._bring_to_end(w, deadline, grace)
        finally:
            w.close_pipes()

    def _bring_to_end(
        self, w: _Worker, deadline: float, grace: float
    ) -> tuple[int | None, bool]:
        """Bring ``w`` to its end; return (its exit status, whether this sent a kill).

        While it is ending (dumping / exiting) it is waited for up to ``deadline``; while live, up
        to ``grace`` s (within the deadline), then killed. A kill sent to a process that has already
        died does not change its status, so the status returned is always its own, read from wait.
        (None, False): still ending at the deadline — kept, never killed. (None, True): killed and
        not yet reaped — kept too, so the next call or close() reaps it.
        """
        settle = time.monotonic() + grace
        while True:
            code = w.proc.poll()
            if code is not None:
                return code, False
            phase = w.phase()
            now = time.monotonic()
            if phase in _ENDING:
                if now >= deadline:
                    return None, False
                time.sleep(min(_SLICE, deadline - now))
                continue
            until = min(deadline, settle)
            if now >= until:
                break
            time.sleep(min(_SLICE, until - now))
        # Live at the last read — which includes a worker whose dump has just finished and whose
        # memory is not yet dropped (measured: memory lines back, CoreDumping 0). A kill then
        # cannot change the status the fault already fixed: wait gives -11, and it is reported as
        # itself. Only a fault in the microseconds between the read and the kill, before the
        # kernel fixed a status, becomes the kill.
        w.killed = True
        w.proc.kill()
        try:
            # A killed process ends in milliseconds per GB it unmaps; this wait may run past the
            # deadline by that much. Only an uninterruptible one (a hung mount) outlasts it.
            return w.proc.wait(5), True
        except subprocess.TimeoutExpired:
            return None, True

    @staticmethod
    def _own_kill(w: _Worker, code: int) -> bool:
        """Whether ``code`` is the SIGKILL the Session itself sent ``w`` (and nothing else)."""
        return w.killed and code == -signal.SIGKILL

    def _death(self, code: int, w: _Worker) -> dict[str, Any] | None:
        """Record the raw end of a worker no call reported; a FAULT counts as the APK's crash.

        Only two ends are not told: the SIGKILL the Session sent, and the exit its protocol ends
        with (``expected_exit``). The worker's last words are read here, first. The FAULT
        attribution is a stated model: a fault outside a call is taken as a deferred teardown of
        APK-built state; an outside SIGSEGV would be misattributed the same way.
        """
        w.close()  # its last words into the sink before the record takes them
        if self._own_kill(w, code) or code == w.expected_exit:
            return None
        record = self._ended(code, w)
        record["after" if w.during is None else "during"] = (
            w.after if w.during is None else w.during
        )
        log = w.sink.take_call()
        if log is not None:
            record["aosp_log"] = log
        if steps := w.sink.news(ended=True):
            record["aosp_load_log"] = steps
        return record

    def _ended(self, code: int, w: _Worker) -> dict[str, Any]:
        """Classify an exit status the worker gave itself — the one classifier every path uses."""
        if code >= 0:
            return {"exit": code}
        sig = -code
        out: dict[str, Any] = {"signal": sig, "signal_name": _signal_name(sig)}
        if sig in _FAULTS:
            self.crashes += 1
            out["native_crash"] = True
        # an OOM kill names no cause; memory sampled during the call is a fact beside it
        if sig == signal.SIGKILL and w.observed is not None:
            out["memory_observed"] = w.observed
        if sig == signal.SIGXCPU and w.cpu_limit is not None:
            out["inherited_cpu_limit"] = w.cpu_limit
        return out

    @staticmethod
    def _kept(w: _Worker, killed: bool) -> tuple[str, dict[str, Any]]:
        """Say how a kept worker stands — text and fields from ONE phase read."""
        if killed:
            text, key = "not reaped after it was killed", "worker_unreaped"
        elif w.phase() == "dumping":
            text, key = "writing a core dump", "core_dumping"
        else:
            text, key = "exiting", "worker_exiting"
        return text, {key: True, "during" if w.during else "after": w.during or w.after}

    def _end_worker(
        self,
        why: str,
        name: str,
        deadline: float,
        *,
        acked: bool,
        observed: int | None = None,
        at_start: int | None = None,
    ) -> dict[str, Any]:
        """End the worker of call ``name`` and say why: the Session's reason, or its own death.

        ``why``: ``deadline`` (no answer in time), ``memory`` (past the bound), ``died`` (its pipe
        closed). The worker is kept in ``_prev`` before any wait, so an exception in the wait
        leaves it to the next call. Its own death (a FAULT before the bound or the deadline, any
        status the Session's kill does not explain) is reported as itself — as this call's when it
        had taken the request (``acked``), else as after the tool it last answered.
        """
        w = self._w
        assert w is not None
        taken = acked or w.after is None  # a fresh worker's start is this call's
        w.during = name if taken else None
        self._prev, self._w = w, None
        if why == "died":
            w.pipe_closed = True
        code, killed = self._settle(w, deadline, _grace(w))
        if code is None:  # kept in _prev: still ending, or killed and not reaped yet
            if not killed:
                text, fields = self._kept(w, killed)
                return {
                    "error": f"the worker is still {text} after {name}; it was not killed, and "
                    "its final status comes with the next answer as previous_worker_died",
                    **fields,
                }
        else:
            self._prev = None
            w.close()
            if w.closed and code == -signal.SIGKILL:
                return self._closed(name)
            if not self._own_kill(w, code):
                if taken:
                    return self._in_call(code, name, w)
                record = self._death(code, w)
                if record is not None:
                    self._pending.append(record)
        if why == "deadline":
            return {
                "error": f"{name} did not answer within {self.timeout:g} s (the worker's start "
                "and the APK's parse included) and its worker was ended",
                "native_timeout": True,
            }
        if why == "memory":
            return {
                "error": f"the worker passed {self.memory_limit} bytes of anonymous memory "
                f"during {name} (the worker's start and the APK's parse included); it was ended",
                "native_memory_bound": True,
                "memory_at_call_start": at_start,
                "memory_observed": observed,
            }
        return {
            "error": f"the worker closed its answer pipe during {name} but did not exit; "
            "it was ended",
            "worker_refused": True,
        }

    def _closed(self, name: str) -> dict[str, Any]:
        return {
            "error": f"the Session was closed during {name}",
            "session_closed": True,
        }

    def _in_call(self, code: int, name: str, w: _Worker) -> dict[str, Any]:
        """Answer a call whose worker ended by itself: what its exit status says, and no more."""
        facts = self._ended(code, w)
        if "exit" in facts:  # it EXITED: a Python-level end, not a native fault
            return {
                "error": f"the worker exited ({code}) on {name}",
                "worker_exit": code,
            }
        sig = facts["signal"]
        if facts.get("native_crash"):
            return {
                "error": f"the native core died ({_signal_name(sig)}) on {name} — the APK "
                "crashes AOSP's parser, itself a finding; the next call starts a fresh worker",
                "native_crash": True,
                "signal": sig,
            }
        out = {
            "error": f"the worker was killed ({_signal_name(sig)}) during {name}",
            "worker_killed": True,
            "signal": sig,
        }
        out.update(
            {
                k: v
                for k, v in facts.items()
                if k in ("memory_observed", "inherited_cpu_limit")
            }
        )
        return out

    def _read_frame(self, w: _Worker, deadline: float, watch: _Watch) -> Any:
        """One length-capped JSON frame from the worker; None when it is not a valid one."""
        assert w.ans is not None
        (size,) = _HEADER.unpack(_read_exact(w.ans, _HEADER.size, deadline, watch))
        if size > MAX_ANSWER_BYTES:
            return None
        body = _read_exact(w.ans, size, deadline, watch)
        try:
            return json.loads(body)
        except (
            ValueError,
            RecursionError,
        ):  # malformed, or nested to exhaust the decoder
            return None

    def _refused(self, name: str, deadline: float) -> dict[str, Any]:
        self._stop(during=name, grace=_remaining_grace(deadline))
        return {
            "error": f"the worker's answer to {name} was not a JSON object within "
            f"{MAX_ANSWER_BYTES} bytes carrying only a tool's keys; the worker is replaced",
            "worker_refused": True,
        }

    def close(self) -> None:
        """End the worker — at once, even while another thread waits on a call.

        An ending worker (dumping / exiting) is not killed: close() waits for it up to ``timeout``.
        Every end it settles that no answer told, and any death still undelivered, is recorded in
        ``last_worker_status`` (close() has no answer to carry them); a worker still ending past
        the wait is recorded as such and its handle dropped (the OS reaps it when this one exits).
        """
        self._closing = True
        try:
            w = self._w
            if w is not None and w.phase() == "live":
                w.killed = w.closed = True
                w.proc.kill()  # an in-flight call sees the death and returns; then clean up
            with self._lock:
                found: list[dict[str, Any]] = []
                deadline = time.monotonic() + self.timeout
                for kept in (self._prev, self._w):
                    if kept is None:
                        continue
                    code, killed = self._settle(kept, deadline, grace=_grace(kept))
                    if code is None:
                        found.append(
                            {"still_ending": True, **self._kept(kept, killed)[1]}
                        )
                    elif (record := self._death(code, kept)) is not None:
                        found.append(record)
                    kept.close()
                self._prev = self._w = None
                # undelivered deaths are taken only now: an interrupt in the wait above keeps them
                self.last_worker_status += self._pending + found
                self._pending = []
        finally:
            self._closing = False

    def __enter__(self) -> Session:
        """Use as a context manager: the worker ends on exit."""
        return self

    def __exit__(self, *exc: object) -> None:
        """End the worker."""
        self.close()


def _load(path: str) -> Any:
    module, _, name = path.partition(":")
    return getattr(importlib.import_module(module), name)


def _quiet_paths() -> None:
    """Keep file names out of the worker's own Python output (its fd 2 reaches an LLM as data).

    No traceback is printed (it names every source file on the stack: the host's install, the
    user's home). An uncaught exception, a thread's, an unraisable one are told by type and
    message — an OSError by its strerror and an ImportError by the module's name, whose messages
    name files; any other message is printed as written (the worker's own code puts no path in
    one). A warning is told by category and message. SIGINT is ignored: a terminal's Ctrl-C
    reaches the worker too, and the Session — not a KeyboardInterrupt traceback — ends it.
    """
    import threading
    import warnings

    def told(exc: BaseException | None) -> str:
        if exc is None:
            return "(none)"
        if isinstance(exc, OSError):
            return f"{type(exc).__name__}: {exc.strerror or ''}"
        if isinstance(exc, ImportError):
            return f"{type(exc).__name__}: {exc.name or ''}"
        return f"{type(exc).__name__}: {exc}"

    def excepthook(_t: Any, exc: BaseException, _tb: Any) -> None:
        sys.stderr.write(f"uncaught {told(exc)}\n")

    sys.excepthook = excepthook
    threading.excepthook = lambda a: sys.stderr.write(
        f"uncaught in a thread {told(a.exc_value)}\n"
    )
    sys.unraisablehook = lambda u: sys.stderr.write(f"unraisable {told(u.exc_value)}\n")

    def showwarning(
        message: Warning | str, category: type[Warning], *_a: Any, **_k: Any
    ) -> None:
        sys.stderr.write(f"warning {category.__name__}: {message}\n")

    warnings.showwarning = showwarning
    signal.signal(signal.SIGINT, signal.SIG_IGN)


def _serve(req_fd: int, ans_fd: int, apk_path: str, execute: str) -> None:
    """Child: open the manifest, say whether it did, then answer [name, args] requests."""
    from axmlllm import Manifest  # imported in the child only

    def read(n: int) -> bytes | None:
        buf = bytearray()
        while len(buf) < n:
            chunk = os.read(req_fd, n - len(buf))
            if not chunk:
                return None
            buf += chunk
        return bytes(buf)

    def recv() -> Any:
        head = read(_HEADER.size)
        if head is None:
            return None
        body = read(_HEADER.unpack(head)[0])
        if body is None:
            return None
        send(_ACK)  # taken: from here a death is this request's
        return json.loads(body)

    def send(data: bytes) -> None:
        while data:
            data = data[os.write(ans_fd, data) :]

    # Victim choice only: when the host runs out, the kernel's OOM killer takes this worker before
    # the caller. It does not protect the host — systemd's OOMPolicy=stop and systemd-oomd act on
    # the whole scope (measured) — the parent's memory bound firing first is what does.
    try:
        with open("/proc/self/oom_score_adj", "w") as f:
            f.write("1000")
    except OSError:
        pass
    # A nonce the Session learns from the hello frames below (the answer pipe, never fd 2): the
    # load-step markers carry it, so nothing else written to fd 2 can pose as one. New per worker.
    from axmlllm._axml_core import set_worker_log_mode
    from axmlllm.manifest.resources import discover_framework

    nonce = os.urandom(16).hex()
    set_worker_log_mode(nonce)
    framework = discover_framework()
    hello: dict[str, Any] = {"nonce": nonce}
    if framework is not None:
        hello["framework"] = (
            framework  # a host path the Session replaces in the logs it passes on
        )
    run = _load(execute)
    try:
        # AOSP prints the path it was given in its load errors, and a file name is the sample's
        # (any bytes but '/' and NUL — a newline in it forged lines inside AOSP's own text). So
        # AOSP is given a spelling with none of the sample's bytes: the descriptor of the file
        # this worker opened. One open, too: every later open reads this same file (with the
        # descriptor spellings; see _fixed_name for the fallback).
        fd = os.open(apk_path, os.O_RDONLY)
        # The Session decided (a directory in the environment means: no descriptor spelling on
        # this host); a worker run without a Session looks for itself.
        candidates = (
            ()
            if os.environ.get(_WORKER_DIR_ENV)
            else (f"/proc/self/fd/{fd}", f"/dev/fd/{fd}")
        )
        spelling = next((sp for sp in candidates if os.path.exists(sp)), None)
        if (
            spelling is None
        ):  # neither: a fixed name, in a private directory, that links to it
            spelling = _fixed_name(apk_path)
        manifest = Manifest.from_apk(spelling)
    except MemoryError:
        send(_frame({"error": "the worker ran out of memory opening the APK",
                     "memory_exhausted": True, **hello}))  # fmt: skip
        return
    except Exception as exc:  # noqa: BLE001 - not an APK / no such file: an answer
        # No path in the answer: the caller passed it, and a file name is the sample's (it could
        # forge text or inject control bytes into an answer an LLM reads). An OSError's str()
        # names the file: its strerror alone.
        reason = exc.strerror if isinstance(exc, OSError) and exc.strerror else exc
        send(
            _frame(
                {"error": f"{type(exc).__name__} opening the APK: {reason}", **hello}
            )
        )
        return
    send(_frame({"ready": True, **hello}))
    while (request := recv()) is not None:
        name, args = request
        # The answer is framed and dropped BEFORE it is sent, so what tearing it down does happens
        # inside this call, not after its answer (where it would look like the next call's).
        frame = _frame(run(name, args, manifest))
        send(frame)


def _remaining_grace(deadline: float) -> float:
    """_PIPE_CLOSED_GRACE, within what is left of the call's one deadline."""
    return min(_PIPE_CLOSED_GRACE, max(0.0, deadline - time.monotonic()))


def _grace(w: _Worker) -> float:
    """How long a live worker may take to end by itself before the Session ends it.

    One whose answer pipe closed is ending on its own account: waited for _PIPE_CLOSED_GRACE
    (an outside SIGKILL leaves it reading live until its memory is gone, and a kill sent then
    would make its death the Session's own — measured). Any other is ended at once.
    """
    return _PIPE_CLOSED_GRACE if w.pipe_closed else 0.0


def _fd_spellings() -> bool:
    """Whether this host names an open descriptor as a path (/proc/self/fd or /dev/fd)."""
    return os.path.isdir("/proc/self/fd") or os.path.isdir("/dev/fd")


def _fixed_name(apk_path: str) -> str:
    """Link the APK under a fixed name, ``apk``, in the private directory the Session made.

    For a host with neither /proc/self/fd nor /dev/fd: AOSP still gets no byte of the sample's
    name. A hard link pins the file at the path when it is linked; across file systems only a
    symbolic link can be made, and it resolves the path again on each open (a file swapped on
    disk is read).
    The Session made the directory and removes it when it settles the worker (it ends workers
    with SIGKILL, so the worker cannot); a worker run without one makes its own, removed at exit.
    """
    directory = os.environ.get(_WORKER_DIR_ENV)
    if not directory:
        import atexit
        import shutil
        import tempfile

        directory = tempfile.mkdtemp(prefix="axmlllm-worker-")
        atexit.register(shutil.rmtree, directory, True)
    link = os.path.join(directory, "apk")
    try:
        os.link(apk_path, link)
    except OSError:
        os.symlink(os.path.abspath(apk_path), link)
    return link


def _main() -> None:
    """Worker entry (see _BOOT): quiet the Python output, then serve."""
    _quiet_paths()
    _serve(int(sys.argv[1]), int(sys.argv[2]), sys.argv[3], sys.argv[4])


if __name__ == "__main__":
    _main()


__all__ = ["DEFAULT_MEMORY_LIMIT", "DEFAULT_TIMEOUT", "MAX_ANSWER_BYTES", "Session"]
