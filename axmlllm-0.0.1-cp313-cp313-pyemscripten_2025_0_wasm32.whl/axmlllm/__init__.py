"""axmlllm — LLM-facing Android binary-XML (AXML) + resources.arsc analyzer.

A pybind11 wrapper around **real AOSP libandroidfw** (``ResXMLTree`` / ``LoadedArsc`` /
``AssetManager2``), surfacing the parsed **data tree the device actually walks** — not a
regenerated XML (the apktool path malware defeats), and not a custom text render.

The native core (``_axml_core``) parses an APK's ``AndroidManifest.xml`` exactly as the
runtime does, preserving the string-name vs ResID dual identity and raw (unmasked)
``Res_value`` types — the signals string-based manifest tools miss. See
``docs/tree-schema.md`` for the emitted tree shape.

Destined to merge into ``dexllm`` as its manifest/resources half; module names mirror
dexllm so the merge is mechanical.
"""

from . import format, manifest, tools
from ._axml_core import parse_apk, parse_axml
from .manifest import Anomaly, Attribute, Element, Manifest, detect

__all__ = [
    "Anomaly",
    "Attribute",
    "Element",
    "Manifest",
    "detect",
    "format",
    "manifest",
    "parse_apk",
    "parse_axml",
    "tools",
]
__version__ = "0.0.1"
