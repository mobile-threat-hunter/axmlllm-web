"""Sparse JSON view + compact text summary of a parsed manifest.

The LLM-facing form is the **sparse data tree** (``docs/tree-schema.md``): emit a field only
when it carries signal, so anomaly-free attributes stay terse and the spoofing cases stand
out. A human-readable ``summary`` is provided as a secondary convenience (CLI/debug); the
LLM normally renders its own prose from the sparse JSON.

``key`` (the ResID-derived canonical name) and ``flags`` are added in milestone 3 once the
platform styleable→ResID tables are extracted; until then ``name`` + ``resid`` already
expose mismatches.
"""

from __future__ import annotations

from typing import Any

from .manifest.dispatch import Replay
from .manifest.model import Attribute, Element, Manifest

_REF_TYPES = ("reference", "dynamic_reference", "attribute", "dynamic_attribute")


def sparse_attr(a: Attribute) -> dict[str, Any]:
    """Render one attribute sparsely — fields appear only when non-trivial.

    ``key`` is the framework's ResID-derived name (what the device acts on); ``name`` is
    emitted only when the string-pool name disagrees — i.e. the spoof signal.
    """
    out: dict[str, Any] = {"key": a.key, "value": a.value}
    if a.name != a.key:
        out["name"] = a.name
    if a.resid is not None:
        out["resid"] = a.resid
    if a.type != "string":
        out["type"] = a.type
    if a.type in _REF_TYPES:
        out["raw"] = f"0x{a.raw:08x}"
    return out


def device_note(e: Element, replay: Replay | None) -> dict[str, Any]:
    """Say what the device's package parser does with ``e``, when a tree reader would not see it.

    Empty for an element read where it stands; else ``device`` says why it is not read, or where
    it is read from, and ``device_conditions`` the device facts it depends on.
    """
    if replay is None:
        return {}
    d = replay.of(e)
    if d is None:
        return {}
    out: dict[str, Any] = {}
    if d.outcome != "read":
        out["device"] = f"not read: {d.because or d.outcome.replace('_', ' ')}"
    elif d.effect is None and d.because:
        out["device"] = f"records nothing: {d.because}"
    elif replay.hidden(d):
        out["device"] = f"read: {replay.how_hidden(d)}"
    if d.conditions:
        out["device_conditions"] = list(d.conditions)
    return out


def sparse_element(e: Element, replay: Replay | None = None) -> dict[str, Any]:
    """Render one element subtree sparsely (omit empty attributes/children/text).

    With ``replay``, an element the device does not read where it stands says so (device_note).
    """
    out: dict[str, Any] = {"tag": e.tag, "line": e.line}
    out.update(device_note(e, replay))
    if e.ns:
        out["ns"] = e.ns
    if e.attributes:
        out["attributes"] = [sparse_attr(a) for a in e.attributes]
    if e.children:
        out["children"] = [sparse_element(c, replay) for c in e.children]
    if e.text:
        out["text"] = e.text
    if e.dropped_descendants:  # nested past the depth cap: present, not parsed here
        out["children_dropped"] = e.dropped_descendants
    return out


def sparse_tree(manifest: Manifest) -> dict[str, Any]:
    """Render the whole manifest as the sparse document for LLM consumption."""
    out: dict[str, Any] = {"format": "axml", "parse_status": manifest.parse_status}
    if manifest.package:
        out["package"] = manifest.package
    if manifest.dispatch.install_error is not None:
        out["install_error"] = manifest.dispatch.install_error
    if manifest.dispatch.conditional_install_error is not None:
        out["install_error_if"] = manifest.dispatch.conditional_install_error
    if manifest.root is not None:
        out["root"] = sparse_element(manifest.root, manifest.dispatch)
    return out


def summary(manifest: Manifest) -> str:
    """One-screen text summary (secondary; for CLI/debug, not the primary LLM surface)."""
    lines: list[str] = [f"package: {manifest.package or '(none)'}"]
    perms = manifest.permissions()
    lines.append(f"permissions: {len(perms)}")
    for p in perms:
        lines.append(f"  - {p}")
    comps = manifest.components()
    lines.append(f"components: {len(comps)}")
    for c in comps:
        name = c.attr("name")
        lines.append(
            f"  {c.tag} {name.value if name else '(unnamed)'}  // line {c.line}"
        )
    return "\n".join(lines)
