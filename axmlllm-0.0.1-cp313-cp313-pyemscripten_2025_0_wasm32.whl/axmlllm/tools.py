"""LLM-friendly tool surface over a parsed manifest.

Single source of truth for the manifest analysis tools exposed to an LLM — mirrors
dexllm's ``tools.py`` (JSON-Schema ``TOOL_DEFINITIONS`` + a pure ``execute(name, args,
manifest)`` dispatcher + pagination), so on merge these entries fold into dexllm's one
catalog and the shared MCP / FastAPI backends expose them alongside the dex tools.

The caller owns opening/caching the ``Manifest`` (keyed by ``apk_path`` at the transport
layer), exactly as dexllm passes a ``DexKit`` instance to ``execute``.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import os
import threading
from collections import OrderedDict
from contextvars import ContextVar
from dataclasses import fields, is_dataclass
from typing import Any, Callable

from . import format as _fmt
from ._axml_core import ZIP_ENTRY_NOT_FOUND
from .manifest import Manifest, ResourceTable, detect
from .manifest.anomalies import SEVERITIES
from .manifest.model import printable

DEFAULT_LIST_LIMIT = 100
MAX_LIST_LIMIT = 500


def _paginate(
    items: list[Any], offset: int = 0, limit: int = DEFAULT_LIST_LIMIT
) -> dict[str, Any]:
    """Build the standard list-response shape (clamped offset/limit, ``next_offset``)."""
    total = len(items)
    offset = max(0, min(int(offset), total))
    limit = max(1, min(int(limit), MAX_LIST_LIMIT))
    end = min(offset + limit, total)
    return {
        "total": total,
        "offset": offset,
        "limit": limit,
        "items": items[offset:end],
        "next_offset": end if end < total else None,
    }


def _t_analyze_manifest(manifest: Manifest) -> dict[str, Any]:
    return {
        "package": manifest.package,
        "parse_status": manifest.parse_status,
        # what the DEVICE requests / registers (the replayed dispatch), not the tree's count
        "permission_count": len(manifest.permissions()),
        "component_count": len(manifest.components()),
        **(
            {"install_error": manifest.dispatch.install_error}
            if manifest.dispatch.install_error is not None
            else {}
        ),
        **(
            {"install_error_if": manifest.dispatch.conditional_install_error}
            if manifest.dispatch.conditional_install_error is not None
            else {}
        ),
        **(
            {"flag_settings_not_run": manifest.dispatch.capped}
            if manifest.dispatch.capped is not None
            else {}
        ),
        "anomaly_count": len(detect(manifest)),
        "resources_status": manifest.resources_status,
        **_not_judged(manifest),
        **_dropped(manifest),
    }


def _not_judged(manifest: Manifest) -> dict[str, Any]:
    """Say when THIS host, not AOSP's verdict on the bytes, ended the table's own load."""
    load = getattr(manifest, "table_load", None)
    failure = None if load is None else load.failure
    if manifest.resources_status != "load_failed" or failure is None:
        return {}
    return (
        {}
        if failure.not_judged is None
        else {"resources_not_judged": failure.not_judged}
    )


def _dropped(manifest: Manifest) -> dict[str, Any]:
    """Stack members the best-effort policy left out, each with AOSP's reason (when any)."""
    load = getattr(
        manifest, "table_load", None
    )  # stub manifests in the tests carry none
    drops = [] if load is None else load.dropped
    if not drops:
        return {}
    return {
        "stack_dropped": [
            {"role": d.role, "cause": d.cause}
            # the host's refusal, when it was the host's: not AOSP's verdict on the member
            | ({"not_judged": d.not_judged} if d.not_judged is not None else {})
            for d in drops
        ]
    }


def _t_list_permissions(
    manifest: Manifest, offset: int = 0, limit: int = DEFAULT_LIST_LIMIT
) -> dict[str, Any]:
    return _paginate(manifest.permission_entries(), offset, limit)


def _t_list_components(
    manifest: Manifest, offset: int = 0, limit: int = DEFAULT_LIST_LIMIT
) -> dict[str, Any]:
    return _paginate(manifest.component_entries(), offset, limit)


_SEVERITY_ORDER = {s: i for i, s in enumerate(SEVERITIES)}


def _t_manifest_anomalies(
    manifest: Manifest, offset: int = 0, limit: int = DEFAULT_LIST_LIMIT
) -> dict[str, Any]:
    """List findings high severity first, paged.

    A response bound that dropped the tail of one unpaged list let a flood of early findings push
    later ones out of reach (review).
    """
    found = sorted(
        (_public(a) for a in detect(manifest)),
        key=lambda a: _SEVERITY_ORDER.get(a.get("severity", ""), len(_SEVERITY_ORDER)),
    )
    page = _paginate([_clip_all(a) for a in found], offset, limit)
    shown, capped = _within_budget(page["items"], 0)
    end = page["offset"] + len(shown)
    by_kind: dict[str, int] = {}
    for a in found:
        by_kind[a["kind"]] = by_kind.get(a["kind"], 0) + 1
    return {
        "total": page["total"],
        # every kind and its count, whatever the page: a flood of one kind cannot hide another
        "by_kind": by_kind,
        "offset": page["offset"],
        "anomalies": shown,
        "next_offset": end if end < page["total"] else None,
        **({"response_capped": True} if capped else {}),
    }


def _steps(path: Any) -> list[int] | None:
    """Parse a path of child indices: a list of ints, or (accepted too) a '/'-joined string."""
    if isinstance(path, str):
        parts = [x for x in path.split("/") if x]
        if not all(x.isascii() and x.isdigit() for x in parts):
            return None
        return [int(x) for x in parts]
    if isinstance(path, (list, tuple)) and all(
        isinstance(x, int) and not isinstance(x, bool) and x >= 0 for x in path
    ):
        return list(path)
    return None


def _node_at(manifest: Manifest, steps: list[int]) -> tuple[Any, str | None]:
    """Find the element at `steps` ([] the root; [3, 12] child 12 of the root's child 3)."""
    node = manifest.root
    for k, step in enumerate(steps):
        if node is None or step >= len(node.children):
            return None, f"no child {step} at path {steps[:k]}"
        node = node.children[step]
    return node, None


def _t_get_manifest_tree(
    manifest: Manifest,
    path: Any = (),
    offset: int = 0,
    limit: int = DEFAULT_LIST_LIMIT,
    attributes_offset: int = 0,
) -> dict[str, Any]:
    """Render the sparse tree — whole when it fits, otherwise navigable, never cut.

    A response bound that halves the largest list and keeps its head lets whoever orders the
    manifest choose what is dropped: padding before <application> removed every component from
    the only tree view, and a deep chain of unknown elements blanked it (review). So a subtree
    that does not fit is returned one level at a time: the node, its attributes paged from
    `attributes_offset`, and its children as summaries paged from `offset`, each with the `path`
    that opens it. Nothing is dropped; everything is reachable.
    """
    tree = _fmt.sparse_tree(manifest)
    # A path is a LIST of child indices: no string the bound could cut. As text it was clipped at
    # 300 characters past ~150 levels, and following the returned path looped forever (audit).
    steps = _steps(path)
    if steps is None:
        return {"error": f"path must be a list of child indices, got {path!r}"}
    path = steps
    if not path and _size(_clip_all(tree)) <= RESPONSE_BYTES:
        return tree
    node, error = _node_at(manifest, steps)
    if error is not None:
        return {"error": error}
    if node is None:  # no root: the header is all there is
        return tree
    whole = _clip_all(_fmt.sparse_element(node, manifest.dispatch))
    header = {k: v for k, v in tree.items() if k != "root"} if not path else {}
    if _size(whole) <= RESPONSE_BYTES:
        return {**header, "path": path, "node": whole, "legend": _TREE_LEGEND_PATH}
    head = {k: v for k, v in whole.items() if k not in ("attributes", "children")}
    attrs = whole.get("attributes", [])
    a_off = max(0, min(int(attributes_offset), len(attrs)))
    a_shown, _ = _within_budget(attrs[a_off:], 0, RESPONSE_BYTES // 4)
    a_end = a_off + len(a_shown)
    children = whole.get("children", [])
    total = len(children)
    c_off = max(0, min(int(offset), total))
    summaries = []
    for i, child in enumerate(
        children[c_off : c_off + max(1, min(int(limit), MAX_LIST_LIMIT))]
    ):
        summary = {
            k: v for k, v in child.items() if k not in ("attributes", "children")
        }
        summary["path"] = [*steps, c_off + i]
        summary["children_count"] = len(child.get("children", []))
        child_attrs = child.get("attributes", [])
        if _size(child_attrs) <= 2048:
            summary["attributes"] = child_attrs
        else:
            summary["attributes_count"] = len(child_attrs)
        summaries.append(summary)
    out: dict[str, Any] = {
        "path": path,
        "node": {**head, "attributes": a_shown, "attributes_count": len(attrs)},
        "offset": c_off,
        "total": total,
    }
    if a_end < len(attrs):
        out["attributes_next_offset"] = a_end
    out = header | out
    out["children"], capped = _within_budget(summaries, _size(out))
    end = c_off + len(out["children"])
    out["next_offset"] = end if end < total else None
    if capped:
        out["response_capped"] = True
    out["legend"] = _TREE_LEGEND_PAGED
    return out


_TREE_LEGEND_PATH = {
    "path": "child indices from the root ([] is the root); pass it back as `path`",
    "node": "the element at `path`, whole",
    "children_dropped": "elements nested below this one past the depth this tool parses — "
    "present, readable by the app, shown by no tool (see the depth_capped anomaly)",
}
_TREE_LEGEND_PAGED = {
    **_TREE_LEGEND_PATH,
    "node": "the element at `path`; its attributes are paged (attributes_next_offset) and its "
    "children listed one level deep under `children`",
    "children": "the node's children as summaries, paged from `offset` (`total` of them); "
    "open one by passing its `path`",
    "children_count": "how many children that element has — open it by its path to see them",
    "attributes_count": "how many attributes the element has (a summary omits them when large: "
    "open it by its path)",
    "attributes_next_offset": "pass as attributes_offset for the node's next attributes",
    "response_capped": "the response hit its byte budget; continue from next_offset",
}


def _no_table_error(manifest: Manifest) -> dict[str, Any]:
    """Build the specific 'no resource table' error, distinguishing absent from tampered.

    ``resources_status`` separates a legitimately resource-free APK (``absent``) from a
    ``resources.arsc`` that is present but was rejected on load (``load_failed`` — a tamper
    signal), instead of the old catch-all that lumped both together.
    """
    status = manifest.resources_status
    entry = manifest.arsc_entry
    if status == "load_failed":
        load = manifest.table_load
        failure = load.failure
        not_here = failure.not_judged if failure is not None else None
        return {
            "error": (
                f"resources.arsc was not judged on this host: {not_here}"
                if not_here is not None
                else "resources.arsc is listed but AOSP's loader produced no table from it — this "
                "is itself a triage signal"
            ),
            "resources_status": status,
            "detail": manifest.resources_error,
            "arsc_entry": entry,
            "arsc_inflate": load.inflate,
        }
    if status == "arsc_unopenable":
        return {
            "error": "the APK did not reopen for the resources.arsc lookup — nothing is known "
            "about its table",
            "resources_status": status,
            "arsc_entry": entry,
        }
    if entry is None:
        return {
            "error": "no resources.arsc to resolve against (no APK: parsed from raw AXML)",
            "resources_status": status,
        }
    return {
        "error": "no resource table loaded for this APK",
        "resources_status": status,
        "arsc_entry": entry,
    }


def _t_resolve_resource(manifest: Manifest, res_id: str) -> dict[str, Any]:
    table = manifest.resources
    if table is None:
        return _no_table_error(manifest)
    resolution = table.resolve(res_id)
    if resolution is not None:
        return _public(resolution)
    # A scalar None can mean absent OR a bag (complex/map entry) — tell them apart so the LLM knows
    # to call resolve_bag_resource instead of treating a string-array / style as unresolved (#6).
    bag = table.resolve_bag(res_id)
    if bag is not None:
        out: dict[str, Any] = {
            "resolved": None,
            "is_bag": True,
            "entry_count": bag.entry_count,
            "hint": "complex (bag) resource — call resolve_bag_resource for its entries",
        }
        if bag.parent_cycle:  # the same fact the unbuildable branch reports (#15)
            out["parent_cycle"] = True
        if bag.refused:  # an empty record we produced, not a bag AOSP built empty
            out["refused"] = bag.refused
            out["hint"] = (
                "complex (bag) resource this tool declined to build — see `refused`; its entries "
                "are unknown, not empty"
            )
        return out
    return {"resolved": None, **_bag_shape(table, res_id)}


def _bag_shape(table: ResourceTable, res_id: str) -> dict[str, Any]:
    """Say what an id IS when AOSP could not build its bag — never claim "scalar or absent".

    ``resolve_bag`` returning None conflates three different answers, because ``GetBag`` recurses
    into the parent and propagates its failure: a real scalar, an absent id, and a perfectly
    ordinary bag whose parent chain cannot be walked right now. The last is not exotic — a
    ``<style parent="@android:style/Theme">`` is the shape of nearly every app's theme, and the
    framework table is absent whenever the analyst has no SDK installed. Reporting that to an LLM
    as "scalar or absent" is the same false conclusion the ``ref_cycle`` detector was fixed to stop
    drawing, so answer from the entry's structure instead.
    """
    complex_entry = table.entry_is_complex(res_id)
    if complex_entry is True:
        if table.bag_parent_cycle(res_id):
            # #15: the chain loops. AOSP refused it when asked first, but a device that inflated
            # another member of the loop first holds a parent-less copy and renders a bag.
            return {
                "is_bag": True,
                "parent_cycle": True,
                "hint": "a complex (bag) resource whose parent chain loops back on itself — AOSP "
                "cannot build it when this id is asked first, but on a device the result depends "
                "on which bag in the loop was inflated first",
            }
        return {
            "is_bag": True,
            "hint": "a complex (bag) resource whose parent chain could not be resolved — the "
            "entry exists; a parent may live in a framework/split table that is not loaded",
        }
    if complex_entry is False:
        return {"is_bag": False, "hint": "a scalar entry — use resolve_resource"}
    return {
        "is_bag": None,
        "declared": table.declared(res_id),
        "hint": "the id resolves to nothing here; `declared` says whether the table reserves a "
        "slot for it at all",
    }


def _t_resolve_bag_resource(
    manifest: Manifest, res_id: str, entries_offset: int = 0
) -> dict[str, Any]:
    table = manifest.resources
    if table is None:
        return _no_table_error(manifest)
    bag = table.resolve_bag(res_id)
    if bag is None:
        return {"resolved": None, **_bag_shape(table, res_id)}
    out = _public(bag)
    out["entries"], out["entries_offset"], out["entries_next_offset"] = _page_of(
        out["entries"], entries_offset
    )
    return out


def _page_of(items: list[Any], offset: int) -> tuple[list[Any], int, int | None]:
    """Cut a byte-budgeted page of `items` from `offset`.

    An APK author sizes these lists and orders them, so a cut must leave the rest reachable,
    never drop the tail (review).
    """
    off = max(0, min(int(offset), len(items)))
    shown, _ = _within_budget([_clip_all(x) for x in items[off:]], 0)
    end = off + len(shown)
    return shown, off, end if end < len(items) else None


def _t_resource_config_variants(
    manifest: Manifest, res_id: str, offset: int = 0
) -> dict[str, Any]:
    table = manifest.resources
    if table is None:
        return _no_table_error(manifest)
    report = table.config_variants_report(res_id)
    variants = report["variants"]
    # over EVERY variant, before paging: the page is what is shown, not what is decided on
    distinct = {str(v.get("value")) for v in variants}
    page, off, nxt = _page_of(variants, offset)
    return {
        "res_id": res_id,
        "total": len(variants),
        "offset": off,
        "variants": page,
        "next_offset": nxt,
        "distinct_values": len(distinct),
        "diverges": len(distinct) > 1,
        "truncated": report["truncated"],
    }


# Resource-table tools hand the LLM rows and strings an APK author controls, so their output is
# bounded here, three ways:
#   * a page is at most MAX_RESOURCE_LIMIT rows;
#   * EVERY string longer than VALUE_CLIP_CHARS is cut, wherever it sits — value, entry_name,
#     type_name, inside a hit's entries — and never silently: `<field>_chars` gives its length and
#     `<field>_clipped` is set. Review put a 32,000-char entry name behind 200 aliased slots and
#     got 6.4 MB from one call while only `value` was cut;
#   * the whole response stops at RESPONSE_BYTES: rows (or hits) past it are left for the next
#     page and `response_capped` says so.
# Rows drop flags that are false and fields that are None (absence means false, or "none").
# Every key that can appear is defined in FIELD_LEGEND, and each response carries the meanings of
# the non-basic keys it actually holds, so the model never meets an undefined field —
# tests/test_resource_tools.py fails if an engine dataclass grows a field with no legend.
DEFAULT_RESOURCE_LIMIT = 50
MAX_RESOURCE_LIMIT = 200
VALUE_CLIP_CHARS = 300
RESPONSE_BYTES = 128 * 1024  # about: items are measured, not separators or the legend
HIT_ENTRY_BYTES = 16 * 1024  # one search hit's list of holding entries
# The HARD bound, enforced at execute() on every tool's whole response, legend included. The tools
# page against RESPONSE_BYTES; this is the margin their own measuring leaves out.
HARD_RESPONSE_BYTES = RESPONSE_BYTES + 32 * 1024
_ALWAYS = frozenset({"id", "value_type", "value"})
_ZERO_IS_ABSENT = frozenset({"contending_packages"})
# Not cut at VALUE_CLIP_CHARS: a local path; the caller's own needle.
_NEVER_CLIP = frozenset({"pattern"})
# read_string hands a string over as `pieces` of VALUE_CLIP_CHARS each: nothing to cut by
# construction, where a name-keyed exemption for one long field passed any field of that name
# (audit).
READ_PIECES = 14
READ_CHARS = READ_PIECES * VALUE_CLIP_CHARS

# Keys every response of these tools explains in its tool description; everything else that
# appears is explained in the response's own `legend`.
BASIC_FIELDS = frozenset(
    {"id", "type_name", "entry_name", "config", "value_type", "value", "rows", "hits", "entries",
     "total", "offset", "next_offset", "name", "hint", "error", "legend", "default_package",
     "pattern", "source_role", "is_bag"}
)  # fmt: skip

FIELD_LEGEND: dict[str, str] = {
    # rows (ResourceEntry) and entries of a hit (EntryRef)
    "package_id": "runtime package id: the id a static package declares (127 = 0x7f, the usual "
    "app id; 1 the framework), or for a shared library the one AOSP assigns, counting up from 2",
    "served_on": "a device configuration AOSP serves this definition on (a device always "
    "has an sdk, so a device with nothing else set reads 'v1')",
    "unserved": "no configuration the stock framework hands AssetManager picks this definition "
    "— see unserved_reason",
    "app_served_on": "an app-built configuration (AssetManager.setConfiguration, reachable by "
    "reflection) on which AOSP serves this definition although no device is: data only the app's "
    "own code reads; confirmed by the real AssetManager2 (absent proves nothing)",
    "app_device": "app_served_on's configuration as ResTable_config bytes (hex) — exact where "
    "the app_served_on text is lossy (a gender value past 3, a uiMode type)",
    "app_unasked": "the app question was not answered for this row (the page's or the row's "
    "budget for it, a cut candidate list, a locale no tag spells, a find AOSP refuted): no "
    "app_served_on here means not asked",
    "zero_request_unasked": "whether the all-zero request picks this always_outranked row could not "
    "be proved (its configuration bytes have a twin AOSP's answer may be): zero_request_only was "
    "not ruled out",
    "unserved_reason": "never_matches: no stock device presents the config (a decoy's shape, or a "
    "legacy qualifier nothing assigns: square/stylus/12key/wheel/navhidden; see app_served_on); "
    "always_outranked: another definition always wins, and the all-zero request does not pick it "
    "either (another wins there, or none matches) — usually a build artefact; zero_request_only: outranked on every configuration the stock framework hands "
    "AssetManager, but picked on the all-zero request (sdk 0) a never-configured AssetManager "
    "answers — e.g. idmap2 reading the xml an overlay's android:resourcesMap names, over that one "
    "APK — or an app's own raw setConfiguration (see app_served_on); "
    "not_consulted: AOSP never considers it; unreadable_entry: AOSP fails the lookup instead",
    "selection_capped": "the selection budget ran out before this row was judged",
    "contending_packages": "how many packages define this same id (more than one: shared id)",
    "contention": "every kind that holds, '+'-joined — dynamic_package: a shared library landed "
    "on this id (ballast shape); "
    "same_element: one APK defines it twice; cross_element: different APKs — in an analysed APK, "
    "the app claiming another APK's id (e.g. the framework's 0x01), raised as a finding",
    "dynamic_package": "stored package byte differs from the runtime id (a shared library)",
    "name_omitted": "the entry name was not emitted (name budget); the entry still exists",
    "enumerated_id": "the id under the other type-id convention — they differ, so `id` may not "
    "resolve (typeIdOffset)",
    "type_id_offset": "the package's typeIdOffset (non-zero: ids may not round-trip)",
    "unreadable": "the bytes claim an entry AOSP's verifier refuses",
    "unverified": "a trailing value the verifier does not size-check — reported, not read",
    "value_omitted": "a stored string value the page byte budget refused (omitted, not cut)",
    "out_of_pool": "the value's string index is one no reader, the device included, can fetch",
    "no_value_pool": "the table has no usable value string pool",
    "unmapped_reference": "a reference AOSP's DynamicRefTable could not map; value is the "
    "build-time id the device reads too",
    "value_undecodable": "the value's bytes are in the pool but are not text",
    "null_empty": "value is @empty (explicit nothing), not @null",
    "arsc_entry": "the device loads no table from this APK: this APK's element of the stack is "
    "the EMPTY table AOSP loads in its place. AOSP's own resources.arsc lookup {stage, code, "
    f"message}} (code {ZIP_ENTRY_NOT_FOUND}: no entry listed; any other code: listed, refused by "
    "AOSP's archive reader — a table only other zip tools decode)",
    # page summary (EntryPage)
    "cookie": "stack element index the rows come from",
    "packages": "packages in that table",
    "table_present": "the APK has a resources.arsc",
    "scan_capped": "the walk hit its budget: total is a floor and rows may be missing",
    "rows_capped": "the native page row cap cut this page",
    "unwalked_chunks": "type chunks the walk could not read",
    "unwalked_chunk_entries": "entries in those chunks",
    "names_omitted": "rows whose entry name was omitted",
    "names_undecodable": "rows whose entry name is not text",
    "values_omitted": "rows whose value the byte budget omitted",
    "out_of_pool_values": "rows whose value index no reader can fetch",
    "values_undecodable": "rows whose value bytes are not text",
    "value_pool_present": "the table has a usable value string pool",
    "unserved_rows": "rows with unserved set",
    "selection_capped_rows": "rows with selection_capped set",
    "contended_rows": "rows with contending_packages set",
    "response_capped": "the response hit its byte budget; continue from next_offset (or narrow "
    "the search)",
    "refused": "entry_offsets: this name lookup was refused because the entries AOSP's lookup "
    "would read for it lie outside their chunk (it checks none of them) — a hostile-table signal",
    "match_at": "where the match starts in the full (uncut) value",
    "value_offset": "where the shown slice of a cut value starts in the full value",
    # search (StringSearch, StringHit, PoolRead, PoolGap, EntryScan)
    "pool_index": "index of the string in the value pool",
    "device_truncated": "the app reads only a prefix of this string (embedded NUL)",
    "device_truncates_at": "where the app's copy stops",
    "undecodable": "the string's bytes are not valid text (shown with replacement characters)",
    "entries_total": "how many entries store this string",
    "entries_truncated": "entries lists only some of them — not every holder is shown",
    "hits_truncated": "more hits exist than were returned",
    "read": "string pools that were searched",
    "unread": "pools or slots NOT searched — zero hits proves nothing about these",
    "scans": "the entry walk behind `entries`, per pool, with its own coverage",
    "values": "how many strings the pool holds (or were not read)",
    "encoding": "the pool's encoding",
    "reason": "why it was not read",
    "kind": "class of the gap (e.g. out_of_scope, unreadable)",
    "indices": "pool indices not read",
    "indices_truncated": "indices lists only some of them",
    "values_unknown": "how many were not read cannot be told",
    "chunk_bytes": "size of an ignored pool chunk",
    "scanned_entries": "entries the walk visited",
    "string_entries": "of those, storing a string",
    "complex_entries": "of those, bags",
    "unreadable_entries": "of those, unreadable",
    "unverified_values": "of those, with an unverified value",
    "store_capped": "the walk kept only some holders per string",
    "ignored_chunks": "pool chunks the runtime never loads (exact, even when unread lists fewer)",
    "pieces": f"the string from `offset`, in order, {VALUE_CLIP_CHARS} characters a piece — "
    "join them",
    "length": "the whole string's length in characters",
    "strings_cut": "strings inside lists that were cut — see the mark at each one's end",
    "bytes_in_ignored_chunks": "their measured size in bytes",
    "values_in_ignored_chunks": "how many values they claim to hold",
}


class _CutStore:
    """The whole of every string a response cut, for ``read_string`` — one per Manifest.

    A cut string gets a ``ref`` beside the cut, and every cut is readable this one way, whatever
    produced it — a value, a tag, an attribute name, a bag item, a variant — where locating each
    source by its own address (a tree path, a pool index, ...) missed every source not handled
    (review).

    A ref is a 128-bit MAC under a secret of this store: the APK author writes the strings, and a
    public hash let them plant a decoy's ref in a fake cut mark, or search for two strings sharing
    one (review). Without the key there is nothing to search with.

    Only what a response SHOWS is stored, when the call returns: a cut gets its ref as it is made,
    but tools cut whole subtrees and lists to measure and page them, and storing at the cut stored
    every hidden string too — 20,000 for a page that showed 77, each insertion paying for an
    eviction scan (review: quadratic, 12 s at 40,000 strings). Bounded: past MAX_STORE_CHARS the
    least recently shown go first, never one the response being returned shows — so the store
    passes the bound only by the latest response's own strings; an evicted ref says so.
    """

    MAX_STORE_CHARS = 64 * 1024 * 1024

    def __init__(self) -> None:
        self._by_ref: OrderedDict[str, str] = OrderedDict()
        self._chars = 0
        self._key = os.urandom(32)
        self._lock = (
            threading.Lock()
        )  # a server may run calls on one Manifest from threads

    def ref_for(self, text: str) -> str:
        mac = hmac.new(self._key, text.encode("utf-8", "surrogatepass"), hashlib.sha256)
        return "s" + mac.hexdigest()[:32]

    def keep(self, shown: dict[str, str]) -> None:
        """Store the strings a response shows (by ref), evicting the least recently shown others.

        A response that shows none evicts none: a read_string between two reads of a big
        response's refs dropped them all.
        """
        if not shown:
            return
        with self._lock:
            for ref, text in shown.items():
                if ref in self._by_ref:
                    self._by_ref.move_to_end(ref)
                else:
                    self._by_ref[ref] = text
                    self._chars += len(text)
            while self._chars > self.MAX_STORE_CHARS:
                ref = next(iter(self._by_ref))
                if ref in shown:  # all that is left was just shown
                    break
                self._chars -= len(self._by_ref.pop(ref))

    def get(self, ref: str) -> str | None:
        with self._lock:  # a string being read is in use: it goes last (review)
            text = self._by_ref.get(ref)
            if text is not None:
                self._by_ref.move_to_end(ref)
            return text


class _Call:
    """The cuts one execute() call made: every ref it gave out, and the list strings it cut."""

    def __init__(self, store: _CutStore) -> None:
        self.store = store
        self.texts: dict[str, str] = {}  # ref -> the whole string
        # id of a list string _clip_bare made -> (that string, its ref). The string is held here so
        # its id cannot be reused by another while the call lasts (review: it relied on _CUTS).
        self.bare: dict[int, tuple[str, str]] = {}

    def shown(self, out: Any) -> dict[str, str]:
        """Collect the refs `out` carries — beside a cut field, or in the mark of a cut list string."""
        found: dict[str, str] = {}

        def walk(obj: Any) -> None:
            if isinstance(obj, dict):
                for k, v in obj.items():
                    if (
                        k.endswith("_cut_ref")
                        and isinstance(v, str)
                        and v in self.texts
                    ):
                        found[v] = self.texts[v]
                    walk(v)
            elif isinstance(obj, list):
                for x in obj:
                    entry = self.bare.get(id(x))
                    if entry is not None:
                        found[entry[1]] = self.texts[entry[1]]
                    walk(x)

        walk(out)
        return found


# The current execute() call (None outside execute()).
_CALL: ContextVar[_Call | None] = ContextVar("_CALL", default=None)


def _remember(text: str) -> str | None:
    call = _CALL.get()
    if call is None:
        return None
    ref = call.store.ref_for(text)
    call.texts[ref] = text
    return ref


def _clip_all(obj: Any) -> Any:
    """Cut every over-long string in `obj`, recursively, marking each cut and its ref beside it."""
    if isinstance(obj, dict):
        out: dict[str, Any] = {}
        for k, v in obj.items():
            if (
                isinstance(v, str)
                and len(v) > VALUE_CLIP_CHARS
                and k not in _NEVER_CLIP
            ):
                out[k] = v[:VALUE_CLIP_CHARS]
                out[f"{k}_chars"] = len(v)
                out[f"{k}_clipped"] = True
                ref = _remember(v)
                if ref is not None:
                    out[f"{k}_cut_ref"] = ref
            else:
                out[k] = _clip_all(v)
        return out
    # tuples too: asdict keeps a dataclass's tuple fields as tuples, and the strings inside them
    # (a search's `unread` reasons, an entry's names) went out uncut
    if isinstance(obj, (list, tuple)):
        return [_clip_bare(x) if isinstance(x, str) else _clip_all(x) for x in obj]
    return obj


_CUT_SUFFIX = "…(cut: {} chars{})"
# The strings _clip_bare made during ONE execute() call, kept so the response can count those it
# still holds by IDENTITY: re-detecting the mark counted a stored string that merely ends like one
# (review), and counting at cut time counted strings a later shrink dropped.
_CUTS: ContextVar[list[str] | None] = ContextVar("_CUTS", default=None)


def _clip_bare(v: str) -> str:
    """Cut a string that sits in a list — no key to mark it beside, so the mark is its own tail.

    The mark carries the ref (``…(cut: N chars, ref s…)``). The result is at most VALUE_CLIP_CHARS
    long, mark included, so cutting again changes nothing — by LENGTH alone: a string that merely
    ends like a mark is cut like any other.
    """
    if len(v) <= VALUE_CLIP_CHARS:
        return v
    ref = _remember(v)
    mark = _CUT_SUFFIX.format(len(v), f", ref {ref}" if ref else "")
    cut = v[: VALUE_CLIP_CHARS - len(mark)] + mark
    made = _CUTS.get()
    if made is not None:  # outside execute() nothing counts them
        made.append(cut)
    call = _CALL.get()
    if call is not None and ref is not None:
        call.bare[id(cut)] = (cut, ref)
    return cut


def _window(hit: dict[str, Any]) -> dict[str, Any]:
    """Show a long hit around its match, not its head.

    Review found 72 of 200 framework hits whose first 300 chars did not contain the needle at all.
    `match_at` is where the match starts in the full value — the ENGINE's, found by the fold the
    search matched with (a second derivation here could only disagree with it); `value_offset`
    where the shown slice starts.
    """
    value = hit.get("value")
    if not isinstance(value, str) or len(value) <= VALUE_CLIP_CHARS:
        return hit
    at = hit.get("match_at", -1)
    if (
        not isinstance(at, int) or at < 0
    ):  # no position: show the head, still marked as cut
        return hit
    start = max(0, min(at - VALUE_CLIP_CHARS // 3, len(value) - VALUE_CLIP_CHARS))
    hit["value"] = value[start : start + VALUE_CLIP_CHARS]
    hit["value_chars"] = len(value)
    hit["value_clipped"] = True
    ref = _remember(value)
    if ref is not None:
        hit["value_cut_ref"] = ref
    hit["value_offset"] = start
    hit["match_at"] = at
    return hit


def _compact(row: dict[str, Any]) -> dict[str, Any]:
    return {
        k: v
        for k, v in row.items()
        if k in _ALWAYS
        or not (
            v is False
            or v is None
            or (v == 0 and k in _ZERO_IS_ABSENT and v is not True)
        )
    }


def _limit(limit: int) -> int:
    return max(1, min(int(limit), MAX_RESOURCE_LIMIT))


def _keys(obj: Any) -> set[str]:
    if isinstance(obj, dict):
        return set(obj) | {k for v in obj.values() for k in _keys(v)}
    if isinstance(obj, list):
        return {k for v in obj for k in _keys(v)}
    return set()


def _with_legend(out: dict[str, Any]) -> dict[str, Any]:
    out = _clip_all(out)
    legend = _legend_for(out)
    if legend:
        out["legend"] = legend
    return out


_CUT_MARKERS = ("_chars", "_clipped", "_cut_ref")


def _cut_marker_legend(k: str) -> str:
    """Explain a key _clip_all puts beside a cut field."""
    if k.endswith("_chars"):
        return f"original length of {k[:-6]}, which was cut to {VALUE_CLIP_CHARS} chars"
    if k.endswith("_clipped"):
        return f"{k[:-8]} was cut; see {k[:-8]}_chars"
    return f"pass to read_string as `ref` to read the whole {k[:-8]}"


def _legend_for(
    out: dict[str, Any], extra: dict[str, str] | None = None
) -> dict[str, str]:
    legend = {}
    for k in sorted(_keys(out) - BASIC_FIELDS):
        if extra and k in extra:  # markers a _shrink added
            legend[k] = extra[k]
        elif k.endswith(_CUT_MARKERS):
            legend[k] = _cut_marker_legend(k)
        else:
            legend[k] = FIELD_LEGEND[k]
    return legend


def _within_budget(
    items: list[dict[str, Any]], spent: int, budget: int | None = None
) -> tuple[list[dict[str, Any]], bool]:
    """Keep items while the serialised total stays under `budget` (RESPONSE_BYTES by default).

    Always keeps at least one, and measures items, not separators or the legend added after — so
    the response is ABOUT the budget, not a hard limit.
    """
    limit = RESPONSE_BYTES if budget is None else budget
    kept: list[dict[str, Any]] = []
    for item in items:
        spent += len(json.dumps(item, default=str))
        if kept and spent > limit:
            return kept, True
        kept.append(item)
    return kept, False


def _t_resource_id_for(
    manifest: Manifest, name: str, default_type: str = ""
) -> dict[str, Any]:
    table = manifest.resources
    if table is None:
        return _no_table_error(manifest)
    package = manifest.package or ""
    try:
        found = table.resource_id_for(
            name, default_type=default_type, default_package=package
        )
    except (
        RuntimeError
    ) as exc:  # the table fails the pre-flight entry check — see the binding
        return _with_legend(
            {
                "name": name,
                "id": None,
                "refused": "entry_offsets",
                "hint": f"{exc}. Other names, resolve_resource and list_resources still work on "
                "this table; an entry placed outside its chunk is a hostile-table signal",
            }
        )
    if found is None:
        return _with_legend(
            {
                "name": name,
                "id": None,
                "hint": "AOSP's name lookup (what Resources.getIdentifier returns) finds "
                "nothing — list_resources shows what the table stores, including names the "
                "lookup cannot reach",
            }
        )
    return _with_legend({"name": name, "id": found, "default_package": package})


def _t_list_resources(
    manifest: Manifest,
    type_name: str | None = None,
    source_role: str = "base",
    offset: int = 0,
    limit: int = DEFAULT_RESOURCE_LIMIT,
) -> dict[str, Any]:
    table = manifest.resources
    if table is None:
        return _no_table_error(manifest)
    cookies = [
        c for c in range(table.cookie_count()) if table.cookie_role(c) == source_role
    ]
    if not cookies:
        return {"error": f"no {source_role!r} table is loaded"}
    page = table.list_entries(
        cookie=cookies[0],
        type_name=type_name,
        offset=max(0, int(offset)),
        limit=_limit(limit),
    )
    out = _clip_all(
        _compact({k: v for k, v in _public(page).items() if k != "entries"})
    )
    rows = [_clip_all(_compact(_public(e))) for e in page.entries]
    out["rows"], capped = _within_budget(rows, len(json.dumps(out, default=str)))
    if capped:
        out["response_capped"] = True
    end = page.offset + len(out["rows"])
    out["next_offset"] = end if end < page.total else None
    out["legend"] = _legend_for(out)
    return out


def _t_search_resource_strings(
    manifest: Manifest,
    needle: str,
    ignore_case: bool = True,
    include_framework: bool = False,
    limit: int = DEFAULT_RESOURCE_LIMIT,
) -> dict[str, Any]:
    table = manifest.resources
    if table is None:
        return _no_table_error(manifest)
    if not needle:
        return {"error": "needle must be a non-empty substring"}
    found = table.search_strings(
        needle,
        ignore_case=ignore_case,
        include_framework=include_framework,
        limit=_limit(limit),
    )
    out = _clip_all({k: v for k, v in _public(found).items() if k != "hits"})
    # The exact totals stand on their own, and the one-gap-per-chunk details go last: if the
    # response must shorten `unread`, it drops those details first, never a gap of another kind.
    out["unread"] = sorted(
        out["unread"], key=lambda g: g.get("kind") == "ignored_chunk"
    )
    if found.ignored_chunks:
        out["ignored_chunks"] = found.ignored_chunks
        out["bytes_in_ignored_chunks"] = found.bytes_in_ignored_chunks
        out["values_in_ignored_chunks"] = found.values_in_ignored_chunks
    # ...and the account takes at most a quarter of the response, so the hits keep the rest
    header_markers: dict[str, str] = {}
    _shrink(out, RESPONSE_BYTES // 4, header_markers)
    hits = []
    for hit in _public(found)["hits"]:
        hit["entries"] = [_compact(e) for e in hit.get("entries", ())]
        hit = _clip_all(_window(_compact(hit)))
        # one hit's holders are budgeted too: up to 256 per hit with clipped names made a single
        # hit ~1 MB in review, past the response cap that always keeps one hit
        shown, cut = _within_budget(hit.get("entries", []), 0, HIT_ENTRY_BYTES)
        if cut:
            hit["entries"] = shown
            hit["entries_truncated"] = True
        hits.append(hit)
    out["hits"], capped = _within_budget(hits, len(json.dumps(out, default=str)))
    if capped:
        out["response_capped"] = True
        out["hits_truncated"] = True
    out["legend"] = _legend_for(out, header_markers)
    return out


def _size(obj: Any) -> int:
    return len(json.dumps(obj, default=str))


def _largest_list(obj: Any) -> tuple[dict[str, Any], str] | None:
    """Find the (parent, key) of the largest list of two or more items held under a dict key."""
    best: tuple[int, dict[str, Any], str] | None = None
    stack: list[Any] = [obj]
    while stack:
        cur = stack.pop()
        if isinstance(cur, dict):
            for k, v in cur.items():
                if isinstance(v, list) and len(v) > 1:
                    n = _size(v)
                    if best is None or n > best[0]:
                        best = (n, cur, k)
                if isinstance(v, (dict, list)):
                    stack.append(v)
        elif isinstance(cur, list):
            stack.extend(x for x in cur if isinstance(x, (dict, list)))
    return None if best is None else (best[1], best[2])


_PAGE_KEYS = ("rows", "items", "anomalies", "children")


def _count_ids(obj: Any, ids: set[int]) -> int:
    if isinstance(obj, dict):
        return sum(_count_ids(v, ids) for v in obj.values())
    if isinstance(obj, list):
        return sum(1 if id(x) in ids else _count_ids(x, ids) for x in obj)
    return 0


def _largest_value(obj: dict[str, Any]) -> tuple[dict[str, Any], str] | None:
    """Find the (parent, key) of the largest nested dict/list value.

    What to omit when no list can be halved (a chain of single children).
    """
    best: tuple[int, dict[str, Any], str] | None = None
    stack: list[Any] = [obj]
    while stack:
        cur = stack.pop()
        items = cur.items() if isinstance(cur, dict) else ()
        for k, v in items:
            if isinstance(v, (dict, list)) and v:
                n = _size(v)
                if best is None or n > best[0]:
                    best = (n, cur, k)
                stack.append(v)
        if isinstance(cur, list):
            stack.extend(x for x in cur if isinstance(x, (dict, list)))
    return None if best is None else (best[1], best[2])


def _shrink(out: dict[str, Any], limit: int, added: dict[str, str]) -> bool:
    """Halve the largest list until `out` serialises within `limit`; False if nothing is left.

    Each cut keeps the head and is marked `<key>_truncated` beside the list, with the original
    length in `<key>_count`; `added` collects their legend. A response with no list to halve has
    its largest nested value replaced by `{"omitted_bytes": n}` — never the whole response.
    """
    while _size(out) > limit:
        found = _largest_list(out)
        if found is None:
            big = _largest_value(out)
            if big is None:
                return False
            parent, key = big
            parent[key] = {"omitted_bytes": _size(parent[key])}
            added["omitted_bytes"] = (
                "a value too large for the response, replaced by its size"
            )
            continue
        parent, key = found
        items = parent[key]
        parent.setdefault(f"{key}_count", len(items))
        parent[key] = items[: len(items) // 2]
        parent[f"{key}_truncated"] = True
        added[f"{key}_truncated"] = f"{key} lists only some of them — see {key}_count"
        added[f"{key}_count"] = f"how many {key} there were before the response was cut"
    return True


def _bounded(out: dict[str, Any]) -> dict[str, Any]:
    """Bound ONE tool response, whatever the tool: the single place every tool's output passes.

    Each tool pages and clips what it knows to be large, but those were eleven hand-made orders
    and a response could still leave unbounded (audit): a search's `unread` account — one gap per
    ignored pool chunk, measured 319 KB on a flood of empty chunks — was never counted against
    RESPONSE_BYTES, and `resolve_resource` handed a 32 KB attacker string over whole. So here, on
    every response: every over-long string is cut (marked beside it), and while the whole is over
    HARD_RESPONSE_BYTES the largest list is halved, keeping its head, marked `<key>_truncated` with
    the original `<key>_count`. A page whose `rows` were cut continues from where they now end.
    """
    out = _clip_all(out)
    added: dict[str, str] = {}
    _shrink(out, HARD_RESPONSE_BYTES, added)
    # A paged response whose page list was cut continues from where that list now ends.
    for key in _PAGE_KEYS:
        if out.get(f"{key}_truncated") and isinstance(out.get("offset"), int):
            end = out["offset"] + len(out[key])
            total = out.get("total")
            out["next_offset"] = (
                end if not isinstance(total, int) or end < total else None
            )
    made = {id(c) for c in _CUTS.get() or ()}
    cuts = _count_ids(out, made) if made else 0
    if cuts:
        out["strings_cut"] = cuts
        added["strings_cut"] = (
            f"strings inside lists cut to {VALUE_CLIP_CHARS} chars; each ends '…(cut: N chars, ref "
            "R)' with N its original length — pass R to read_string as `ref` for the whole "
            "(a string stored ending so is not counted)"
        )
    markers = {k for k in _keys(out) if k.endswith(_CUT_MARKERS)} | set(added)
    prior = out.get("legend")
    legend: dict[str, str] = prior if isinstance(prior, dict) else {}
    missing = sorted(k for k in markers if k not in legend)
    if missing:
        for k in missing:
            legend[k] = added[k] if k in added else _cut_marker_legend(k)
        out["legend"] = legend
    return out


def _nonneg_int(v: Any) -> bool:
    return isinstance(v, int) and not isinstance(v, bool) and 0 <= v < 2**32


def _t_read_string(
    manifest: Manifest,
    ref: str | None = None,
    pool_index: int | None = None,
    cookie: int | None = None,
    offset: int = 0,
) -> dict[str, Any]:
    """Read a long string whole, READ_CHARS at a time.

    Every response cuts a string at VALUE_CLIP_CHARS and marks the cut with a ``ref``; this reads
    the whole from it, whatever the string was (audit: past 300 characters a C2 URL was
    unreachable). A value a page OMITTED (``value_omitted``) was never in a response to cut, so it
    is read by its ``pool_index`` (on string rows and search hits) in the element ``cookie`` (the
    base by default) — with the byte offset where the app's own copy stops, if it has a NUL.
    """
    if not _nonneg_int(offset):
        return {"error": "offset must be a non-negative integer"}
    extra: dict[str, Any] = {}
    if ref is not None and pool_index is not None:
        return {"error": "give a ref OR a pool_index, not both"}
    if ref is not None:
        call = _CALL.get()
        value = call.store.get(str(ref)) if call is not None else None
        if value is None:
            # The action first, and the caller's ref not echoed: a long error is clipped at 300
            # characters, and the ref may be text an LLM copied out of the APK. No cause list
            # either — this tool cannot tell which happened, and the Session's ends keep growing.
            return {"error": "re-run the call that showed this ref: no string is held under "
                    "it — it is unknown, evicted, or, under isolated.Session, from a worker "
                    "since replaced (any restart)"}  # fmt: skip
    elif pool_index is not None:
        if not _nonneg_int(pool_index) or (
            cookie is not None and not _nonneg_int(cookie)
        ):
            return {"error": "pool_index and cookie must be non-negative integers"}
        table = manifest.resources
        if table is None:
            return _no_table_error(manifest)
        if cookie is not None and cookie >= table.cookie_count():
            return {
                "error": f"no element {cookie} (cookie_count {table.cookie_count()})"
            }
        got = table.pool_string(pool_index, cookie)
        if got is None:
            return {"error": f"the value pool does not hand over index {pool_index}"}
        value = got["text"]
        extra["cookie"] = table._base_cookie() if cookie is None else cookie
        if got["undecodable"]:
            extra["undecodable"] = True
        if got["device_truncates_at"] is not None:
            extra["device_truncated"] = True
            extra["device_truncates_at"] = got["device_truncates_at"]
    else:
        return {"error": "give a ref (from a cut string) or a pool_index"}
    off = min(offset, len(value))
    end = min(off + READ_CHARS, len(value))
    return _with_legend(
        {
            "pieces": [
                value[i : i + VALUE_CLIP_CHARS]
                for i in range(off, end, VALUE_CLIP_CHARS)
            ],
            "offset": off,
            "length": len(value),
            "next_offset": end if end < len(value) else None,
            **extra,
        }
    )


_EXECUTORS: dict[str, Callable[..., dict[str, Any]]] = {
    "analyze_manifest": _t_analyze_manifest,
    "list_permissions": _t_list_permissions,
    "list_components": _t_list_components,
    "manifest_anomalies": _t_manifest_anomalies,
    "get_manifest_tree": _t_get_manifest_tree,
    "resolve_resource": _t_resolve_resource,
    "resolve_bag_resource": _t_resolve_bag_resource,
    "resource_config_variants": _t_resource_config_variants,
    "read_string": _t_read_string,
    "resource_id_for": _t_resource_id_for,
    "list_resources": _t_list_resources,
    "search_resource_strings": _t_search_resource_strings,
}

TOOL_DEFINITIONS: list[dict[str, Any]] = [
    {
        "name": "analyze_manifest",
        "description": "Headline manifest facts: package, parse status, the permissions the "
        "device requests and components it registers (counts, from the replayed package-parser "
        "dispatch), install_error when the device would refuse the manifest (install_error_if when only "
        "one flag setting refuses it), anomaly count, "
        "resources_status (ok / absent / load_failed / "
        "arsc_unopenable); resources_not_judged when THIS host, not AOSP, ended the table's "
        "load; stack_dropped for framework / split members left out.",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "list_permissions",
        "description": "List every <uses-permission> (and -sdk-23 / -sdk-m) element with what "
        'the DEVICE does with it (paginated): `device` is "read" when the device\'s package '
        "parser requests it, else why not (a loop that skips it); `hidden` when it is read from "
        "a place a tree reader would not look (nested in an element whose handler leaves its "
        "subtree); `conditions` when it holds only under a device flag.",
        "input_schema": {
            "type": "object",
            "properties": {
                "offset": {"type": "integer"},
                "limit": {"type": "integer"},
            },
        },
    },
    {
        "name": "list_components",
        "description": "List every component element (activity/activity-alias/service/receiver/"
        "provider) with name, source line and what the DEVICE does with it (paginated): "
        "`device`, `hidden`, `conditions` as in list_permissions.",
        "input_schema": {
            "type": "object",
            "properties": {
                "offset": {"type": "integer"},
                "limit": {"type": "integer"},
            },
        },
    },
    {
        "name": "manifest_anomalies",
        "description": "Dual-parser / present-vs-consumed anomalies (ResID spoofing, masked "
        "dynamic references, duplicate attributes, dangling or looping resource references), "
        "high severity first, paged (offset, limit, next_offset); `by_kind` counts every "
        "finding by kind across all pages. severity: high = a plain read of the bytes, as other "
        "tools do it, shows something the device does not do; medium = a construction that "
        "makes analysis harder, while a plain read is not misled; info = a fact about this "
        "analysis (the host, a detector, a skipped check), never evidence about the APK. `detail` "
        "says why for each finding.",
        "input_schema": {
            "type": "object",
            "properties": {"offset": {"type": "integer"}, "limit": {"type": "integer"}},
        },
    },
    {
        "name": "get_manifest_tree",
        "description": "The full manifest as the sparse AOSP data tree (docs/tree-schema.md). "
        "When it is too large for one response it is returned one level at a time: `node` (the "
        "element at `path`), its attributes paged by attributes_offset, and its `children` as "
        "summaries paged by offset/limit, each carrying the `path` that opens it. Nothing is "
        "dropped — pass a `path` to go deeper. An element the DEVICE's package parser does not "
        "read where it stands carries `device` (not read and why, or read from a hidden place "
        "by which loop) and `device_conditions`; `install_error` when the device refuses the "
        "manifest.",
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {"type": "array", "items": {"type": "integer"}},
                "offset": {"type": "integer"},
                "limit": {"type": "integer"},
                "attributes_offset": {"type": "integer"},
            },
        },
    },
    {
        "name": "resolve_resource",
        "description": "Resolve a manifest @resource reference (e.g. '@0x7f0f001f' or "
        "'0x7f0f001f') to its value via resources.arsc (AOSP AssetManager2): returns "
        "type/value/entry_name/config, source APK (cookie), and a config-dependence flag. "
        "If the stored value was itself a reference the chain is reported too — was_reference, "
        "resolved_id/resolved_name (the chain's TAIL, kept separate from the head entry_name), "
        "ref_hops (every id visited, in order) and ref_terminal: 'value' (reached a real value), "
        "'null', 'self' (points at itself — either a self-reference or a bag), 'cycle', "
        "'max_hops' (longer than AOSP follows, so the device never gets a value) or 'unresolved'. "
        "'cycle' and 'max_hops' mean the device never reaches a value at all, so any value shown "
        "for this id is not what it sees; 'self' on a bag and 'null' are ordinary outcomes.",
        "input_schema": {
            "type": "object",
            "properties": {"res_id": {"type": "string"}},
            "required": ["res_id"],
        },
    },
    {
        "name": "resolve_bag_resource",
        "description": "Resolve a COMPLEX (bag/map) resource id — style/theme, array/string-array, "
        "plurals, or declared attr — to its flattened key-value entries via resources.arsc (AOSP "
        "GetBag). This is where string-array C2/target lists and style-based UI-impersonation live; "
        "the scalar resolve_resource returns null for them. Returns entries [{key, key_name, type, "
        "value, resolved, resolved_type, source}], entry_count, and truncated; a reference-typed "
        "entry also carries its resolved terminal value. Returns the default-config bag (config_axes "
        "!= 0 hints a config-conditioned variant exists). parent_cycle true: the style's parent "
        "chain loops back on itself — the entries are what AOSP builds when this id is asked first, "
        "but on a device they depend on which style in the loop the app inflated first. refused set "
        "('parent_chain' | 'work_cap'): this tool declined to build the bag, so the empty entries "
        "are NOT the device's — 'parent_chain' is itself a hostile-table signal. The entries "
        "are paged by bytes: entries_offset is where this page starts, entries_next_offset where "
        "the next one does (pass it as entries_offset).",
        "input_schema": {
            "type": "object",
            "properties": {
                "res_id": {"type": "string"},
                "entries_offset": {"type": "integer"},
            },
            "required": ["res_id"],
        },
    },
    {
        "name": "resource_id_for",
        "description": "Look a resource id up by name, exactly as the app's "
        "Resources.getIdentifier(name, defType, getPackageName()) does (AOSP GetResourceId). name "
        "is '[package:]type/entry' or just 'entry' with default_type; the package defaults to the "
        "manifest package. Returns {id} or {id: null, hint}. This is the CONSUMED view: a second "
        "entry stored under the same name is present in the table (list_resources shows it) but "
        "never found by name. refused set: the table fails AOSP's own entry check, so the "
        "lookup was not run (a hostile-table signal).",
        "input_schema": {
            "type": "object",
            "properties": {
                "name": {"type": "string"},
                "default_type": {"type": "string"},
            },
            "required": ["name"],
        },
    },
    {
        "name": "list_resources",
        "description": "Enumerate what one resources.arsc STORES — every type, config and entry, "
        "including integers, colours, references and entries nothing references (the PRESENT "
        "view; resolve_resource gives what the device selects). Filter with type_name ('string', "
        "'array', ...); source_role is 'base' (default) or 'framework'. Paginated: offset, limit "
        "(default 50, max 200), next_offset. Each row: id, type_name, entry_name, config, "
        "value_type, value; any other field appears only when true or set — absent means false "
        "or none (is_bag -> resolve_bag_resource; a missing name or value has a flag saying why). "
        "ANY string over 300 chars is cut and marked <field>_chars / <field>_clipped; a response "
        "stops at about 128 KB (response_capped; continue from next_offset). Every field not named "
        "here is defined in the response's own `legend`.",
        "input_schema": {
            "type": "object",
            "properties": {
                "type_name": {"type": "string"},
                "source_role": {"type": "string", "enum": ["base", "framework"]},
                "offset": {"type": "integer"},
                "limit": {"type": "integer"},
            },
        },
    },
    {
        "name": "search_resource_strings",
        "description": "Substring-search every string the resource table holds (the flat value "
        "pool — complete even for strings no entry still reaches), e.g. 'http', a bank name, a "
        "package. Returns hits [{value, pool_index, source_role, entries:[{id, entry_name, "
        "type_name, config}] that store it (entries_truncated: not all shown), "
        "device_truncates_at? (the app sees only a prefix), "
        "undecodable?}] plus read/unread/scans — an account of what was searched, so zero hits "
        "with something in unread is NOT proof of absence. limit default 50, max 200 "
        "(hits_truncated says more exist). Framework strings are skipped unless "
        "include_framework. A value over 300 chars is cut AROUND the match (match_at, "
        "value_offset, value_chars, value_clipped); any other long string is cut and marked the "
        "same way. Fields not named here are defined in the response's own `legend`.",
        "input_schema": {
            "type": "object",
            "properties": {
                "needle": {"type": "string"},
                "ignore_case": {"type": "boolean"},
                "include_framework": {"type": "boolean"},
                "limit": {"type": "integer"},
            },
            "required": ["needle"],
        },
    },
    {
        "name": "resource_config_variants",
        "description": "The distinct per-configuration values a device would select for a "
        "resource id (locale/density/sdk variants) — surfaces locale-conditioned "
        "impersonation and SDK-gated values the default-config resolve hides. "
        "`diverges: true` means the value is not the same across configurations. Each "
        "row: `config` (as stored), `served_by` (the definition AOSP served on a device "
        "presenting that config — the row's own, or one that outranks it; two rows can share "
        "a `config` label), `served_self` (whether that was this row's own definition), "
        "`no_device` (no device presents that config: the row is then probed on its stored bytes "
        "as they are — whether an app can pass them, and reach the definition, is list_resources' "
        "app_served_on). Paged by bytes (offset, next_offset, total); `diverges` and "
        "`distinct_values` are over every variant, not just this page.",
        "input_schema": {
            "type": "object",
            "properties": {"res_id": {"type": "string"}, "offset": {"type": "integer"}},
            "required": ["res_id"],
        },
    },
    {
        "name": "read_string",
        "description": f"Read a long string WHOLE, {READ_CHARS} characters at a time. Every tool cuts "
        "strings at 300 characters and marks the cut with a ref: <field>_cut_ref beside a cut "
        "field, or '…(cut: N chars, ref R)' inside a list — pass it as `ref`. A value a page "
        "OMITTED (value_omitted) is read by `pool_index` (on list_resources string rows and "
        "search hits) and `cookie` (the element; base by default). Give exactly one of ref or "
        "pool_index. Returns pieces (join them), offset, length, next_offset (pass it as offset for the "
        "rest); undecodable when the bytes are not valid text; device_truncated / "
        "device_truncates_at when the app's own copy stops at an embedded NUL.",
        "input_schema": {
            "type": "object",
            "properties": {
                "ref": {"type": "string"},
                "pool_index": {"type": "integer"},
                "cookie": {"type": "integer"},
                "offset": {"type": "integer"},
            },
        },
    },
]


# Tools that answer from the resource table. When the device loads none of this APK's own table
# (no resources.arsc listed, or one AOSP's archive reader refuses), they answer from the empty
# table AOSP loads instead — so each answer carries AOSP's lookup, and its "nothing here" is never
# read as a judgement about a table the APK does carry.
_TABLE_TOOLS = frozenset(
    {"resolve_resource", "resolve_bag_resource", "resource_config_variants", "read_string",
     "resource_id_for", "list_resources", "search_resource_strings"}
)  # fmt: skip


def _public(obj: Any) -> Any:
    """``dataclasses.asdict`` for an answer: every field declared a path (PATH_FIELD) is left out.

    Decided by the field's declaration, at the dataclass that holds it — a key-name filter over
    finished answers would also delete any future non-path field that shares the name.
    """
    if is_dataclass(obj) and not isinstance(obj, type):
        return {
            f.name: _public(getattr(obj, f.name))
            for f in fields(obj)
            if not f.metadata.get("path")
        }
    if isinstance(obj, (list, tuple)):
        return type(obj)(_public(v) for v in obj)
    if isinstance(obj, dict):
        return {k: _public(v) for k, v in obj.items()}
    return obj


def _with_arsc_entry(
    name: str, out: dict[str, Any], manifest: Manifest
) -> dict[str, Any]:
    # A stub manifest (tests) may carry neither attribute.
    if (
        name not in _TABLE_TOOLS
        or "error" in out
        or not getattr(manifest, "loads_no_own_table", False)
    ):
        return out
    entry = manifest.arsc_entry
    if entry is None:  # loads_no_own_table implies a lookup ran; narrows the type
        return out
    out["arsc_entry"] = dict(entry)
    legend = out.get("legend")
    legend = legend if isinstance(legend, dict) else {}
    legend["arsc_entry"] = FIELD_LEGEND["arsc_entry"]
    out["legend"] = legend
    return out


_SCHEMA_PROPS: dict[str, set[str]] = {
    t["name"]: set(t["input_schema"].get("properties", {})) for t in TOOL_DEFINITIONS
}


def _printable(obj: Any) -> Any:
    """Escape lone surrogates in every string of a tool's answer (see ``printable``)."""
    if isinstance(obj, str):
        return printable(obj)
    if isinstance(obj, dict):
        return {_printable(k): _printable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return type(obj)(_printable(v) for v in obj)
    return obj


def execute(name: str, args: dict[str, Any], manifest: Manifest) -> dict[str, Any]:
    """Dispatch a tool call by name against an open ``Manifest``.

    Arguments are filtered to the tool's declared schema, so transport-injected or stray
    keys (e.g. ``apk_path``) are ignored rather than raising.
    """
    fn = _EXECUTORS.get(name)
    if fn is None:
        return {"error": f"unknown tool: {name}"}
    allowed = _SCHEMA_PROPS.get(name, set())
    kwargs = {k: v for k, v in args.items() if k in allowed}
    # Dispatch boundary for a long-running MCP server that triages hostile APKs: never let a
    # tool call crash the loop. Catch everything and return a structured error; the exception
    # type is included so genuine internal bugs stay visible rather than silently swallowed.
    token = _CUTS.set([])
    store = _store_of(manifest)
    call = None if store is None else _Call(store)
    call_token = _CALL.set(call)
    try:
        out = _printable(
            _bounded(_with_arsc_entry(name, fn(manifest, **kwargs), manifest))
        )
        if call is not None:
            call.store.keep(call.shown(out))
        return out
    except MemoryError:
        # Not a failure of this tool alone: an allocation failed somewhere inside AOSP or Python,
        # and the Manifest's cached state (table, stores) may be half-built. Say so for the whole
        # call; isolated.Session ends its worker on this key, so the next call starts clean.
        return {
            "memory_exhausted": True,
            "error": f"memory ran out answering {name} — the Manifest's state is unknown: "
            "reopen it",
        }
    # the MCP boundary: any failure is an answer
    except Exception as exc:  # noqa: BLE001
        return {"error": f"{type(exc).__name__} in {name}: {exc}"}
    finally:
        _CALL.reset(call_token)
        _CUTS.reset(token)


def _store_of(manifest: Any) -> _CutStore | None:
    """Return the Manifest's cut store, made on first use; it lives as long as the Manifest."""
    store = getattr(manifest, "_axmlllm_cut_store", None)
    if store is not None:
        return store
    with _STORE_MADE:  # two threads' first calls must not each make one (review)
        store = getattr(manifest, "_axmlllm_cut_store", None)
        if store is None:
            store = _CutStore()
            try:
                manifest._axmlllm_cut_store = store
            except AttributeError:  # takes no attributes: no refs, cuts still marked
                return None
    return store


_STORE_MADE = threading.Lock()


__all__ = ["TOOL_DEFINITIONS", "execute"]
