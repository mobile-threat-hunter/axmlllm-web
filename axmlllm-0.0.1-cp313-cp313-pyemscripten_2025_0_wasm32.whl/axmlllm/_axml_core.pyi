"""Type stub for the native ``_axml_core`` extension (real AOSP libandroidfw).

The native boundary is typed here so the Python domain layer type-checks against a
concrete contract (PEP 484 / PEP 561). The returned ``dict`` shape is documented in
``docs/tree-schema.md``; ``Tree`` aliases it loosely (a recursive ``TypedDict`` would
over-constrain the sparse/optional fields).
"""

from typing import Any, Literal, TypedDict

Tree = dict[str, Any]

def parse_axml(data: bytes) -> Tree:
    """Parse raw binary-XML (AXML) bytes into the AOSP data tree.

    The bytes are parsed by AOSP ``ResXMLTree`` exactly as the device would; the
    returned tree preserves the string-name vs ResID dual identity and raw (unmasked)
    ``Res_value`` types. On a structurally invalid block returns ``{"format": "axml",
    "parse_status": "bad_document", "error": <status_t>}``.
    """
    ...

def parse_apk(path: str | bytes) -> Tree:
    """Open an APK, extract ``AndroidManifest.xml``, and parse it into the AOSP data tree.

    Raises ``RuntimeError`` if the archive cannot be opened or has no manifest entry.
    """
    ...

ZIP_ENTRY_NOT_FOUND: int

class _ArscEntryBase(TypedDict):
    stage: Literal["open", "find"]
    code: int
    message: str

class ArscEntry(_ArscEntryBase, total=False):
    # present when code == 0: the central directory's own statement of the entry
    method: int
    compressed_length: int
    uncompressed_length: int

def arsc_entry(path: str | bytes) -> ArscEntry:
    """Look up ``resources.arsc`` with the loader's own calls (``OpenArchive`` + ``FindEntry``).

    ``stage`` names the call that answered. ``code`` is libziparchive's raw result: 0 = found,
    ``ZIP_ENTRY_NOT_FOUND`` = none listed, any other = listed but refused — on which ApkAssets
    loads an empty table, exactly as for none listed. ``stage == "open"`` means the archive did
    not open for this lookup.
    """
    ...

class TableLoadError(RuntimeError):
    """The resolver's constructor refused the stack: which member, and why (as data)."""

    element: int  # index into the stack (the cookie); -1 = the stack as a whole
    cause: str  # load_rejected | allocation_failed | unindexable_package_id | set_apk_assets_failed
    role: str  # set by ResourceTable: "base" | "split" | "framework" | "stack"
    dropped: tuple[
        Any, ...
    ]  # set by ResourceTable: members dropped before this failure
    host_refusals: list[
        dict[str, Any]
    ]  # {call, errno, size}: the host's, inside ApkAssets::Load
    host_refusal_count: (
        int  # all of them (host_refusals keeps the last 8, oldest first)
    )

def witness_selftest() -> dict[str, Any]:
    """Prove the --wrap link and each wrapper's rule.

    ``hit``: wrappers reached; ``refused``: probe -> calls recorded; ``ring`` and
    ``refusal_count``: an overrun of the kept ring.
    """
    ...

def set_worker_log_mode(nonce: str) -> None:
    """Set worker log mode (worker only, once, before the APK is opened).

    AOSP's log floor becomes FATAL, ERROR across each load step, each step bracketed on fd 2 by
    ``<nonce> BEGIN|END ...`` markers.
    """
    ...

def arsc_inflate(path: str | bytes) -> dict[str, Any] | None:
    """Replay the device's inflate of resources.arsc into a counting writer.

    ``{code, message, written, declared, stored}``; None unless the entry is found and deflated.
    """
    ...

class ArscResolver:
    """Resolve resource ids against an APK's resources.arsc (AOSP AssetManager2)."""

    def __init__(
        self, apk_paths: list[str] | list[bytes], purpose: str = "stack"
    ) -> None:
        """Load an ApkAssets stack (base first, then splits/overlays/framework).

        Paths are bytes (``os.fsencode``): a file name need not be UTF-8. No error message
        names a path (a failing element is "stack element N", its index in ``apk_paths``); a
        value's ``source`` comes back as bytes for ``os.fsdecode``.
        """
        ...

    def resolve(self, resid: int) -> Tree | None:
        """Resolve a numeric resource id to a scalar ``{id,type,value,entry_name,...}``.

        Includes ``config_axes`` (CONFIG_* bitmask, SPEC_* bits masked off) and ``public`` /
        ``staged`` (SPEC_PUBLIC / SPEC_STAGED_API visibility). None if the id is absent or is a bag
        (complex/map entry) — use ``resolve_bag`` for those.

        When the stored value was a reference the chase is instrumented: ``was_reference``,
        ``original_type``, ``resolved_id`` / ``resolved_name`` (the chain TAIL, kept apart from the
        head ``id`` / ``entry_name``), ``ref_hops`` (visited ids, in order) and ``ref_terminal``
        (``value`` | ``null`` | ``self`` | ``cycle`` | ``max_hops`` | ``unresolved``).
        ``resolve_error`` (``not_found`` | ``io_error``) is set when AOSP's own ``ResolveReference``
        reported failure.
        """
        ...

    def resolve_bag(self, resid: int) -> Tree | None:
        """Resolve a complex (bag/map) id — style/theme, array, plurals, attr — via AOSP GetBag.

        Returns ``{id, entry_name, config_axes, public, staged?, entries: [{key, key_name, type,
        value, resolved, resolved_type, cookie, source}], entry_count, truncated, parent_cycle?,
        refused?}`` (``parent_cycle`` when the chain loops, #15; ``refused`` — ``"parent_chain"``
        or ``"work_cap"`` — when this resolver declined to build it, so the empty ``entries`` are
        unknown, not AOSP's), or None if the id is absent or is a scalar. Reference-typed entry
        values also carry their one-shot ``resolved`` scalar.

        Every call builds on a fresh AOSP manager, so the answer depends on the id alone — none of
        GetBag's never-evicted caches (a dirty parent-walk stack, a parent-less copy left by a walk
        through a loop) is kept between calls.
        """
        ...

    def resource_id_for(
        self, name: str, default_type: str = "", default_package: str = ""
    ) -> int | None:
        """Return AOSP GetResourceId's answer — what ``Resources.getIdentifier`` returns — or None."""
        ...

    def bag_build_cost(self, resid: int) -> int | None:
        """Estimate the bag entries GetBag copies building this id; None if the guard refuses."""
        ...

    def element_packages(self, cookie: int) -> list[Tree]:
        """List one element's packages: ``[{name, stored_id, runtime_id, dynamic}]``."""
        ...

    def bag_parent_cycle(self, resid: int) -> bool | None:
        """Report whether the id's bag parent chain loops back on itself.

        True if it loops, False if it ends, None if the walk was refused before it could tell.
        Structural, so independent of query order (#15).
        """
        ...

    def entry_is_complex(self, resid: int) -> bool | None:
        """Is the entry AOSP selects for this id COMPLEX (a map/bag)? None if undeterminable.

        Answered by AOSP's own discriminator — ``GetResource`` refuses a complex entry when
        ``may_be_bag`` is false and represents it as a self-pointing reference when it is true —
        so it inherits AOSP's configuration selection rather than assuming a particular config
        chunk. Deliberately distinct from ``resolve_bag(...) is not None``, which answers "could
        ``GetBag`` build this, as of the first ask": ``GetBag`` recurses into the parent and propagates the parent's
        failure, so an ordinary style reports "not a bag" whenever its parent chain cannot be
        walked (no framework table loaded, parent in an unmounted split, unresolvable dynamic
        reference). Only an explicit ``False`` means "definitely a scalar".
        """
        ...

    def declared(self, resid: int) -> bool:
        """Report whether a loaded package reserves a slot for the id.

        True when the ``TypeSpec`` is present and the entry index is within ``entryCount`` —
        covers split-delivered / public-reserved / bag entries, so only a forged or stripped id
        reads as not-declared (dangling).

        ``resid`` is in the RUNTIME id space: a shared library stores package id ``0x00`` and AOSP
        assigns it from a stack-wide counter starting at ``0x02`` (#7), so this answers True at the
        assigned id and False at the stored one. ``id`` on an attribution row is in the same space.
        """
        ...

    def declaring_cookies(self, resid: int) -> list[int]:
        """Return the stack APK indices (== resolved ``SelectedValue.cookie``) that declare the id.

        The per-APK form of ``declared``: compare against a resolved value's cookie to tell a
        split override (base + split both declare, split won) from a base-only/split-only resource.
        """
        ...

    def list_entries(
        self,
        cookie: int,
        package_id: int = -1,
        type_id: int = -1,
        type_name: str = "",
        offset: int = 0,
        limit: int = 200,
    ) -> Tree:
        """Enumerate one stack element's entries — every type, config chunk and entry index.

        Unlike ``entries_for_pool_indices``, which is keyed on the value string pool and so can
        only reach string-valued entries, this reports whatever the entry stores.

        ``{rows: [{id, enumerated_id?, type_id_offset?, type_name?, entry_name?, name_omitted?,
        config, package_id, dynamic_package?, value_type?, value?, value_omitted?, out_of_pool?,
        no_value_pool?, value_undecodable?, unmapped_reference?, null_empty?, is_bag?, unreadable?,
        unverified?, served_on?, unserved?, unserved_reason?, selection_capped?,
        contending_packages?, contention?}], total: int,
        offset: int, packages: int, table_present: bool, scan_capped: bool, rows_capped: bool,
        unwalked_chunks: int, unwalked_chunk_entries: int, names_omitted: int,
        names_undecodable: int, values_omitted: int, out_of_pool_values: int,
        values_undecodable: int, value_pool_present: bool, unserved_rows: int,
        selection_capped_rows: int, contended_rows: int}``. Each row carries exactly one of ``served_on`` (a device
        configuration AOSP serves that row's definition on), ``unserved`` (+ ``unserved_reason``:
        ``never_matches`` / ``always_outranked`` / ``zero_request_only`` / ``not_consulted`` /
        ``unreadable_entry``; and
        ``app_served_on`` when an app-built configuration is served it, ``zero_request_unasked``
        when the all-zero request's pick could not be attributed) or
        ``selection_capped`` (#17), and ``contending_packages`` + ``contention``
        (``dynamic_package`` / ``same_element`` / ``cross_element``) when more than one package
        defines the id.

        A page is bounded on both of its axes: ``limit`` is capped (``rows_capped``), and a pooled
        string value is shared per pool index under a byte budget (``value_omitted`` /
        ``values_omitted``). Row ``package_id`` is the STORED byte while the ``package_id`` FILTER
        is the runtime one — they differ for a shared library, and ``id``'s high byte is always the
        filter value.

        Filters are AND-ed; ``package_id``/``type_id`` negative and ``type_name`` empty mean "any".
        ``package_id`` matches the RUNTIME id and ``type_id`` the STORED type id — the two bytes
        ``id`` is built from. No PAGE index is retained between calls — a page is walked, counted
        and sliced — so ``total`` is exact within the scan budget and ``scan_capped`` says when it
        is not. (#17 state is retained: the selection cache, bounded by entry count, and each
        package type's printed indices, bounded by the table; see ``slot_selection``.) The page itself is bounded on both of its axes: ``rows_capped`` when the row cap
        actually bound, and ``value_omitted``/``values_omitted`` when a pooled value exceeded the
        page's byte budget.
        """
        ...

    def package_collisions(self) -> list[Tree]:
        """``[{runtime_id, packages, dynamic_packages, cookies}]`` — counter-assigned collisions."""
        ...

    def contention_for(self, resid: int) -> Tree | None:
        """``{contending_packages, contention}`` when more than one package defines the id (#17)."""
        ...

    def contention_summary(self, cookie: int) -> Tree:
        """``{by_kind: {kind: ids}, samples: {kind: [{id, contending_packages, contention}]}}``."""
        ...

    def slot_selection(self, resid: int) -> Tree:
        """Report every stored definition of the slot and the device each is served on (#17).

        ``{candidates: [{cookie, config, served, served_on?, device?, unserved_reason?}],
        capped: bool, capped_reason?}``, in AOSP's candidate order. ``served`` is True with a
        witness ``device`` (``ResTable_config`` bytes) the real resolver serves it on, False when
        no device in the domain is, or None when undecided: a budget ran out before a witness
        was found, or the walk's witness was not confirmed by the real resolver (``capped_reason``
        ``candidates`` / ``locale`` / ``reps`` / ``work`` / ``unconfirmed``).
        """
        ...

    def select_on_device(self, resid: int, device: bytes) -> Tree | None:
        """Run the mirror of FindEntryInternal on exactly ``device``: ``{cookie, config}`` or None."""
        ...

    def resolve_on_device(self, resid: int, device: bytes) -> Tree | None:
        """Ask the real AssetManager2, configured with exactly ``device``, for ``resid``.

        ``{cookie, config, type, data}`` or None — the oracle ``slot_selection`` and
        ``select_on_device`` are checked against.
        """
        ...

    def resolve_config_variants(self, resid: int) -> Tree:
        """``{variants: [{config, type, value}, ...], truncated: bool}`` — one row per config."""
        ...

    def ignored_pool_chunks(self, cookie: int) -> Tree:
        """String-pool chunks this stack element's table holds that the runtime never loads.

        ``{inspected: bool, unavailable: str | None, walk_error: str | None,
        chunks: [{bytes, level, declared_string_count}], chunks_truncated: bool, total_ignored: int}``.

        Mirrors AOSP's rule, which is recursive rather than a list of places: at every level a
        chunk whose type that level does not handle is skipped by its declared size and its bytes
        are never interpreted, so it is an opaque container and a pool inside it is equally
        unreachable. AOSP iterates chunks at four sites (LoadedArsc.cpp:946, :832, :514, :678);
        the walk descends all of them plus every unhandled chunk. Each chunk reports the ``level``
        that stepped over it. A package's two consumed pools are matched BY ADDRESS against
        ``header->typeStrings``/``->keyStrings`` (:521-548).

        Computed ONCE when the resolver loads, so the verdict always describes the bytes the
        resolver is answering from and cannot drift if the file changes underneath.

        ``inspected`` False means the walk could not run (``unavailable`` says why); ``walk_error``
        means it stopped early on a malformed chunk while the table still loaded. Neither is an
        empty ``chunks`` list, which asserts the walk completed and found nothing.

        ``declared_string_count`` is read off an unvalidated header — what the chunk CLAIMS, never
        a count of anything read — and is None when ``headerSize`` cannot hold the field.
        ``bytes`` is the chunk's measured size. ``total_ignored`` stays exact past the
        ``chunks_truncated`` enumeration cap.

        Raises ``IndexError`` for a cookie outside the stack.
        """
        ...

    def entries_for_pool_indices(self, cookie: int, indices: list[int]) -> Tree:
        """Scalar entries of one stack element that STORE the given value-pool indices.

        ``id``/``enumerated_id`` are RUNTIME ids (#7); ``package_id`` is the byte stored in the
        arsc, which differs from ``id``'s high byte only for a ``dynamic_package``.

        ``{entries: {pool_index: {rows: [{id, enumerated_id?, type_id_offset?, type_name?,
        entry_name?, name_omitted?, config, package_id, dynamic_package?}], total: int}},
        table_present: bool, packages: int, scanned_entries: int, string_entries: int,
        complex_entries: int, unreadable_entries: int, unverified_values: int,
        out_of_pool_values: int, unwalked_chunks: int, unwalked_chunk_entries: int,
        names_omitted: int, names_undecodable: int, scan_capped: bool, store_capped: bool}``.

        Names are decoded only for emitted rows and shared by (pool, raw bytes, encoding) — the
        index alone is not identity, since every package has its own key pool. Sharing bounds the
        aliasing axis only: pooled strings may OVERLAP, so distinct name bytes are quadratic in
        the pool, and the RAW POOL BYTES a call decodes are therefore explicitly budgeted — not
        the retained bytes, which CPython sizes by the widest code point (up to 4x). A name past the
        budget is omitted (``name_omitted`` on the row, never shortened). ``names_omitted`` counts
        dropped ``(pool, index)`` SLOTS — an upper bound on the distinct names lost, since the
        omission path cannot de-duplicate by bytes without retaining what the budget refused.

        ``rows`` is capped per index while ``total`` stays exact past the RETENTION caps — one
        ``ResTable_type`` chunk may declare 65535 offsets that all point at a single entry. Past
        ``scan_capped`` it is only a floor: the walk abandons the rest of the table, so entries
        after the budget are neither listed nor counted.

        ``enumerated_id`` and ``type_id_offset`` appear only when the package's ``typeIdOffset``
        makes AOSP's two resource-id conventions disagree. **Neither id form is claimed to
        resolve**: that needs a type with stored id ``S - offset`` to exist as well, which is a
        property of the package's type set, and for an aapt2 feature split holds for no type.

        The join is an exact equality — a scalar entry whose ``Res_value.dataType`` is
        ``TYPE_STRING`` stores the pool index in ``data`` — read from the STORED bytes, so an
        alias (which stores ``TYPE_REFERENCE``) can never claim its target's string. Per cookie,
        because a string index addresses its own table's pool.

        Walks what ``FindEntry`` walks: every package, every type reachable by a resource id,
        every ``ResTable_type`` chunk of it (one per configuration), bounded by that chunk's own
        ``entryCount`` — NOT ``LoadedPackage::iterator``, which is bounded by the typeSpec's
        (LoadedArsc.cpp:588). Built once per stack element and cached.

        A missing index means no scalar entry stores it, which is ordinary: bag items, feature-flag
        names and unreferenced strings all live in the same pool. The counters are the account
        behind that — an empty result must never be read as "this string is not in the table".

        Raises ``IndexError`` for a cookie outside the stack.
        """
        ...

    def pool_values(self, cookie: int, offset: int = 0, limit: int = 100000) -> Tree:
        """Read one stack element's global value string pool — the table's flat string store.

        ``{values: [str], total: int, offset: int, encoding: "utf8"|"utf16"|None,
        pool_present: bool, table_present: bool, unreadable: [int], undecodable: [int],
        device_truncates_at: {int: int}}``. Index lists are ABSOLUTE, not relative to ``offset``.

        ``unreadable`` slots yield no bytes (the device cannot read them either) and appear as
        ``""`` placeholders so positions keep matching absolute indices; ``undecodable`` ones had
        undecodable bytes replaced with U+FFFD and remain searchable — but the searched text is
        then not the stored text, so a caller must carry that into its coverage account;
        ``device_truncates_at`` maps an index to the BYTE offset where the app's own
        ``NewStringUTF`` stops on an embedded NUL (legitimately ``0`` when the NUL is first).

        ``pool_present`` and ``table_present`` are independent: a table whose
        ``RES_STRING_POOL_TYPE`` chunk is absent loads and resolves ids normally
        (LoadedArsc.cpp:839-850) while having no value pool at all.

        Raises ``IndexError`` for a cookie outside the stack — as distinct from an element that
        has no table, which reports ``table_present: False``.
        """
        ...
